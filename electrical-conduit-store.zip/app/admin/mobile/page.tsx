"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Progress } from "@/components/ui/progress"
import {
  Smartphone,
  Tablet,
  Download,
  Upload,
  Users,
  BarChart3,
  Settings,
  Bell,
  Star,
  TrendingUp,
  Activity,
  Globe,
  Shield,
  Eye,
  Edit,
  Plus,
  RefreshCw,
  CheckCircle,
  AlertTriangle,
  Clock,
  Target,
  Send,
  Code,
  Monitor,
  Wifi,
  Battery,
  Signal,
} from "lucide-react"

// Mock data for mobile app management
const mockAppVersions = [
  {
    id: 1,
    platform: "iOS",
    version: "2.1.0",
    buildNumber: "210",
    status: "live",
    downloads: 1245,
    rating: 4.8,
    reviews: 156,
    releaseDate: "2024-01-10",
    size: "45.2 MB",
    minOS: "iOS 13.0",
  },
  {
    id: 2,
    platform: "Android",
    version: "2.1.0",
    buildNumber: "210",
    status: "live",
    downloads: 2890,
    rating: 4.6,
    reviews: 342,
    releaseDate: "2024-01-10",
    size: "38.7 MB",
    minOS: "Android 7.0",
  },
]

const mockDeviceStats = [
  { device: "iPhone 14 Pro", users: 245, percentage: 18.5 },
  { device: "Samsung Galaxy S23", users: 198, percentage: 14.9 },
  { device: "iPhone 13", users: 167, percentage: 12.6 },
  { device: "iPad Pro", users: 134, percentage: 10.1 },
  { device: "OnePlus 11", users: 89, percentage: 6.7 },
]

const mockCrashReports = [
  {
    id: 1,
    error: "NullPointerException in ProductListActivity",
    platform: "Android",
    version: "2.1.0",
    occurrences: 23,
    affectedUsers: 18,
    firstSeen: "2024-01-14",
    lastSeen: "2024-01-15",
    status: "investigating",
  },
  {
    id: 2,
    error: "Memory leak in ImageCache",
    platform: "iOS",
    version: "2.0.9",
    occurrences: 12,
    affectedUsers: 9,
    firstSeen: "2024-01-12",
    lastSeen: "2024-01-13",
    status: "fixed",
  },
]

const mockPushNotifications = [
  {
    id: 1,
    title: "โปรโมชั่นพิเศษ LB Series",
    message: "ลดราคาสูงสุด 20% สำหรับสินค้า LB Series",
    audience: "all_users",
    scheduled: "2024-01-16 10:00",
    status: "scheduled",
    estimatedReach: 3245,
  },
  {
    id: 2,
    title: "สินค้าใหม่เข้าแล้ว",
    message: "T-Series รุ่นใหม่พร้อมส่ง",
    audience: "premium_customers",
    scheduled: "2024-01-15 14:30",
    status: "sent",
    actualReach: 1567,
    openRate: 24.5,
    clickRate: 8.2,
  },
]

export default function MobileAppManagement() {
  const [activeTab, setActiveTab] = useState("overview")

  // App Overview Dashboard
  const AppOverview = () => (
    <div className="space-y-6">
      {/* App Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">ผู้ใช้งานรวม</p>
                <p className="text-2xl font-bold">4,135</p>
                <p className="text-xs text-green-600 flex items-center mt-1">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  +12.5% จากเดือนที่แล้ว
                </p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <Users className="h-6 w-6 text-blue-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-400 to-blue-600"></div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">ดาวน์โหลดรวม</p>
                <p className="text-2xl font-bold">4,135</p>
                <p className="text-xs text-purple-600">iOS: 1,245 | Android: 2,890</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                <Download className="h-6 w-6 text-purple-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-purple-400 to-purple-600"></div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">คะแนนเฉลี่ย</p>
                <p className="text-2xl font-bold">4.7</p>
                <p className="text-xs text-yellow-600">จาก 498 รีวิว</p>
              </div>
              <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center">
                <Star className="h-6 w-6 text-yellow-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-yellow-400 to-yellow-600"></div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">ผู้ใช้งานวันนี้</p>
                <p className="text-2xl font-bold">892</p>
                <p className="text-xs text-green-600">21.6% ของผู้ใช้ทั้งหมด</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <Activity className="h-6 w-6 text-green-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-green-400 to-green-600"></div>
          </CardContent>
        </Card>
      </div>

      {/* App Versions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>เวอร์ชั่นแอปพลิเคชั่น</span>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              อัพโหลดเวอร์ชั่นใหม่
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {mockAppVersions.map((app) => (
              <Card key={app.id} className="border-2">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      {app.platform === "iOS" ? (
                        <Smartphone className="h-5 w-5 text-gray-600" />
                      ) : (
                        <Tablet className="h-5 w-5 text-green-600" />
                      )}
                      <span>{app.platform}</span>
                    </div>
                    <Badge variant={app.status === "live" ? "default" : "secondary"}>
                      {app.status === "live" ? "เผยแพร่แล้ว" : "รอเผยแพร่"}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-gray-600">เวอร์ชั่น</p>
                      <p className="font-medium">
                        {app.version} ({app.buildNumber})
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-600">ขนาดไฟล์</p>
                      <p className="font-medium">{app.size}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">ดาวน์โหลด</p>
                      <p className="font-medium">{app.downloads.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">คะแนน</p>
                      <div className="flex items-center space-x-1">
                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        <span className="font-medium">{app.rating}</span>
                        <span className="text-gray-500">({app.reviews})</span>
                      </div>
                    </div>
                    <div>
                      <p className="text-gray-600">วันที่เผยแพร่</p>
                      <p className="font-medium">{app.releaseDate}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">OS ขั้นต่ำ</p>
                      <p className="font-medium">{app.minOS}</p>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline" className="flex-1 bg-transparent">
                      <Eye className="h-4 w-4 mr-2" />
                      ดูรายละเอียด
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1 bg-transparent">
                      <Upload className="h-4 w-4 mr-2" />
                      อัพเดท
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Device Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>อุปกรณ์ที่ใช้งานมากที่สุด</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {mockDeviceStats.map((device, index) => (
                <div key={device.device} className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                      <span className="text-sm font-bold text-blue-600">#{index + 1}</span>
                    </div>
                    <div>
                      <p className="font-medium">{device.device}</p>
                      <p className="text-sm text-gray-600">{device.users} ผู้ใช้</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">{device.percentage}%</p>
                    <div className="w-20 h-2 bg-gray-200 rounded-full mt-1">
                      <div className="h-2 bg-blue-500 rounded-full" style={{ width: `${device.percentage}%` }}></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Performance Metrics</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>App Launch Time</span>
                <span className="font-medium text-green-600">1.2s</span>
              </div>
              <Progress value={85} className="h-2" />
              <p className="text-xs text-gray-500 mt-1">เป้าหมาย: &lt; 1.5s</p>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Crash Rate</span>
                <span className="font-medium text-green-600">0.08%</span>
              </div>
              <Progress value={8} className="h-2" />
              <p className="text-xs text-gray-500 mt-1">เป้าหมาย: &lt; 0.1%</p>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Memory Usage</span>
                <span className="font-medium text-orange-600">145 MB</span>
              </div>
              <Progress value={72} className="h-2" />
              <p className="text-xs text-gray-500 mt-1">เป้าหมาย: &lt; 200 MB</p>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Battery Impact</span>
                <span className="font-medium text-green-600">Low</span>
              </div>
              <Progress value={25} className="h-2" />
              <p className="text-xs text-gray-500 mt-1">คะแนนจาก Apple/Google</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )

  // Push Notifications Management
  const PushNotifications = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-bold">Push Notifications</h3>
          <p className="text-gray-600">จัดการการแจ้งเตือนและแคมเปญการตลาด</p>
        </div>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          สร้างการแจ้งเตือนใหม่
        </Button>
      </div>

      {/* Notification Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">ส่งวันนี้</p>
                <p className="text-2xl font-bold text-blue-600">23</p>
              </div>
              <Send className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Open Rate</p>
                <p className="text-2xl font-bold text-green-600">24.5%</p>
              </div>
              <Eye className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Click Rate</p>
                <p className="text-2xl font-bold text-purple-600">8.2%</p>
              </div>
              <Target className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Subscribers</p>
                <p className="text-2xl font-bold text-orange-600">3,245</p>
              </div>
              <Bell className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Notifications List */}
      <Card>
        <CardHeader>
          <CardTitle>การแจ้งเตือนล่าสุด</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left p-4 font-medium">หัวข้อ</th>
                  <th className="text-left p-4 font-medium">กลุ่มเป้าหมาย</th>
                  <th className="text-left p-4 font-medium">กำหนดส่ง</th>
                  <th className="text-left p-4 font-medium">สถานะ</th>
                  <th className="text-left p-4 font-medium">ผลลัพธ์</th>
                  <th className="text-left p-4 font-medium">จัดการ</th>
                </tr>
              </thead>
              <tbody>
                {mockPushNotifications.map((notification) => (
                  <tr key={notification.id} className="border-t hover:bg-gray-50">
                    <td className="p-4">
                      <div>
                        <p className="font-medium">{notification.title}</p>
                        <p className="text-sm text-gray-600">{notification.message}</p>
                      </div>
                    </td>
                    <td className="p-4">
                      <Badge variant="outline">
                        {notification.audience === "all_users" && "ผู้ใช้ทั้งหมด"}
                        {notification.audience === "premium_customers" && "ลูกค้าพรีเมียม"}
                        {notification.audience === "new_users" && "ผู้ใช้ใหม่"}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <p className="text-sm">{notification.scheduled}</p>
                    </td>
                    <td className="p-4">
                      <Badge
                        variant={
                          notification.status === "sent"
                            ? "default"
                            : notification.status === "scheduled"
                              ? "secondary"
                              : "outline"
                        }
                      >
                        {notification.status === "sent" && "ส่งแล้ว"}
                        {notification.status === "scheduled" && "กำหนดส่ง"}
                        {notification.status === "draft" && "ร่าง"}
                      </Badge>
                    </td>
                    <td className="p-4">
                      {notification.status === "sent" ? (
                        <div className="text-sm">
                          <p>ส่งถึง: {notification.actualReach?.toLocaleString()}</p>
                          <p className="text-green-600">เปิด: {notification.openRate}%</p>
                          <p className="text-blue-600">คลิก: {notification.clickRate}%</p>
                        </div>
                      ) : (
                        <div className="text-sm text-gray-600">
                          <p>คาดว่าส่งถึง: {notification.estimatedReach?.toLocaleString()}</p>
                        </div>
                      )}
                    </td>
                    <td className="p-4">
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Edit className="h-4 w-4" />
                        </Button>
                        {notification.status === "scheduled" && (
                          <Button size="sm" variant="outline">
                            <Send className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Create Notification Form */}
      <Card>
        <CardHeader>
          <CardTitle>สร้างการแจ้งเตือนใหม่</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="notification-title">หัวข้อ</Label>
              <Input id="notification-title" placeholder="เช่น โปรโมชั่นพิเศษ" />
            </div>
            <div>
              <Label htmlFor="notification-audience">กลุ่มเป้าหมาย</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="เลือกกลุ่มเป้าหมาย" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all_users">ผู้ใช้ทั้งหมด</SelectItem>
                  <SelectItem value="premium_customers">ลูกค้าพรีเมียม</SelectItem>
                  <SelectItem value="new_users">ผู้ใช้ใหม่</SelectItem>
                  <SelectItem value="inactive_users">ผู้ใช้ไม่ใช้งาน</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <Label htmlFor="notification-message">ข้อความ</Label>
            <Textarea id="notification-message" placeholder="เขียนข้อความที่ต้องการส่ง..." rows={3} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="notification-date">วันที่ส่ง</Label>
              <Input id="notification-date" type="date" />
            </div>
            <div>
              <Label htmlFor="notification-time">เวลา</Label>
              <Input id="notification-time" type="time" />
            </div>
          </div>
          <div className="flex space-x-2">
            <Button>
              <Send className="h-4 w-4 mr-2" />
              ส่งทันที
            </Button>
            <Button variant="outline" className="bg-transparent">
              <Clock className="h-4 w-4 mr-2" />
              กำหนดเวลาส่ง
            </Button>
            <Button variant="outline" className="bg-transparent">
              บันทึกร่าง
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  // Crash Reports & Debugging
  const CrashReports = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-bold">Crash Reports & Debugging</h3>
          <p className="text-gray-600">ติดตามและแก้ไขปัญหาแอปพลิเคชั่น</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <RefreshCw className="h-4 w-4 mr-2" />
            รีเฟรชข้อมูล
          </Button>
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            ส่งออกรายงาน
          </Button>
        </div>
      </div>

      {/* Crash Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Crash Rate</p>
                <p className="text-2xl font-bold text-green-600">0.08%</p>
              </div>
              <Shield className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Active Issues</p>
                <p className="text-2xl font-bold text-orange-600">3</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Fixed This Week</p>
                <p className="text-2xl font-bold text-blue-600">7</p>
              </div>
              <CheckCircle className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Affected Users</p>
                <p className="text-2xl font-bold text-red-600">27</p>
              </div>
              <Users className="h-8 w-8 text-red-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Crash Reports Table */}
      <Card>
        <CardHeader>
          <CardTitle>รายงานข้อผิดพลาด</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left p-4 font-medium">ข้อผิดพลาด</th>
                  <th className="text-left p-4 font-medium">แพลตฟอร์ม</th>
                  <th className="text-left p-4 font-medium">เวอร์ชั่น</th>
                  <th className="text-left p-4 font-medium">เกิดขึ้น</th>
                  <th className="text-left p-4 font-medium">ผู้ใช้ที่ได้รับผลกระทบ</th>
                  <th className="text-left p-4 font-medium">สถานะ</th>
                  <th className="text-left p-4 font-medium">จัดการ</th>
                </tr>
              </thead>
              <tbody>
                {mockCrashReports.map((crash) => (
                  <tr key={crash.id} className="border-t hover:bg-gray-50">
                    <td className="p-4">
                      <div>
                        <p className="font-medium text-sm">{crash.error}</p>
                        <p className="text-xs text-gray-600">
                          เห็นครั้งแรก: {crash.firstSeen} | ล่าสุด: {crash.lastSeen}
                        </p>
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-2">
                        {crash.platform === "iOS" ? (
                          <Smartphone className="h-4 w-4 text-gray-600" />
                        ) : (
                          <Tablet className="h-4 w-4 text-green-600" />
                        )}
                        <span className="text-sm">{crash.platform}</span>
                      </div>
                    </td>
                    <td className="p-4">
                      <Badge variant="outline">{crash.version}</Badge>
                    </td>
                    <td className="p-4">
                      <p className="font-medium">{crash.occurrences}</p>
                    </td>
                    <td className="p-4">
                      <p className="font-medium">{crash.affectedUsers}</p>
                    </td>
                    <td className="p-4">
                      <Badge
                        variant={
                          crash.status === "fixed"
                            ? "default"
                            : crash.status === "investigating"
                              ? "secondary"
                              : "destructive"
                        }
                      >
                        {crash.status === "fixed" && "แก้ไขแล้ว"}
                        {crash.status === "investigating" && "กำลังตรวจสอบ"}
                        {crash.status === "open" && "เปิด"}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Code className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <CheckCircle className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Performance Monitoring */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Real-time Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Wifi className="h-4 w-4 text-blue-600" />
                  <span className="text-sm">Network Requests</span>
                </div>
                <div className="text-right">
                  <p className="font-medium">1,245/min</p>
                  <p className="text-xs text-green-600">+5.2%</p>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Battery className="h-4 w-4 text-green-600" />
                  <span className="text-sm">Battery Usage</span>
                </div>
                <div className="text-right">
                  <p className="font-medium">Low Impact</p>
                  <p className="text-xs text-green-600">Optimized</p>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Monitor className="h-4 w-4 text-purple-600" />
                  <span className="text-sm">Memory Usage</span>
                </div>
                <div className="text-right">
                  <p className="font-medium">145 MB</p>
                  <p className="text-xs text-orange-600">+12 MB</p>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Signal className="h-4 w-4 text-orange-600" />
                  <span className="text-sm">API Response Time</span>
                </div>
                <div className="text-right">
                  <p className="font-medium">245ms</p>
                  <p className="text-xs text-green-600">-15ms</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Error Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 bg-gradient-to-br from-red-50 to-orange-100 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <BarChart3 className="h-16 w-16 text-red-500 mx-auto mb-4" />
                <p className="text-gray-600">กราฟการกระจายตัวของข้อผิดพลาด</p>
                <p className="text-sm text-gray-500">แยกตามประเภทและความรุนแรง</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )

  // App Settings
  const AppSettings = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-bold">การตั้งค่าแอปพลิเคชั่น</h3>
        <p className="text-gray-600">จัดการการตั้งค่าและคอนฟิกแอป</p>
      </div>

      <Tabs defaultValue="general" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="general">ทั่วไป</TabsTrigger>
          <TabsTrigger value="features">ฟีเจอร์</TabsTrigger>
          <TabsTrigger value="api">API</TabsTrigger>
          <TabsTrigger value="security">ความปลอดภัย</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>การตั้งค่าทั่วไป</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="app-name">ชื่อแอป</Label>
                  <Input id="app-name" defaultValue="KDP Engineering" />
                </div>
                <div>
                  <Label htmlFor="app-version">เวอร์ชั่นปัจจุบัน</Label>
                  <Input id="app-version" defaultValue="2.1.0" disabled />
                </div>
                <div>
                  <Label htmlFor="min-ios">iOS ขั้นต่ำ</Label>
                  <Select defaultValue="ios13">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ios12">iOS 12.0</SelectItem>
                      <SelectItem value="ios13">iOS 13.0</SelectItem>
                      <SelectItem value="ios14">iOS 14.0</SelectItem>
                      <SelectItem value="ios15">iOS 15.0</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="min-android">Android ขั้นต่ำ</Label>
                  <Select defaultValue="android7">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="android6">Android 6.0</SelectItem>
                      <SelectItem value="android7">Android 7.0</SelectItem>
                      <SelectItem value="android8">Android 8.0</SelectItem>
                      <SelectItem value="android9">Android 9.0</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="features" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>ฟีเจอร์แอป</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <Switch id="push-notifications" defaultChecked />
                  <Label htmlFor="push-notifications">Push Notifications</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch id="offline-mode" defaultChecked />
                  <Label htmlFor="offline-mode">โหมดออฟไลน์</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch id="dark-mode" defaultChecked />
                  <Label htmlFor="dark-mode">โหมดมืด</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch id="biometric-auth" />
                  <Label htmlFor="biometric-auth">การยืนยันตัวตนด้วยลายนิ้วมือ</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch id="location-services" />
                  <Label htmlFor="location-services">บริการตำแหน่ง</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch id="analytics" defaultChecked />
                  <Label htmlFor="analytics">การวิเคราะห์การใช้งาน</Label>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="api" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>การตั้งค่า API</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="api-endpoint">API Endpoint</Label>
                <Input id="api-endpoint" defaultValue="https://api.kdp.co.th/v2" />
              </div>
              <div>
                <Label htmlFor="api-timeout">Timeout (วินาที)</Label>
                <Input id="api-timeout" type="number" defaultValue="30" />
              </div>
              <div>
                <Label htmlFor="retry-attempts">จำนวนครั้งที่ลองใหม่</Label>
                <Input id="retry-attempts" type="number" defaultValue="3" />
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="api-caching" defaultChecked />
                <Label htmlFor="api-caching">เปิดใช้งาน API Caching</Label>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>ความปลอดภัย</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Switch id="ssl-pinning" defaultChecked />
                <Label htmlFor="ssl-pinning">SSL Certificate Pinning</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="root-detection" defaultChecked />
                <Label htmlFor="root-detection">ตรวจจับอุปกรณ์ที่ถูก Root/Jailbreak</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="debug-detection" defaultChecked />
                <Label htmlFor="debug-detection">ตรวจจับการ Debug</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="screenshot-protection" />
                <Label htmlFor="screenshot-protection">ป้องกันการจับภาพหน้าจอ</Label>
              </div>
              <div>
                <Label htmlFor="session-timeout">Session Timeout (นาที)</Label>
                <Input id="session-timeout" type="number" defaultValue="30" />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center">
                <Smartphone className="h-8 w-8 mr-3 text-blue-600" />
                Mobile App Management
              </h1>
              <p className="text-gray-600 mt-2">จัดการแอปพลิเคชั่นมือถือแบบครบครัน</p>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                ดาวน์โหลด APK
              </Button>
              <Button variant="outline">
                <Globe className="h-4 w-4 mr-2" />
                App Store
              </Button>
              <Button>
                <Upload className="h-4 w-4 mr-2" />
                อัพโหลดเวอร์ชั่นใหม่
              </Button>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="overview" className="flex items-center space-x-2">
              <BarChart3 className="h-4 w-4" />
              <span>ภาพรวม</span>
            </TabsTrigger>
            <TabsTrigger value="notifications" className="flex items-center space-x-2">
              <Bell className="h-4 w-4" />
              <span>การแจ้งเตือน</span>
            </TabsTrigger>
            <TabsTrigger value="crashes" className="flex items-center space-x-2">
              <AlertTriangle className="h-4 w-4" />
              <span>รายงานข้อผิดพลาด</span>
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center space-x-2">
              <Settings className="h-4 w-4" />
              <span>ตั้งค่า</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <AppOverview />
          </TabsContent>

          <TabsContent value="notifications">
            <PushNotifications />
          </TabsContent>

          <TabsContent value="crashes">
            <CrashReports />
          </TabsContent>

          <TabsContent value="settings">
            <AppSettings />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
