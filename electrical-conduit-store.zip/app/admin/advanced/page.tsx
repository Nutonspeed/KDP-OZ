"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Checkbox } from "@/components/ui/checkbox"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import {
  LayoutDashboard,
  Package,
  ShoppingCart,
  Users,
  BarChart3,
  Settings,
  Search,
  Plus,
  Edit,
  Trash2,
  Eye,
  Download,
  RefreshCw,
  AlertTriangle,
  TrendingUp,
  DollarSign,
  Package2,
  Bell,
  FileText,
  Globe,
  Mail,
  Star,
  CheckCircle,
  XCircle,
  AlertCircle,
  Menu,
  X,
  LogOut,
  User,
  Shield,
  Database,
  Truck,
  MessageSquare,
  Clock,
  MapPin,
  Percent,
  Tag,
  Zap,
  Activity,
  Copy,
  Lock,
  Monitor,
  PieChart,
  Send,
  Target,
  UserPlus,
  MoreHorizontal,
  FileSpreadsheet,
  MessageCircle,
  LineChart,
  PieChartIcon,
  TrendingDown,
  Maximize,
  Cloud,
  Map,
} from "lucide-react"
import Image from "next/image"

// Extended mock data for comprehensive admin system
const mockUsers = [
  {
    id: 1,
    name: "Admin User",
    email: "admin@kdp.co.th",
    role: "super_admin",
    permissions: ["all"],
    status: "active",
    lastLogin: "2024-01-15 14:30",
    avatar: "/placeholder.svg?height=40&width=40&text=AU",
    department: "IT",
    phone: "02-123-4567",
    joinDate: "2023-01-01",
  },
  {
    id: 2,
    name: "Sales Manager",
    email: "sales@kdp.co.th",
    role: "sales_manager",
    permissions: ["orders", "customers", "products_read"],
    status: "active",
    lastLogin: "2024-01-15 13:45",
    avatar: "/placeholder.svg?height=40&width=40&text=SM",
    department: "Sales",
    phone: "02-123-4568",
    joinDate: "2023-02-15",
  },
  {
    id: 3,
    name: "Inventory Staff",
    email: "inventory@kdp.co.th",
    role: "inventory_staff",
    permissions: ["products", "inventory"],
    status: "active",
    lastLogin: "2024-01-15 12:20",
    avatar: "/placeholder.svg?height=40&width=40&text=IS",
    department: "Warehouse",
    phone: "02-123-4569",
    joinDate: "2023-03-01",
  },
]

const mockSuppliers = [
  {
    id: 1,
    name: "O-Z/Gedney USA",
    contact: "John Smith",
    email: "orders@ozgedney.com",
    phone: "+1-555-0123",
    address: "123 Industrial Ave, Houston, TX 77001",
    status: "active",
    rating: 4.8,
    totalOrders: 45,
    totalValue: 2500000,
    paymentTerms: "Net 30",
    leadTime: "14-21 days",
    currency: "USD",
  },
  {
    id: 2,
    name: "Local Distributor Co.",
    contact: "สมชาย ใจดี",
    email: "info@localdist.co.th",
    phone: "02-555-0123",
    address: "456 ถนนพระราม 4 กรุงเทพฯ 10500",
    status: "active",
    rating: 4.5,
    totalOrders: 28,
    totalValue: 850000,
    paymentTerms: "Net 15",
    leadTime: "3-5 days",
    currency: "THB",
  },
]

const mockPurchaseOrders = [
  {
    id: "PO-2024-001",
    supplier: "O-Z/Gedney USA",
    total: 125000,
    status: "pending",
    items: 15,
    orderDate: "2024-01-10",
    expectedDate: "2024-01-25",
    receivedDate: null,
    currency: "USD",
    exchangeRate: 35.5,
  },
  {
    id: "PO-2024-002",
    supplier: "Local Distributor Co.",
    total: 45000,
    status: "received",
    items: 8,
    orderDate: "2024-01-08",
    expectedDate: "2024-01-12",
    receivedDate: "2024-01-11",
    currency: "THB",
    exchangeRate: 1,
  },
]

const mockPromotions = [
  {
    id: 1,
    name: "ลดราคาสินค้า LB Series",
    type: "percentage",
    value: 15,
    code: "LB15OFF",
    startDate: "2024-01-01",
    endDate: "2024-01-31",
    status: "active",
    usageCount: 45,
    usageLimit: 100,
    minOrder: 5000,
    applicableProducts: ["LB-50G", "LB-75G", "LB-100G"],
  },
  {
    id: 2,
    name: "ซื้อครบ 10,000 ฟรีค่าส่ง",
    type: "free_shipping",
    value: 0,
    code: "FREESHIP10K",
    startDate: "2024-01-01",
    endDate: "2024-12-31",
    status: "active",
    usageCount: 128,
    usageLimit: null,
    minOrder: 10000,
    applicableProducts: [],
  },
]

const mockTickets = [
  {
    id: "TK-2024-001",
    subject: "สินค้าไม่ตรงตามที่สั่ง",
    customer: "บริษัท ABC จำกัด",
    priority: "high",
    status: "open",
    assignee: "Sales Manager",
    created: "2024-01-15 10:30",
    updated: "2024-01-15 14:20",
    category: "product_issue",
    description: "ได้รับสินค้า LB-75G แต่สั่ง LB-100G",
  },
  {
    id: "TK-2024-002",
    subject: "สอบถามราคาขายส่ง",
    customer: "คุณสมชาย ใจดี",
    priority: "medium",
    status: "in_progress",
    assignee: "Sales Manager",
    created: "2024-01-14 15:45",
    updated: "2024-01-15 09:15",
    category: "pricing",
    description: "ต้องการราคาพิเศษสำหรับการสั่งซื้อจำนวนมาก",
  },
]

const mockAuditLogs = [
  {
    id: 1,
    user: "Admin User",
    action: "UPDATE_PRODUCT",
    resource: "LB-75G",
    details: "Updated price from ฿350 to ฿360",
    timestamp: "2024-01-15 14:30:25",
    ip: "192.168.1.100",
    userAgent: "Mozilla/5.0...",
  },
  {
    id: 2,
    user: "Sales Manager",
    action: "CREATE_ORDER",
    resource: "ORD-2024-001",
    details: "Created new order for บริษัท ABC จำกัด",
    timestamp: "2024-01-15 13:45:12",
    ip: "192.168.1.101",
    userAgent: "Mozilla/5.0...",
  },
]

const mockIntegrations = [
  {
    id: 1,
    name: "LINE Notify",
    type: "notification",
    status: "connected",
    description: "แจ้งเตือนผ่าน LINE เมื่อมีคำสั่งซื้อใหม่",
    lastSync: "2024-01-15 14:30",
    config: { token: "***hidden***", channel: "orders" },
  },
  {
    id: 2,
    name: "Google Analytics",
    type: "analytics",
    status: "connected",
    description: "ติดตามการใช้งานเว็บไซต์",
    lastSync: "2024-01-15 14:25",
    config: { trackingId: "GA-123456789" },
  },
  {
    id: 3,
    name: "Facebook Pixel",
    type: "marketing",
    status: "disconnected",
    description: "ติดตามการแปลงจาก Facebook Ads",
    lastSync: null,
    config: {},
  },
]

export default function AdvancedAdminPanel() {
  const [activeTab, setActiveTab] = useState("dashboard")
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedItems, setSelectedItems] = useState<number[]>([])
  const [bulkAction, setBulkAction] = useState("")
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false)

  // Advanced Dashboard with Real-time Data
  const AdvancedDashboard = () => (
    <div className="space-y-6">
      {/* Real-time Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">ยอดขายวันนี้</p>
                <p className="text-2xl font-bold">฿125,450</p>
                <p className="text-xs text-green-600 flex items-center mt-1">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  +12.5% จากเมื่อวาน
                </p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <DollarSign className="h-6 w-6 text-green-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-green-400 to-green-600"></div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">คำสั่งซื้อใหม่</p>
                <p className="text-2xl font-bold">24</p>
                <p className="text-xs text-blue-600">รอดำเนินการ 8 รายการ</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <ShoppingCart className="h-6 w-6 text-blue-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-400 to-blue-600"></div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">ผู้เยี่ยมชมออนไลน์</p>
                <p className="text-2xl font-bold">156</p>
                <p className="text-xs text-purple-600">อัตราแปลง 3.2%</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                <Users className="h-6 w-6 text-purple-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-purple-400 to-purple-600"></div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">สินค้าเหลือน้อย</p>
                <p className="text-2xl font-bold">12</p>
                <p className="text-xs text-orange-600">ต้องสั่งซื้อเพิ่ม</p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                <AlertTriangle className="h-6 w-6 text-orange-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-orange-400 to-orange-600"></div>
          </CardContent>
        </Card>
      </div>

      {/* Advanced Analytics Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>ยอดขายรายเดือน</span>
              <Select defaultValue="6months">
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="3months">3 เดือน</SelectItem>
                  <SelectItem value="6months">6 เดือน</SelectItem>
                  <SelectItem value="1year">1 ปี</SelectItem>
                </SelectContent>
              </Select>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80 bg-gradient-to-br from-blue-50 to-indigo-100 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <BarChart3 className="h-16 w-16 text-blue-500 mx-auto mb-4" />
                <p className="text-gray-600">กราฟยอดขายรายเดือน</p>
                <p className="text-sm text-gray-500">แสดงแนวโน้มการเติบโต +15.2%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>สินค้าขายดี Top 10</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { code: "T-75G", sales: 145, revenue: 65250, growth: 12 },
                { code: "LB-75G", sales: 128, revenue: 46080, growth: 8 },
                { code: "BC-75G", sales: 95, revenue: 20425, growth: -2 },
                { code: "LB-100G", sales: 87, revenue: 48720, growth: 15 },
                { code: "T-100G", sales: 76, revenue: 51680, growth: 5 },
              ].map((item, index) => (
                <div key={item.code} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                      <span className="text-sm font-bold text-blue-600">#{index + 1}</span>
                    </div>
                    <div>
                      <p className="font-medium">{item.code}</p>
                      <p className="text-sm text-gray-600">{item.sales} ชิ้น</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">฿{item.revenue.toLocaleString()}</p>
                    <p className={`text-xs flex items-center ${item.growth >= 0 ? "text-green-600" : "text-red-600"}`}>
                      {item.growth >= 0 ? (
                        <TrendingUp className="h-3 w-3 mr-1" />
                      ) : (
                        <TrendingDown className="h-3 w-3 mr-1" />
                      )}
                      {Math.abs(item.growth)}%
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Real-time Activity Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>กิจกรรมแบบเรียลไทม์</span>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-sm text-gray-600">Live</span>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 max-h-80 overflow-y-auto">
              {[
                { type: "order", message: "คำสั่งซื้อใหม่ #ORD-2024-156 จาก บริษัท XYZ", time: "2 นาทีที่แล้ว", status: "new" },
                {
                  type: "payment",
                  message: "ได้รับชำระเงิน ORD-2024-155 จำนวน ฿15,750",
                  time: "5 นาทีที่แล้ว",
                  status: "success",
                },
                { type: "stock", message: "สินค้า LB-250G เหลือ 8 ชิ้น (ต่ำกว่าขั้นต่ำ)", time: "8 นาทีที่แล้ว", status: "warning" },
                { type: "user", message: "ผู้ใช้ใหม่ลงทะเบียน: somchai@email.com", time: "12 นาทีที่แล้ว", status: "info" },
                { type: "review", message: "รีวิวใหม่ 5 ดาว สำหรับ T-75G", time: "15 นาทีที่แล้ว", status: "positive" },
                { type: "support", message: "ตั๋วใหม่: สอบถามการจัดส่ง TK-2024-089", time: "18 นาทีที่แล้ว", status: "support" },
              ].map((activity, index) => (
                <div
                  key={index}
                  className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors"
                >
                  <div
                    className={`w-2 h-2 rounded-full mt-2 ${
                      activity.status === "new"
                        ? "bg-blue-500"
                        : activity.status === "success"
                          ? "bg-green-500"
                          : activity.status === "warning"
                            ? "bg-orange-500"
                            : activity.status === "positive"
                              ? "bg-purple-500"
                              : activity.status === "support"
                                ? "bg-red-500"
                                : "bg-gray-500"
                    }`}
                  />
                  <div className="flex-1">
                    <p className="text-sm">{activity.message}</p>
                    <p className="text-xs text-gray-500">{activity.time}</p>
                  </div>
                  <Button size="sm" variant="ghost" className="opacity-0 group-hover:opacity-100">
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>ประสิทธิภาพระบบ</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>CPU Usage</span>
                <span>45%</span>
              </div>
              <Progress value={45} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Memory</span>
                <span>62%</span>
              </div>
              <Progress value={62} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Storage</span>
                <span>78%</span>
              </div>
              <Progress value={78} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Network</span>
                <span>23%</span>
              </div>
              <Progress value={23} className="h-2" />
            </div>
            <Separator />
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span>Database</span>
                <Badge variant="outline" className="text-green-600 border-green-600">
                  Online
                </Badge>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span>Cache</span>
                <Badge variant="outline" className="text-green-600 border-green-600">
                  Healthy
                </Badge>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span>API</span>
                <Badge variant="outline" className="text-green-600 border-green-600">
                  Active
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )

  // Advanced User Management
  const UserManagement = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">จัดการผู้ใช้งาน</h2>
          <p className="text-gray-600">จัดการบัญชีผู้ใช้ สิทธิ์ และบทบาท</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            ส่งออกข้อมูล
          </Button>
          <Button>
            <UserPlus className="h-4 w-4 mr-2" />
            เพิ่มผู้ใช้
          </Button>
        </div>
      </div>

      {/* User Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">ผู้ใช้ทั้งหมด</p>
                <p className="text-2xl font-bold">12</p>
              </div>
              <Users className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">ออนไลน์</p>
                <p className="text-2xl font-bold text-green-600">8</p>
              </div>
              <Activity className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Admin</p>
                <p className="text-2xl font-bold text-purple-600">3</p>
              </div>
              <Shield className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">ล็อกอินวันนี้</p>
                <p className="text-2xl font-bold text-orange-600">9</p>
              </div>
              <Clock className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Users Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left p-4 font-medium">ผู้ใช้</th>
                  <th className="text-left p-4 font-medium">บทบาท</th>
                  <th className="text-left p-4 font-medium">แผนก</th>
                  <th className="text-left p-4 font-medium">สถานะ</th>
                  <th className="text-left p-4 font-medium">ล็อกอินล่าสุด</th>
                  <th className="text-left p-4 font-medium">สิทธิ์</th>
                  <th className="text-left p-4 font-medium">จัดการ</th>
                </tr>
              </thead>
              <tbody>
                {mockUsers.map((user) => (
                  <tr key={user.id} className="border-t hover:bg-gray-50">
                    <td className="p-4">
                      <div className="flex items-center space-x-3">
                        <Image
                          src={user.avatar || "/placeholder.svg"}
                          alt={user.name}
                          width={40}
                          height={40}
                          className="rounded-full"
                        />
                        <div>
                          <p className="font-medium">{user.name}</p>
                          <p className="text-sm text-gray-600">{user.email}</p>
                          <p className="text-xs text-gray-500">{user.phone}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-4">
                      <Badge variant={user.role === "super_admin" ? "default" : "outline"}>
                        {user.role === "super_admin" && "Super Admin"}
                        {user.role === "sales_manager" && "Sales Manager"}
                        {user.role === "inventory_staff" && "Inventory Staff"}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <span className="text-sm">{user.department}</span>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-2">
                        <div
                          className={`w-2 h-2 rounded-full ${user.status === "active" ? "bg-green-500" : "bg-gray-400"}`}
                        />
                        <Badge variant={user.status === "active" ? "default" : "secondary"}>
                          {user.status === "active" ? "ใช้งาน" : "ไม่ใช้งาน"}
                        </Badge>
                      </div>
                    </td>
                    <td className="p-4">
                      <p className="text-sm">{user.lastLogin}</p>
                    </td>
                    <td className="p-4">
                      <div className="flex flex-wrap gap-1">
                        {user.permissions.slice(0, 2).map((perm) => (
                          <Badge key={perm} variant="outline" className="text-xs">
                            {perm === "all" && "ทั้งหมด"}
                            {perm === "orders" && "คำสั่งซื้อ"}
                            {perm === "products" && "สินค้า"}
                            {perm === "customers" && "ลูกค้า"}
                          </Badge>
                        ))}
                        {user.permissions.length > 2 && (
                          <Badge variant="outline" className="text-xs">
                            +{user.permissions.length - 2}
                          </Badge>
                        )}
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Shield className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline" className="text-red-600 hover:text-red-700 bg-transparent">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Role Management */}
      <Card>
        <CardHeader>
          <CardTitle>จัดการบทบาทและสิทธิ์</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="border-2 border-blue-200">
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <Shield className="h-5 w-5 mr-2 text-blue-600" />
                  Super Admin
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-4">สิทธิ์เต็มในการจัดการระบบทั้งหมด</p>
                <div className="space-y-2">
                  {["จัดการผู้ใช้", "จัดการสินค้า", "จัดการคำสั่งซื้อ", "ดูรายงาน", "ตั้งค่าระบบ"].map((perm) => (
                    <div key={perm} className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span className="text-sm">{perm}</span>
                    </div>
                  ))}
                </div>
                <Button className="w-full mt-4" size="sm">
                  แก้ไขสิทธิ์
                </Button>
              </CardContent>
            </Card>

            <Card className="border-2 border-green-200">
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <Users className="h-5 w-5 mr-2 text-green-600" />
                  Sales Manager
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-4">จัดการคำสั่งซื้อและลูกค้า</p>
                <div className="space-y-2">
                  {[
                    { name: "จัดการคำสั่งซื้อ", allowed: true },
                    { name: "จัดการลูกค้า", allowed: true },
                    { name: "ดูสินค้า", allowed: true },
                    { name: "แก้ไขสินค้า", allowed: false },
                    { name: "ดูรายงาน", allowed: true },
                  ].map((perm) => (
                    <div key={perm.name} className="flex items-center space-x-2">
                      {perm.allowed ? (
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      ) : (
                        <XCircle className="h-4 w-4 text-red-600" />
                      )}
                      <span className="text-sm">{perm.name}</span>
                    </div>
                  ))}
                </div>
                <Button className="w-full mt-4 bg-transparent" size="sm" variant="outline">
                  แก้ไขสิทธิ์
                </Button>
              </CardContent>
            </Card>

            <Card className="border-2 border-orange-200">
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <Package className="h-5 w-5 mr-2 text-orange-600" />
                  Inventory Staff
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-4">จัดการสินค้าและคลังสินค้า</p>
                <div className="space-y-2">
                  {[
                    { name: "จัดการสินค้า", allowed: true },
                    { name: "จัดการคลังสินค้า", allowed: true },
                    { name: "ดูคำสั่งซื้อ", allowed: true },
                    { name: "แก้ไขคำสั่งซื้อ", allowed: false },
                    { name: "ดูรายงานสต็อก", allowed: true },
                  ].map((perm) => (
                    <div key={perm.name} className="flex items-center space-x-2">
                      {perm.allowed ? (
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      ) : (
                        <XCircle className="h-4 w-4 text-red-600" />
                      )}
                      <span className="text-sm">{perm.name}</span>
                    </div>
                  ))}
                </div>
                <Button className="w-full mt-4 bg-transparent" size="sm" variant="outline">
                  แก้ไขสิทธิ์
                </Button>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  // Advanced Inventory Management
  const InventoryManagement = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">จัดการคลังสินค้า</h2>
          <p className="text-gray-600">ติดตามสต็อก การสั่งซื้อ และซัพพลายเออร์</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <FileSpreadsheet className="h-4 w-4 mr-2" />
            นำเข้า Excel
          </Button>
          <Button variant="outline">
            <Truck className="h-4 w-4 mr-2" />
            สั่งซื้อใหม่
          </Button>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            เพิ่มซัพพลายเออร์
          </Button>
        </div>
      </div>

      <Tabs defaultValue="stock" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="stock">สต็อกสินค้า</TabsTrigger>
          <TabsTrigger value="suppliers">ซัพพลายเออร์</TabsTrigger>
          <TabsTrigger value="purchase-orders">ใบสั่งซื้อ</TabsTrigger>
          <TabsTrigger value="locations">ตำแหน่งเก็บ</TabsTrigger>
        </TabsList>

        <TabsContent value="stock" className="space-y-6">
          {/* Stock Overview */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">มูลค่าสต็อกรวม</p>
                    <p className="text-2xl font-bold">฿2.4M</p>
                  </div>
                  <DollarSign className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">สินค้าเหลือน้อย</p>
                    <p className="text-2xl font-bold text-orange-600">12</p>
                  </div>
                  <AlertTriangle className="h-8 w-8 text-orange-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">สินค้าหมด</p>
                    <p className="text-2xl font-bold text-red-600">3</p>
                  </div>
                  <XCircle className="h-8 w-8 text-red-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">อัตราหมุนเวียน</p>
                    <p className="text-2xl font-bold">4.2x</p>
                  </div>
                  <RefreshCw className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Stock Movement Chart */}
          <Card>
            <CardHeader>
              <CardTitle>การเคลื่อนไหวสต็อก</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64 bg-gradient-to-br from-green-50 to-blue-100 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <LineChart className="h-16 w-16 text-green-500 mx-auto mb-4" />
                  <p className="text-gray-600">กราฟการเคลื่อนไหวสต็อก</p>
                  <p className="text-sm text-gray-500">แสดงการเข้า-ออกสินค้ารายวัน</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="suppliers" className="space-y-6">
          {/* Suppliers Table */}
          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="text-left p-4 font-medium">ซัพพลายเออร์</th>
                      <th className="text-left p-4 font-medium">ติดต่อ</th>
                      <th className="text-left p-4 font-medium">คะแนน</th>
                      <th className="text-left p-4 font-medium">คำสั่งซื้อ</th>
                      <th className="text-left p-4 font-medium">มูลค่ารวม</th>
                      <th className="text-left p-4 font-medium">เงื่อนไข</th>
                      <th className="text-left p-4 font-medium">จัดการ</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mockSuppliers.map((supplier) => (
                      <tr key={supplier.id} className="border-t hover:bg-gray-50">
                        <td className="p-4">
                          <div>
                            <p className="font-medium">{supplier.name}</p>
                            <p className="text-sm text-gray-600">{supplier.address}</p>
                          </div>
                        </td>
                        <td className="p-4">
                          <div>
                            <p className="text-sm">{supplier.contact}</p>
                            <p className="text-sm text-gray-600">{supplier.email}</p>
                            <p className="text-sm text-gray-600">{supplier.phone}</p>
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center space-x-1">
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                            <span className="font-medium">{supplier.rating}</span>
                          </div>
                        </td>
                        <td className="p-4">
                          <p className="font-medium">{supplier.totalOrders}</p>
                        </td>
                        <td className="p-4">
                          <p className="font-medium">
                            {supplier.currency === "USD" ? "$" : "฿"}
                            {supplier.totalValue.toLocaleString()}
                          </p>
                        </td>
                        <td className="p-4">
                          <div>
                            <p className="text-sm">{supplier.paymentTerms}</p>
                            <p className="text-sm text-gray-600">{supplier.leadTime}</p>
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="flex space-x-2">
                            <Button size="sm" variant="outline">
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline">
                              <Mail className="h-4 w-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="purchase-orders" className="space-y-6">
          {/* Purchase Orders */}
          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="text-left p-4 font-medium">เลขที่ PO</th>
                      <th className="text-left p-4 font-medium">ซัพพลายเออร์</th>
                      <th className="text-left p-4 font-medium">มูลค่า</th>
                      <th className="text-left p-4 font-medium">สถานะ</th>
                      <th className="text-left p-4 font-medium">วันที่สั่ง</th>
                      <th className="text-left p-4 font-medium">กำหนดส่ง</th>
                      <th className="text-left p-4 font-medium">จัดการ</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mockPurchaseOrders.map((po) => (
                      <tr key={po.id} className="border-t hover:bg-gray-50">
                        <td className="p-4">
                          <div>
                            <p className="font-medium">{po.id}</p>
                            <p className="text-sm text-gray-600">{po.items} รายการ</p>
                          </div>
                        </td>
                        <td className="p-4">
                          <p className="text-sm">{po.supplier}</p>
                        </td>
                        <td className="p-4">
                          <div>
                            <p className="font-medium">
                              {po.currency === "USD" ? "$" : "฿"}
                              {po.total.toLocaleString()}
                            </p>
                            {po.currency === "USD" && (
                              <p className="text-xs text-gray-500">
                                ≈ ฿{(po.total * po.exchangeRate).toLocaleString()}
                              </p>
                            )}
                          </div>
                        </td>
                        <td className="p-4">
                          <Badge
                            variant={
                              po.status === "pending" ? "secondary" : po.status === "received" ? "default" : "outline"
                            }
                          >
                            {po.status === "pending" && "รอของ"}
                            {po.status === "received" && "ได้รับแล้ว"}
                            {po.status === "cancelled" && "ยกเลิก"}
                          </Badge>
                        </td>
                        <td className="p-4">
                          <p className="text-sm">{po.orderDate}</p>
                        </td>
                        <td className="p-4">
                          <p className="text-sm">{po.expectedDate}</p>
                          {po.receivedDate && <p className="text-xs text-green-600">รับ: {po.receivedDate}</p>}
                        </td>
                        <td className="p-4">
                          <div className="flex space-x-2">
                            <Button size="sm" variant="outline">
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline">
                              <FileText className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline">
                              <Truck className="h-4 w-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="locations" className="space-y-6">
          {/* Warehouse Locations */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MapPin className="h-5 w-5 mr-2" />
                  โซน A - อุปกรณ์หลัก
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm">ความจุ:</span>
                    <span className="text-sm font-medium">1,000 ชิ้น</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">ใช้แล้ว:</span>
                    <span className="text-sm font-medium">750 ชิ้น</span>
                  </div>
                  <Progress value={75} className="h-2" />
                  <div className="text-xs text-gray-500">A-01 ถึง A-20 (20 ชั้น)</div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MapPin className="h-5 w-5 mr-2" />
                  โซน B - อุปกรณ์เสริม
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm">ความจุ:</span>
                    <span className="text-sm font-medium">500 ชิ้น</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">ใช้แล้ว:</span>
                    <span className="text-sm font-medium">320 ชิ้น</span>
                  </div>
                  <Progress value={64} className="h-2" />
                  <div className="text-xs text-gray-500">B-01 ถึง B-15 (15 ชั้น)</div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MapPin className="h-5 w-5 mr-2" />
                  โซน C - สินค้าพิเศษ
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm">ความจุ:</span>
                    <span className="text-sm font-medium">200 ชิ้น</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">ใช้แล้ว:</span>
                    <span className="text-sm font-medium">45 ชิ้น</span>
                  </div>
                  <Progress value={22} className="h-2" />
                  <div className="text-xs text-gray-500">C-01 ถึง C-10 (10 ชั้น)</div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Location Map */}
          <Card>
            <CardHeader>
              <CardTitle>แผนผังคลังสินค้า</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-96 bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg flex items-center justify-center border-2 border-dashed border-gray-300">
                <div className="text-center">
                  <Map className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">แผนผังคลังสินค้า 3D</p>
                  <p className="text-sm text-gray-500">แสดงตำแหน่งสินค้าแบบเรียลไทม์</p>
                  <Button className="mt-4 bg-transparent" variant="outline">
                    <Eye className="h-4 w-4 mr-2" />
                    ดูแผนผัง 3D
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )

  // Promotions & Marketing Management
  const PromotionsManagement = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">จัดการโปรโมชั่น</h2>
          <p className="text-gray-600">สร้างและจัดการโปรโมชั่น ส่วนลด และแคมเปญการตลาด</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <BarChart3 className="h-4 w-4 mr-2" />
            รายงานประสิทธิภาพ
          </Button>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            สร้างโปรโมชั่น
          </Button>
        </div>
      </div>

      {/* Promotion Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">โปรโมชั่นใช้งาน</p>
                <p className="text-2xl font-bold text-green-600">8</p>
              </div>
              <Tag className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">ยอดลดรวม</p>
                <p className="text-2xl font-bold text-blue-600">฿45,200</p>
              </div>
              <Percent className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">การใช้งานวันนี้</p>
                <p className="text-2xl font-bold text-purple-600">23</p>
              </div>
              <TrendingUp className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">ROI เฉลี่ย</p>
                <p className="text-2xl font-bold text-orange-600">285%</p>
              </div>
              <Target className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Active Promotions */}
      <Card>
        <CardHeader>
          <CardTitle>โปรโมชั่นที่ใช้งานอยู่</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left p-4 font-medium">โปรโมชั่น</th>
                  <th className="text-left p-4 font-medium">ประเภท</th>
                  <th className="text-left p-4 font-medium">ส่วนลด</th>
                  <th className="text-left p-4 font-medium">ระยะเวลา</th>
                  <th className="text-left p-4 font-medium">การใช้งาน</th>
                  <th className="text-left p-4 font-medium">ประสิทธิภาพ</th>
                  <th className="text-left p-4 font-medium">จัดการ</th>
                </tr>
              </thead>
              <tbody>
                {mockPromotions.map((promo) => (
                  <tr key={promo.id} className="border-t hover:bg-gray-50">
                    <td className="p-4">
                      <div>
                        <p className="font-medium">{promo.name}</p>
                        <p className="text-sm text-gray-600">รหัส: {promo.code}</p>
                      </div>
                    </td>
                    <td className="p-4">
                      <Badge variant="outline">
                        {promo.type === "percentage" && "เปอร์เซ็นต์"}
                        {promo.type === "fixed" && "จำนวนคงที่"}
                        {promo.type === "free_shipping" && "ฟรีค่าส่ง"}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <p className="font-medium">
                        {promo.type === "percentage" && `${promo.value}%`}
                        {promo.type === "fixed" && `฿${promo.value}`}
                        {promo.type === "free_shipping" && "ฟรีค่าส่ง"}
                      </p>
                    </td>
                    <td className="p-4">
                      <div>
                        <p className="text-sm">{promo.startDate}</p>
                        <p className="text-sm text-gray-600">ถึง {promo.endDate}</p>
                      </div>
                    </td>
                    <td className="p-4">
                      <div>
                        <p className="font-medium">{promo.usageCount}</p>
                        {promo.usageLimit && <p className="text-sm text-gray-600">/ {promo.usageLimit}</p>}
                        {promo.usageLimit && (
                          <Progress value={(promo.usageCount / promo.usageLimit) * 100} className="h-1 mt-1" />
                        )}
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-1">
                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm font-medium">4.2</span>
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Copy className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Email Marketing */}
      <Card>
        <CardHeader>
          <CardTitle>Email Marketing</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="border-2 border-blue-200">
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <Mail className="h-5 w-5 mr-2 text-blue-600" />
                  Newsletter
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm">ผู้สมัครรับ:</span>
                    <span className="font-medium">1,245</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Open Rate:</span>
                    <span className="font-medium text-green-600">24.5%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Click Rate:</span>
                    <span className="font-medium text-blue-600">3.2%</span>
                  </div>
                  <Button className="w-full" size="sm">
                    <Send className="h-4 w-4 mr-2" />
                    ส่ง Newsletter
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="border-2 border-green-200">
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <Target className="h-5 w-5 mr-2 text-green-600" />
                  Targeted Campaigns
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm">แคมเปญใช้งาน:</span>
                    <span className="font-medium">3</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Conversion:</span>
                    <span className="font-medium text-green-600">8.7%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">ROI:</span>
                    <span className="font-medium text-purple-600">340%</span>
                  </div>
                  <Button className="w-full bg-transparent" size="sm" variant="outline">
                    <Plus className="h-4 w-4 mr-2" />
                    สร้างแคมเปญ
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="border-2 border-purple-200">
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <Zap className="h-5 w-5 mr-2 text-purple-600" />
                  Automation
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm">Auto Workflows:</span>
                    <span className="font-medium">5</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">ส่งวันนี้:</span>
                    <span className="font-medium text-blue-600">127</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Success Rate:</span>
                    <span className="font-medium text-green-600">94.2%</span>
                  </div>
                  <Button className="w-full bg-transparent" size="sm" variant="outline">
                    <Settings className="h-4 w-4 mr-2" />
                    ตั้งค่า Auto
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  // Customer Support & Ticketing
  const SupportManagement = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">ระบบสนับสนุนลูกค้า</h2>
          <p className="text-gray-600">จัดการตั๋วสนับสนุน แชท และการติดต่อลูกค้า</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <MessageCircle className="h-4 w-4 mr-2" />
            Live Chat
          </Button>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            ตั๋วใหม่
          </Button>
        </div>
      </div>

      {/* Support Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">ตั๋วเปิด</p>
                <p className="text-2xl font-bold text-orange-600">12</p>
              </div>
              <AlertCircle className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">เวลาตอบกลับเฉลี่ย</p>
                <p className="text-2xl font-bold text-blue-600">2.5h</p>
              </div>
              <Clock className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">ความพึงพอใจ</p>
                <p className="text-2xl font-bold text-green-600">4.8</p>
              </div>
              <Star className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">แก้ไขวันนี้</p>
                <p className="text-2xl font-bold text-purple-600">8</p>
              </div>
              <CheckCircle className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Support Tickets */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>ตั๋วสนับสนุน</span>
            <div className="flex space-x-2">
              <Select defaultValue="all">
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">ทั้งหมด</SelectItem>
                  <SelectItem value="open">เปิด</SelectItem>
                  <SelectItem value="in_progress">กำลังดำเนินการ</SelectItem>
                  <SelectItem value="resolved">แก้ไขแล้ว</SelectItem>
                </SelectContent>
              </Select>
              <Select defaultValue="all_priority">
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all_priority">ทุกระดับ</SelectItem>
                  <SelectItem value="high">สูง</SelectItem>
                  <SelectItem value="medium">กลาง</SelectItem>
                  <SelectItem value="low">ต่ำ</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left p-4 font-medium">ตั๋ว</th>
                  <th className="text-left p-4 font-medium">ลูกค้า</th>
                  <th className="text-left p-4 font-medium">หมวดหมู่</th>
                  <th className="text-left p-4 font-medium">ความสำคัญ</th>
                  <th className="text-left p-4 font-medium">สถานะ</th>
                  <th className="text-left p-4 font-medium">ผู้รับผิดชอบ</th>
                  <th className="text-left p-4 font-medium">อัพเดท</th>
                  <th className="text-left p-4 font-medium">จัดการ</th>
                </tr>
              </thead>
              <tbody>
                {mockTickets.map((ticket) => (
                  <tr key={ticket.id} className="border-t hover:bg-gray-50">
                    <td className="p-4">
                      <div>
                        <p className="font-medium">{ticket.id}</p>
                        <p className="text-sm text-gray-600">{ticket.subject}</p>
                      </div>
                    </td>
                    <td className="p-4">
                      <p className="text-sm">{ticket.customer}</p>
                    </td>
                    <td className="p-4">
                      <Badge variant="outline">
                        {ticket.category === "product_issue" && "ปัญหาสินค้า"}
                        {ticket.category === "pricing" && "ราคา"}
                        {ticket.category === "shipping" && "การจัดส่ง"}
                        {ticket.category === "technical" && "เทคนิค"}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <Badge
                        variant={
                          ticket.priority === "high"
                            ? "destructive"
                            : ticket.priority === "medium"
                              ? "secondary"
                              : "outline"
                        }
                      >
                        {ticket.priority === "high" && "สูง"}
                        {ticket.priority === "medium" && "กลาง"}
                        {ticket.priority === "low" && "ต่ำ"}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <Badge
                        variant={
                          ticket.status === "open"
                            ? "secondary"
                            : ticket.status === "in_progress"
                              ? "default"
                              : "outline"
                        }
                      >
                        {ticket.status === "open" && "เปิด"}
                        {ticket.status === "in_progress" && "กำลังดำเนินการ"}
                        {ticket.status === "resolved" && "แก้ไขแล้ว"}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <p className="text-sm">{ticket.assignee}</p>
                    </td>
                    <td className="p-4">
                      <p className="text-sm">{ticket.updated}</p>
                    </td>
                    <td className="p-4">
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <MessageCircle className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <CheckCircle className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Live Chat Interface */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Live Chat</span>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-sm text-gray-600">5 แชทใช้งาน</span>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 max-h-80 overflow-y-auto">
              {[
                { customer: "คุณสมชาย", message: "สอบถามราคา LB-100G ครับ", time: "14:30", unread: true },
                { customer: "บริษัท ABC", message: "ต้องการใบเสนอราคาด่วน", time: "14:25", unread: true },
                { customer: "คุณมาลี", message: "สินค้าส่งมาถึงแล้วครับ ขอบคุณ", time: "14:20", unread: false },
                { customer: "โรงงาน XYZ", message: "มีสินค้าใหม่เข้ามาไหมครับ", time: "14:15", unread: false },
              ].map((chat, index) => (
                <div
                  key={index}
                  className={`flex items-center justify-between p-3 rounded-lg cursor-pointer hover:bg-gray-50 ${chat.unread ? "bg-blue-50 border-l-4 border-blue-500" : "bg-gray-50"}`}
                >
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <User className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium text-sm">{chat.customer}</p>
                      <p className="text-sm text-gray-600">{chat.message}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-gray-500">{chat.time}</p>
                    {chat.unread && <div className="w-2 h-2 bg-blue-500 rounded-full mt-1 ml-auto"></div>}
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-4 flex space-x-2">
              <Input placeholder="พิมพ์ข้อความ..." className="flex-1" />
              <Button>
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Quick Responses</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {[
                "สวัสดีครับ มีอะไรให้ช่วยไหมครับ",
                "ขอบคุณสำหรับการติดต่อ",
                "รอสักครู่นะครับ กำลังตรวจสอบให้",
                "ส่งใบเสนอราคาให้แล้วครับ",
                "สินค้ามีพร้อมส่งครับ",
                "ขอโทษครับ สินค้าหมดชั่วคราว",
              ].map((response, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  className="w-full text-left justify-start text-xs bg-transparent"
                >
                  {response}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )

  // Advanced Analytics & Reports
  const AdvancedAnalytics = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">รายงานและการวิเคราะห์ขั้นสูง</h2>
          <p className="text-gray-600">ข้อมูลเชิงลึกและรายงานแบบครบครัน</p>
        </div>
        <div className="flex space-x-2">
          <Select defaultValue="30days">
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7days">7 วันที่ผ่านมา</SelectItem>
              <SelectItem value="30days">30 วันที่ผ่านมา</SelectItem>
              <SelectItem value="90days">90 วันที่ผ่านมา</SelectItem>
              <SelectItem value="1year">1 ปีที่ผ่านมา</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            ส่งออกรายงาน
          </Button>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            รายงานใหม่
          </Button>
        </div>
      </div>

      {/* Advanced KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Revenue Growth</p>
                <p className="text-2xl font-bold">+15.2%</p>
                <p className="text-xs text-green-600 flex items-center mt-1">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  vs เดือนที่แล้ว
                </p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <TrendingUp className="h-6 w-6 text-green-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-green-400 to-green-600"></div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Customer LTV</p>
                <p className="text-2xl font-bold">฿125,450</p>
                <p className="text-xs text-blue-600">เฉลี่ย 18 เดือน</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <Users className="h-6 w-6 text-blue-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-400 to-blue-600"></div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Inventory Turnover</p>
                <p className="text-2xl font-bold">4.2x</p>
                <p className="text-xs text-purple-600">ดีกว่าเป้า 3.8x</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                <RefreshCw className="h-6 w-6 text-purple-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-purple-400 to-purple-600"></div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Profit Margin</p>
                <p className="text-2xl font-bold">28.5%</p>
                <p className="text-xs text-orange-600">+2.1% จากเดือนที่แล้ว</p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                <PieChart className="h-6 w-6 text-orange-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-orange-400 to-orange-600"></div>
          </CardContent>
        </Card>
      </div>

      {/* Advanced Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Revenue vs Profit Analysis</span>
              <Button variant="outline" size="sm">
                <Maximize className="h-4 w-4" />
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80 bg-gradient-to-br from-blue-50 to-purple-100 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <BarChart3 className="h-16 w-16 text-blue-500 mx-auto mb-4" />
                <p className="text-gray-600">กราฟเปรียบเทียบรายได้และกำไร</p>
                <p className="text-sm text-gray-500">แสดงแนวโน้มรายเดือน</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Customer Segmentation</span>
              <Button variant="outline" size="sm">
                <Maximize className="h-4 w-4" />
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80 bg-gradient-to-br from-green-50 to-teal-100 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <PieChartIcon className="h-16 w-16 text-green-500 mx-auto mb-4" />
                <p className="text-gray-600">การแบ่งกลุ่มลูกค้า</p>
                <p className="text-sm text-gray-500">ตาม RFM Analysis</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Reports */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Product Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { product: "T-75G", revenue: 125000, growth: 15, margin: 32 },
                { product: "LB-75G", revenue: 98000, growth: 8, margin: 28 },
                { product: "BC-75G", revenue: 75000, growth: -2, margin: 35 },
                { product: "LB-100G", revenue: 68000, growth: 12, margin: 30 },
                { product: "T-100G", revenue: 55000, growth: 5, margin: 29 },
              ].map((item, index) => (
                <div key={item.product} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium">{item.product}</p>
                    <p className="text-sm text-gray-600">฿{item.revenue.toLocaleString()}</p>
                  </div>
                  <div className="text-right">
                    <p className={`text-sm font-medium ${item.growth >= 0 ? "text-green-600" : "text-red-600"}`}>
                      {item.growth >= 0 ? "+" : ""}
                      {item.growth}%
                    </p>
                    <p className="text-xs text-gray-500">Margin: {item.margin}%</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Customer Insights</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-3 bg-blue-50 rounded-lg">
                <p className="text-sm font-medium text-blue-800">New Customers</p>
                <p className="text-2xl font-bold text-blue-600">23</p>
                <p className="text-xs text-blue-600">+15% จากเดือนที่แล้ว</p>
              </div>
              <div className="p-3 bg-green-50 rounded-lg">
                <p className="text-sm font-medium text-green-800">Repeat Customers</p>
                <p className="text-2xl font-bold text-green-600">67%</p>
                <p className="text-xs text-green-600">เพิ่มขึ้น 5%</p>
              </div>
              <div className="p-3 bg-purple-50 rounded-lg">
                <p className="text-sm font-medium text-purple-800">Avg Order Value</p>
                <p className="text-2xl font-bold text-purple-600">฿15,750</p>
                <p className="text-xs text-purple-600">+8% จากเดือนที่แล้ว</p>
              </div>
              <div className="p-3 bg-orange-50 rounded-lg">
                <p className="text-sm font-medium text-orange-800">Churn Rate</p>
                <p className="text-2xl font-bold text-orange-600">2.3%</p>
                <p className="text-xs text-orange-600">ลดลง 0.5%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Operational Metrics</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Order Fulfillment Rate</span>
                  <span className="font-medium text-green-600">98.5%</span>
                </div>
                <Progress value={98.5} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>On-time Delivery</span>
                  <span className="font-medium text-blue-600">94.2%</span>
                </div>
                <Progress value={94.2} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Customer Satisfaction</span>
                  <span className="font-medium text-purple-600">4.8/5</span>
                </div>
                <Progress value={96} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Return Rate</span>
                  <span className="font-medium text-orange-600">1.2%</span>
                </div>
                <Progress value={1.2} className="h-2" />
              </div>
              <Separator />
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Avg Response Time</span>
                  <span className="font-medium">2.5h</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>First Call Resolution</span>
                  <span className="font-medium">87%</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Support Tickets</span>
                  <span className="font-medium">12 open</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )

  // System Settings & Configuration
  const SystemSettings = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">ตั้งค่าระบบขั้นสูง</h2>
          <p className="text-gray-600">จัดการการตั้งค่าระบบ การรักษาความปลอดภัย และการสำรองข้อมูล</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <Database className="h-4 w-4 mr-2" />
            สำรองข้อมูล
          </Button>
          <Button variant="outline">
            <Activity className="h-4 w-4 mr-2" />
            ตรวจสอบระบบ
          </Button>
        </div>
      </div>

      <Tabs defaultValue="general" className="w-full">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="general">ทั่วไป</TabsTrigger>
          <TabsTrigger value="security">ความปลอดภัย</TabsTrigger>
          <TabsTrigger value="integrations">การเชื่อมต่อ</TabsTrigger>
          <TabsTrigger value="backup">สำรองข้อมูล</TabsTrigger>
          <TabsTrigger value="logs">บันทึกการใช้งาน</TabsTrigger>
          <TabsTrigger value="maintenance">บำรุงรักษา</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>การตั้งค่าทั่วไป</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="site-name">ชื่อเว็บไซต์</Label>
                  <Input id="site-name" defaultValue="KDP Engineering & Supply" />
                </div>
                <div>
                  <Label htmlFor="admin-email">อีเมลผู้ดูแลระบบ</Label>
                  <Input id="admin-email" defaultValue="admin@kdp.co.th" />
                </div>
                <div>
                  <Label htmlFor="timezone">เขตเวลา</Label>
                  <Select defaultValue="asia-bangkok">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="asia-bangkok">Asia/Bangkok (UTC+7)</SelectItem>
                      <SelectItem value="utc">UTC (UTC+0)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="currency">สกุลเงินหลัก</Label>
                  <Select defaultValue="thb">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="thb">THB (บาท)</SelectItem>
                      <SelectItem value="usd">USD (ดอลลาร์)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h4 className="font-medium">การตั้งค่าการแสดงผล</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center space-x-2">
                    <Switch id="dark-mode" />
                    <Label htmlFor="dark-mode">โหมดมืด</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="compact-view" />
                    <Label htmlFor="compact-view">มุมมองกะทัดรัด</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="animations" defaultChecked />
                    <Label htmlFor="animations">แอนิเมชั่น</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="sound-notifications" />
                    <Label htmlFor="sound-notifications">เสียงแจ้งเตือน</Label>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>การรักษาความปลอดภัย</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="border-2 border-green-200">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center">
                      <Shield className="h-5 w-5 mr-2 text-green-600" />
                      Two-Factor Authentication
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">เพิ่มความปลอดภัยด้วย 2FA</p>
                    <div className="flex items-center space-x-2 mb-4">
                      <Switch id="2fa" defaultChecked />
                      <Label htmlFor="2fa">เปิดใช้งาน 2FA</Label>
                    </div>
                    <Button size="sm" variant="outline">
                      <Settings className="h-4 w-4 mr-2" />
                      ตั้งค่า 2FA
                    </Button>
                  </CardContent>
                </Card>

                <Card className="border-2 border-blue-200">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center">
                      <Lock className="h-5 w-5 mr-2 text-blue-600" />
                      Password Policy
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">กำหนดนโยบายรหัสผ่าน</p>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Checkbox id="min-length" defaultChecked />
                        <Label htmlFor="min-length" className="text-sm">
                          ความยาวขั้นต่ำ 8 ตัวอักษร
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="special-chars" defaultChecked />
                        <Label htmlFor="special-chars" className="text-sm">
                          ต้องมีอักขระพิเศษ
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="numbers" defaultChecked />
                        <Label htmlFor="numbers" className="text-sm">
                          ต้องมีตัวเลข
                        </Label>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-2 border-orange-200">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center">
                      <Activity className="h-5 w-5 mr-2 text-orange-600" />
                      Session Management
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">จัดการเซสชั่นผู้ใช้</p>
                    <div className="space-y-3">
                      <div>
                        <Label htmlFor="session-timeout">หมดเวลาเซสชั่น (นาที)</Label>
                        <Input id="session-timeout" type="number" defaultValue="30" />
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch id="concurrent-sessions" />
                        <Label htmlFor="concurrent-sessions" className="text-sm">
                          อนุญาตหลายเซสชั่น
                        </Label>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-2 border-red-200">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center">
                      <AlertTriangle className="h-5 w-5 mr-2 text-red-600" />
                      IP Restrictions
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">จำกัด IP ที่เข้าถึงได้</p>
                    <div className="space-y-3">
                      <div className="flex items-center space-x-2">
                        <Switch id="ip-whitelist" />
                        <Label htmlFor="ip-whitelist" className="text-sm">
                          เปิดใช้ IP Whitelist
                        </Label>
                      </div>
                      <Textarea placeholder="192.168.1.0/24&#10;10.0.0.0/8" rows={3} />
                      <Button size="sm" variant="outline">
                        <Plus className="h-4 w-4 mr-2" />
                        เพิ่ม IP
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="integrations" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>การเชื่อมต่อระบบภายนอก</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockIntegrations.map((integration) => (
                  <div key={integration.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div
                        className={`w-12 h-12 rounded-full flex items-center justify-center ${
                          integration.status === "connected" ? "bg-green-100" : "bg-gray-100"
                        }`}
                      >
                        {integration.type === "notification" && <Bell className="h-6 w-6 text-green-600" />}
                        {integration.type === "analytics" && <BarChart3 className="h-6 w-6 text-blue-600" />}
                        {integration.type === "marketing" && <Target className="h-6 w-6 text-purple-600" />}
                      </div>
                      <div>
                        <h4 className="font-medium">{integration.name}</h4>
                        <p className="text-sm text-gray-600">{integration.description}</p>
                        {integration.lastSync && (
                          <p className="text-xs text-gray-500">ซิงค์ล่าสุด: {integration.lastSync}</p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant={integration.status === "connected" ? "default" : "secondary"}>
                        {integration.status === "connected" ? "เชื่อมต่อแล้ว" : "ไม่ได้เชื่อมต่อ"}
                      </Badge>
                      <Button size="sm" variant="outline">
                        <Settings className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>

              <Separator className="my-6" />

              <div>
                <h4 className="font-medium mb-4">เชื่อมต่อใหม่</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[
                    { name: "Shopee", icon: "🛒", type: "marketplace" },
                    { name: "Lazada", icon: "🛍️", type: "marketplace" },
                    { name: "Facebook Shop", icon: "📘", type: "social" },
                    { name: "Google Merchant", icon: "🔍", type: "advertising" },
                  ].map((service) => (
                    <Card key={service.name} className="cursor-pointer hover:shadow-md transition-shadow">
                      <CardContent className="p-4 text-center">
                        <div className="text-2xl mb-2">{service.icon}</div>
                        <p className="font-medium">{service.name}</p>
                        <p className="text-xs text-gray-500">{service.type}</p>
                        <Button size="sm" className="mt-2 bg-transparent" variant="outline">
                          เชื่อมต่อ
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="backup" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>การสำรองข้อมูล</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="border-2 border-green-200">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center">
                      <Database className="h-5 w-5 mr-2 text-green-600" />
                      Auto Backup
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center space-x-2">
                        <Switch id="auto-backup" defaultChecked />
                        <Label htmlFor="auto-backup">เปิดใช้งาน</Label>
                      </div>
                      <div>
                        <Label htmlFor="backup-frequency">ความถี่</Label>
                        <Select defaultValue="daily">
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="hourly">ทุกชั่วโมง</SelectItem>
                            <SelectItem value="daily">ทุกวัน</SelectItem>
                            <SelectItem value="weekly">ทุกสัปดาห์</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="backup-time">เวลา</Label>
                        <Input id="backup-time" type="time" defaultValue="02:00" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-2 border-blue-200">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center">
                      <Cloud className="h-5 w-5 mr-2 text-blue-600" />
                      Cloud Storage
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div>
                        <Label htmlFor="cloud-provider">ผู้ให้บริการ</Label>
                        <Select defaultValue="aws">
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="aws">Amazon S3</SelectItem>
                            <SelectItem value="gcp">Google Cloud</SelectItem>
                            <SelectItem value="azure">Azure Storage</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="retention">เก็บไว้ (วัน)</Label>
                        <Input id="retention" type="number" defaultValue="30" />
                      </div>
                      <Button size="sm" variant="outline" className="w-full bg-transparent">
                        <Settings className="h-4 w-4 mr-2" />
                        ตั้งค่า
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-2 border-purple-200">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center">
                      <RefreshCw className="h-5 w-5 mr-2 text-purple-600" />
                      Restore
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <p className="text-sm text-gray-600">กู้คืนข้อมูลจากการสำรอง</p>
                      <div>
                        <Label htmlFor="restore-point">จุดกู้คืน</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="เลือกจุดกู้คืน" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="2024-01-15">2024-01-15 02:00</SelectItem>
                            <SelectItem value="2024-01-14">2024-01-14 02:00</SelectItem>
                            <SelectItem value="2024-01-13">2024-01-13 02:00</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <Button size="sm" variant="outline" className="w-full bg-transparent">
                        <Download className="h-4 w-4 mr-2" />
                        กู้คืน
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>ประวัติการสำรองข้อมูล</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {[
                      { date: "2024-01-15 02:00", size: "245 MB", status: "success", type: "auto" },
                      { date: "2024-01-14 02:00", size: "243 MB", status: "success", type: "auto" },
                      { date: "2024-01-13 15:30", size: "241 MB", status: "success", type: "manual" },
                      { date: "2024-01-13 02:00", size: "240 MB", status: "failed", type: "auto" },
                      { date: "2024-01-12 02:00", size: "238 MB", status: "success", type: "auto" },
                    ].map((backup, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div
                            className={`w-2 h-2 rounded-full ${
                              backup.status === "success" ? "bg-green-500" : "bg-red-500"
                            }`}
                          />
                          <div>
                            <p className="font-medium text-sm">{backup.date}</p>
                            <p className="text-xs text-gray-600">
                              {backup.size} • {backup.type === "auto" ? "อัตโนมัติ" : "ด้วยตนเอง"}
                            </p>
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <Badge variant={backup.status === "success" ? "default" : "destructive"}>
                            {backup.status === "success" ? "สำเร็จ" : "ล้มเหลว"}
                          </Badge>
                          {backup.status === "success" && (
                            <Button size="sm" variant="outline">
                              <Download className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="logs" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>บันทึกการใช้งานระบบ</span>
                <div className="flex space-x-2">
                  <Select defaultValue="all">
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">ทั้งหมด</SelectItem>
                      <SelectItem value="login">เข้าสู่ระบบ</SelectItem>
                      <SelectItem value="product">สินค้า</SelectItem>
                      <SelectItem value="order">คำสั่งซื้อ</SelectItem>
                      <SelectItem value="user">ผู้ใช้</SelectItem>
                      <SelectItem value="system">ระบบ</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="outline" size="sm">
                    <Download className="h-4 w-4 mr-2" />
                    ส่งออก
                  </Button>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {mockAuditLogs.map((log) => (
                  <div key={log.id} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg">
                    <div
                      className={`w-2 h-2 rounded-full mt-2 ${
                        log.action.includes("CREATE")
                          ? "bg-green-500"
                          : log.action.includes("UPDATE")
                            ? "bg-blue-500"
                            : log.action.includes("DELETE")
                              ? "bg-red-500"
                              : "bg-gray-500"
                      }`}
                    />
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <p className="font-medium text-sm">{log.user}</p>
                        <p className="text-xs text-gray-500">{log.timestamp}</p>
                      </div>
                      <p className="text-sm text-gray-600">{log.details}</p>
                      <div className="flex items-center space-x-4 mt-1">
                        <Badge variant="outline" className="text-xs">
                          {log.action.replace("_", " ")}
                        </Badge>
                        <span className="text-xs text-gray-500">IP: {log.ip}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="maintenance" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>การบำรุงรักษาระบบ</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="border-2 border-blue-200">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center">
                      <Monitor className="h-5 w-5 mr-2 text-blue-600" />
                      System Health
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Database</span>
                        <Badge variant="outline" className="text-green-600 border-green-600">
                          Healthy
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Web Server</span>
                        <Badge variant="outline" className="text-green-600 border-green-600">
                          Running
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Cache</span>
                        <Badge variant="outline" className="text-green-600 border-green-600">
                          Active
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Storage</span>
                        <Badge variant="outline" className="text-orange-600 border-orange-600">
                          78% Full
                        </Badge>
                      </div>
                      <Button size="sm" variant="outline" className="w-full bg-transparent">
                        <Activity className="h-4 w-4 mr-2" />
                        รันการตรวจสอบ
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-2 border-orange-200">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center">
                      <Settings className="h-5 w-5 mr-2 text-orange-600" />
                      Maintenance Mode
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <p className="text-sm text-gray-600">เปิดโหมดปิดปรับปรุงเพื่อบำรุงรักษาระบบ</p>
                      <div className="flex items-center space-x-2">
                        <Switch id="maintenance-mode" />
                        <Label htmlFor="maintenance-mode">เปิดโหมดปิดปรับปรุง</Label>
                      </div>
                      <div>
                        <Label htmlFor="maintenance-message">ข้อความแจ้งเตือน</Label>
                        <Textarea
                          id="maintenance-message"
                          placeholder="ระบบอยู่ระหว่างการปรับปรุง กรุณาลองใหม่ภายหลัง"
                          rows={3}
                        />
                      </div>
                      <div>
                        <Label htmlFor="maintenance-duration">ระยะเวลาโดยประมาณ</Label>
                        <Input id="maintenance-duration" placeholder="เช่น 2 ชั่วโมง" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>การทำความสะอาดระบบ</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-medium mb-2">ล้างแคช</h4>
                      <p className="text-sm text-gray-600 mb-3">ล้างแคชทั้งหมดเพื่อปรับปรุงประสิทธิภาพ</p>
                      <Button size="sm" variant="outline" className="w-full bg-transparent">
                        <RefreshCw className="h-4 w-4 mr-2" />
                        ล้างแคช
                      </Button>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-medium mb-2">ล้างบันทึก</h4>
                      <p className="text-sm text-gray-600 mb-3">ลบบันทึกเก่าที่เกิน 30 วัน</p>
                      <Button size="sm" variant="outline" className="w-full bg-transparent">
                        <Trash2 className="h-4 w-4 mr-2" />
                        ล้างบันทึก
                      </Button>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-medium mb-2">ปรับปรุงฐานข้อมูล</h4>
                      <p className="text-sm text-gray-600 mb-3">เพิ่มประสิทธิภาพฐานข้อมูล</p>
                      <Button size="sm" variant="outline" className="w-full bg-transparent">
                        <Database className="h-4 w-4 mr-2" />
                        ปรับปรุง DB
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>การอัพเดทระบบ</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                      <div>
                        <p className="font-medium">เวอร์ชั่นปัจจุบัน: v2.1.0</p>
                        <p className="text-sm text-gray-600">อัพเดทล่าสุด: 2024-01-01</p>
                      </div>
                      <Button variant="outline">
                        <Download className="h-4 w-4 mr-2" />
                        ตรวจสอบอัพเดท
                      </Button>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-medium mb-2">อัพเดทที่พร้อมใช้งาน</h4>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm">v2.1.1 - Bug fixes และปรับปรุงประสิทธิภาพ</span>
                          <Button size="sm">อัพเดท</Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )

  // Main Sidebar Component
  const Sidebar = () => (
    <div
      className={`bg-gray-900 text-white h-screen fixed left-0 top-0 z-50 transition-all duration-300 ${sidebarOpen ? "w-64" : "w-16"} overflow-y-auto`}
    >
      <div className="p-4">
        <div className="flex items-center justify-between">
          <div className={`flex items-center space-x-2 ${!sidebarOpen && "hidden"}`}>
            <Package2 className="h-8 w-8 text-blue-400" />
            <h1 className="text-xl font-bold">KDP Admin Pro</h1>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="text-white hover:bg-gray-800"
          >
            {sidebarOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </Button>
        </div>
      </div>

      <nav className="mt-8">
        <div className="px-4 space-y-2">
          {[
            { id: "dashboard", label: "แดชบอร์ด", icon: LayoutDashboard, badge: null },
            { id: "users", label: "จัดการผู้ใช้", icon: Users, badge: "3" },
            { id: "inventory", label: "คลังสินค้า", icon: Package, badge: "12" },
            { id: "promotions", label: "โปรโมชั่น", icon: Tag, badge: null },
            { id: "support", label: "ฝ่ายสนับสนุน", icon: MessageSquare, badge: "5" },
            { id: "analytics", label: "รายงานขั้นสูง", icon: BarChart3, badge: null },
            { id: "settings", label: "ตั้งค่าระบบ", icon: Settings, badge: null },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg transition-colors ${
                activeTab === item.id ? "bg-blue-600 text-white" : "text-gray-300 hover:bg-gray-800 hover:text-white"
              }`}
            >
              <div className="flex items-center space-x-3">
                <item.icon className="h-5 w-5" />
                {sidebarOpen && <span>{item.label}</span>}
              </div>
              {sidebarOpen && item.badge && <Badge className="bg-red-500 text-white">{item.badge}</Badge>}
            </button>
          ))}
        </div>
      </nav>

      <div className="absolute bottom-4 left-4 right-4">
        <div className={`flex items-center space-x-3 p-3 bg-gray-800 rounded-lg ${!sidebarOpen && "justify-center"}`}>
          <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
            <User className="h-4 w-4 text-white" />
          </div>
          {sidebarOpen && (
            <div className="flex-1">
              <p className="text-sm font-medium">Super Admin</p>
              <p className="text-xs text-gray-400">admin@kdp.co.th</p>
            </div>
          )}
          <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-50">
      <Sidebar />

      <div className={`transition-all duration-300 ${sidebarOpen ? "ml-64" : "ml-16"}`}>
        {/* Enhanced Top Bar */}
        <div className="bg-white shadow-sm border-b p-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                {activeTab === "dashboard" && "แดชบอร์ดขั้นสูง"}
                {activeTab === "users" && "จัดการผู้ใช้งาน"}
                {activeTab === "inventory" && "จัดการคลังสินค้า"}
                {activeTab === "promotions" && "จัดการโปรโมชั่น"}
                {activeTab === "support" && "ระบบสนับสนุนลูกค้า"}
                {activeTab === "analytics" && "รายงานและการวิเคราะห์"}
                {activeTab === "settings" && "ตั้งค่าระบบ"}
              </h1>
              <p className="text-gray-600">
                {new Date().toLocaleDateString("th-TH", {
                  weekday: "long",
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </p>
            </div>

            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  type="search"
                  placeholder="ค้นหาทั่วระบบ..."
                  className="pl-10 w-80"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              <Button variant="outline" size="sm" className="relative bg-transparent">
                <Bell className="h-4 w-4 mr-2" />
                แจ้งเตือน
                <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                  12
                </Badge>
              </Button>

              <Button variant="outline" size="sm">
                <Globe className="h-4 w-4 mr-2" />
                ดูหน้าเว็บ
              </Button>

              <Button variant="outline" size="sm">
                <MessageCircle className="h-4 w-4 mr-2" />
                Live Chat
                <div className="w-2 h-2 bg-green-500 rounded-full ml-2 animate-pulse"></div>
              </Button>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="p-6">
          {activeTab === "dashboard" && <AdvancedDashboard />}
          {activeTab === "users" && <UserManagement />}
          {activeTab === "inventory" && <InventoryManagement />}
          {activeTab === "promotions" && <PromotionsManagement />}
          {activeTab === "support" && <SupportManagement />}
          {activeTab === "analytics" && <AdvancedAnalytics />}
          {activeTab === "settings" && <SystemSettings />}
        </div>
      </div>
    </div>
  )
}
