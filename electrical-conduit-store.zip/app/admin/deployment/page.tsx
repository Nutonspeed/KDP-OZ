"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Rocket,
  Server,
  Database,
  Globe,
  CheckCircle,
  XCircle,
  Clock,
  GitBranch,
  Package,
  Settings,
  Download,
  Upload,
  Monitor,
  Shield,
} from "lucide-react"

// Mock deployment data
const mockDeploymentData = {
  currentVersion: "v2.1.4",
  environment: "production",
  status: "running",
  uptime: "15 days, 8 hours",
  lastDeployment: "2024-01-10T14:30:00Z",
  deploymentHistory: [
    {
      id: 1,
      version: "v2.1.4",
      status: "success",
      timestamp: "2024-01-10T14:30:00Z",
      duration: "3m 45s",
      branch: "main",
    },
    {
      id: 2,
      version: "v2.1.3",
      status: "success",
      timestamp: "2024-01-08T10:15:00Z",
      duration: "4m 12s",
      branch: "main",
    },
    {
      id: 3,
      version: "v2.1.2",
      status: "failed",
      timestamp: "2024-01-07T16:20:00Z",
      duration: "1m 30s",
      branch: "main",
    },
  ],
  environments: [
    {
      name: "Production",
      status: "running",
      version: "v2.1.4",
      url: "https://kdp-store.com",
      health: "healthy",
    },
    {
      name: "Staging",
      status: "running",
      version: "v2.1.5-beta",
      url: "https://staging.kdp-store.com",
      health: "healthy",
    },
    {
      name: "Development",
      status: "running",
      version: "v2.2.0-dev",
      url: "https://dev.kdp-store.com",
      health: "healthy",
    },
  ],
  infrastructure: {
    servers: 3,
    databases: 2,
    loadBalancers: 1,
    cdnNodes: 12,
  },
}

const mockDockerConfig = `# Dockerfile
FROM node:18-alpine AS base

# Install dependencies only when needed
FROM base AS deps
RUN apk add --no-cache libc6-compat
WORKDIR /app

COPY package.json yarn.lock* package-lock.json* pnpm-lock.yaml* ./
RUN \\
  if [ -f yarn.lock ]; then yarn --frozen-lockfile; \\
  elif [ -f package-lock.json ]; then npm ci; \\
  elif [ -f pnpm-lock.yaml ]; then yarn global add pnpm && pnpm i --frozen-lockfile; \\
  else echo "Lockfile not found." && exit 1; \\
  fi

# Rebuild the source code only when needed
FROM base AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .

RUN yarn build

# Production image, copy all the files and run next
FROM base AS runner
WORKDIR /app

ENV NODE_ENV production

RUN addgroup --system --gid 1001 nodejs
RUN adduser --system --uid 1001 nextjs

COPY --from=builder /app/public ./public

COPY --from=builder --chown=nextjs:nodejs /app/.next/standalone ./
COPY --from=builder --chown=nextjs:nodejs /app/.next/static ./.next/static

USER nextjs

EXPOSE 3000

ENV PORT 3000

CMD ["node", "server.js"]`

const mockDockerCompose = `version: '3.8'

services:
  app:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - DATABASE_URL=postgresql://user:password@db:5432/kdp_store
      - REDIS_URL=redis://redis:6379
    depends_on:
      - db
      - redis
    restart: unless-stopped

  db:
    image: postgres:15-alpine
    environment:
      - POSTGRES_DB=kdp_store
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=password
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"
    restart: unless-stopped

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    restart: unless-stopped

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/nginx/ssl
    depends_on:
      - app
    restart: unless-stopped

volumes:
  postgres_data:
  redis_data:`

const mockCICD = `name: Deploy to Production

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
        cache: 'npm'
    
    - name: Install dependencies
      run: npm ci
    
    - name: Run tests
      run: npm test
    
    - name: Run linting
      run: npm run lint
    
    - name: Build application
      run: npm run build

  deploy:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Setup Docker Buildx
      uses: docker/setup-buildx-action@v2
    
    - name: Login to Docker Hub
      uses: docker/login-action@v2
      with:
        username: \${{ secrets.DOCKER_USERNAME }}
        password: \${{ secrets.DOCKER_PASSWORD }}
    
    - name: Build and push Docker image
      uses: docker/build-push-action@v4
      with:
        context: .
        push: true
        tags: kdp-store:latest
    
    - name: Deploy to production
      run: |
        echo "Deploying to production server..."
        # Add deployment commands here`

export default function ProductionDeployment() {
  const [activeTab, setActiveTab] = useState("overview")
  const [isDeploying, setIsDeploying] = useState(false)

  const handleDeploy = async () => {
    setIsDeploying(true)
    // Simulate deployment
    await new Promise((resolve) => setTimeout(resolve, 3000))
    setIsDeploying(false)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "running":
      case "success":
      case "healthy":
        return "text-green-600 bg-green-100"
      case "deploying":
      case "pending":
        return "text-yellow-600 bg-yellow-100"
      case "failed":
      case "error":
        return "text-red-600 bg-red-100"
      default:
        return "text-gray-600 bg-gray-100"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "running":
      case "success":
      case "healthy":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "deploying":
      case "pending":
        return <Clock className="h-4 w-4 text-yellow-500" />
      case "failed":
      case "error":
        return <XCircle className="h-4 w-4 text-red-500" />
      default:
        return <Clock className="h-4 w-4 text-gray-500" />
    }
  }

  // Deployment Overview
  const DeploymentOverview = () => (
    <div className="space-y-6">
      {/* Current Status */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Current Version</p>
                <p className="text-2xl font-bold mt-1">{mockDeploymentData.currentVersion}</p>
              </div>
              <Package className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Environment</p>
                <div className="flex items-center mt-1">
                  {getStatusIcon(mockDeploymentData.status)}
                  <span className="text-lg font-semibold ml-2 capitalize">{mockDeploymentData.environment}</span>
                </div>
              </div>
              <Server className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Uptime</p>
                <p className="text-lg font-bold mt-1">{mockDeploymentData.uptime}</p>
              </div>
              <Monitor className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Last Deployment</p>
                <p className="text-sm font-semibold mt-1">
                  {new Date(mockDeploymentData.lastDeployment).toLocaleDateString()}
                </p>
              </div>
              <Rocket className="h-8 w-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Environments */}
      <Card>
        <CardHeader>
          <CardTitle>Environments</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {mockDeploymentData.environments.map((env, index) => (
              <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center space-x-4">
                  {getStatusIcon(env.status)}
                  <div>
                    <h3 className="font-semibold">{env.name}</h3>
                    <p className="text-sm text-gray-600">{env.url}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <Badge className={getStatusColor(env.health)}>{env.health}</Badge>
                  <Badge variant="outline">{env.version}</Badge>
                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline">
                      <Monitor className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline">
                      <Settings className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Infrastructure */}
      <Card>
        <CardHeader>
          <CardTitle>Infrastructure Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="text-center">
              <Server className="h-8 w-8 mx-auto text-blue-500 mb-2" />
              <p className="text-2xl font-bold">{mockDeploymentData.infrastructure.servers}</p>
              <p className="text-sm text-gray-600">Servers</p>
            </div>
            <div className="text-center">
              <Database className="h-8 w-8 mx-auto text-green-500 mb-2" />
              <p className="text-2xl font-bold">{mockDeploymentData.infrastructure.databases}</p>
              <p className="text-sm text-gray-600">Databases</p>
            </div>
            <div className="text-center">
              <Shield className="h-8 w-8 mx-auto text-purple-500 mb-2" />
              <p className="text-2xl font-bold">{mockDeploymentData.infrastructure.loadBalancers}</p>
              <p className="text-sm text-gray-600">Load Balancers</p>
            </div>
            <div className="text-center">
              <Globe className="h-8 w-8 mx-auto text-orange-500 mb-2" />
              <p className="text-2xl font-bold">{mockDeploymentData.infrastructure.cdnNodes}</p>
              <p className="text-sm text-gray-600">CDN Nodes</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  // Docker Configuration
  const DockerConfiguration = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Dockerfile</CardTitle>
        </CardHeader>
        <CardContent>
          <pre className="bg-gray-100 p-4 rounded-lg text-sm overflow-x-auto">
            <code>{mockDockerConfig}</code>
          </pre>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Docker Compose</CardTitle>
        </CardHeader>
        <CardContent>
          <pre className="bg-gray-100 p-4 rounded-lg text-sm overflow-x-auto">
            <code>{mockDockerCompose}</code>
          </pre>
        </CardContent>
      </Card>
    </div>
  )

  // CI/CD Pipeline
  const CICDPipeline = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>GitHub Actions Workflow</CardTitle>
        </CardHeader>
        <CardContent>
          <pre className="bg-gray-100 p-4 rounded-lg text-sm overflow-x-auto">
            <code>{mockCICD}</code>
          </pre>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Deployment History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {mockDeploymentData.deploymentHistory.map((deployment) => (
              <div key={deployment.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center space-x-4">
                  {getStatusIcon(deployment.status)}
                  <div>
                    <h3 className="font-semibold">{deployment.version}</h3>
                    <p className="text-sm text-gray-600">{new Date(deployment.timestamp).toLocaleString()}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <Badge className={getStatusColor(deployment.status)}>{deployment.status}</Badge>
                  <span className="text-sm text-gray-600">{deployment.duration}</span>
                  <div className="flex items-center text-sm text-gray-600">
                    <GitBranch className="h-4 w-4 mr-1" />
                    {deployment.branch}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Production Deployment</h1>
              <p className="text-gray-600 mt-2">จัดการการ Deploy และ Infrastructure</p>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                ดาวน์โหลด Config
              </Button>
              <Button variant="outline">
                <Upload className="h-4 w-4 mr-2" />
                อัพโหลด Build
              </Button>
              <Button onClick={handleDeploy} disabled={isDeploying}>
                <Rocket className={`h-4 w-4 mr-2 ${isDeploying ? "animate-pulse" : ""}`} />
                {isDeploying ? "กำลัง Deploy..." : "Deploy Now"}
              </Button>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="docker">Docker</TabsTrigger>
            <TabsTrigger value="cicd">CI/CD</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <DeploymentOverview />
          </TabsContent>

          <TabsContent value="docker">
            <DockerConfiguration />
          </TabsContent>

          <TabsContent value="cicd">
            <CICDPipeline />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
