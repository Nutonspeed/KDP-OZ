"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  CheckCircle,
  Brain,
  BarChart3,
  Calendar,
  Package,
  Target,
  Zap,
  RefreshCw,
  Download,
  Settings,
  Activity,
  LineChart,
  PieChart,
} from "lucide-react"

// Mock ML forecasting data
const mockForecastingData = {
  models: [
    {
      name: "ARIMA",
      accuracy: 87.5,
      status: "active",
      lastTrained: "2024-01-15",
      predictions: 156,
    },
    {
      name: "Random Forest",
      accuracy: 92.3,
      status: "active",
      lastTrained: "2024-01-14",
      predictions: 234,
    },
    {
      name: "Neural Network",
      accuracy: 89.1,
      status: "training",
      lastTrained: "2024-01-13",
      predictions: 189,
    },
    {
      name: "Linear Regression",
      accuracy: 78.9,
      status: "inactive",
      lastTrained: "2024-01-10",
      predictions: 98,
    },
  ],
  predictions: [
    {
      productCode: "LB-75G",
      productName: "Malleable Iron Conduit Body LB-75G",
      currentStock: 552,
      predictedDemand30: 145,
      predictedDemand60: 298,
      predictedDemand90: 456,
      recommendedOrder: 200,
      confidence: 92.3,
      trend: "increasing",
      seasonality: "high",
      riskLevel: "low",
    },
    {
      productCode: "T-75G",
      productName: "Malleable Iron Conduit Body T-75G",
      currentStock: 1085,
      predictedDemand30: 89,
      predictedDemand60: 178,
      predictedDemand90: 267,
      recommendedOrder: 0,
      confidence: 88.7,
      trend: "stable",
      seasonality: "medium",
      riskLevel: "low",
    },
    {
      productCode: "LB-250G",
      productName: "Malleable Iron Conduit Body LB-250G",
      currentStock: 10,
      predictedDemand30: 45,
      predictedDemand60: 89,
      predictedDemand90: 134,
      recommendedOrder: 150,
      confidence: 94.1,
      trend: "increasing",
      seasonality: "low",
      riskLevel: "high",
    },
    {
      productCode: "BC-75G",
      productName: "Flat Top Cover BC-75G",
      currentStock: 3734,
      predictedDemand30: 234,
      predictedDemand60: 467,
      predictedDemand90: 701,
      recommendedOrder: 0,
      confidence: 85.6,
      trend: "decreasing",
      seasonality: "high",
      riskLevel: "medium",
    },
  ],
  alerts: [
    {
      id: 1,
      type: "stockout_risk",
      product: "LB-250G",
      message: "สินค้าเสี่ยงหมดสต็อกใน 15 วัน",
      severity: "high",
      confidence: 94.1,
      action: "สั่งซื้อ 150 ชิ้น",
    },
    {
      id: 2,
      type: "overstock_risk",
      product: "BC-75G",
      message: "สินค้าเกินความต้องการ",
      severity: "medium",
      confidence: 78.3,
      action: "ลดการสั่งซื้อ 30%",
    },
    {
      id: 3,
      type: "demand_spike",
      product: "LB-75G",
      message: "ความต้องการเพิ่มขึ้น 25%",
      severity: "medium",
      confidence: 89.5,
      action: "เพิ่มสต็อก 200 ชิ้น",
    },
  ],
  insights: [
    {
      title: "Seasonal Patterns",
      description: "สินค้า LB Series มีความต้องการสูงในช่วง Q1-Q2",
      impact: "high",
      recommendation: "เพิ่มสต็อกล่วงหน้า 2 เดือน",
    },
    {
      title: "Demand Correlation",
      description: "LB-75G และ BC-75G มีความสัมพันธ์สูง (0.87)",
      impact: "medium",
      recommendation: "จัดการสต็อกแบบคู่ขนาน",
    },
    {
      title: "Price Sensitivity",
      description: "สินค้าขนาดใหญ่ (>2 นิ้ว) ไวต่อราคา",
      impact: "medium",
      recommendation: "ติดตามราคาคู่แข่งอย่างใกล้ชิด",
    },
  ],
}

const mockHistoricalData = [
  { month: "ม.ค.", actual: 145, predicted: 142, accuracy: 97.9 },
  { month: "ก.พ.", actual: 167, predicted: 159, accuracy: 95.2 },
  { month: "มี.ค.", actual: 189, predicted: 185, accuracy: 97.9 },
  { month: "เม.ย.", actual: 156, predicted: 162, accuracy: 96.2 },
  { month: "พ.ค.", actual: 178, predicted: 171, accuracy: 96.1 },
  { month: "มิ.ย.", actual: 203, predicted: 198, accuracy: 97.5 },
]

export default function InventoryForecastingML() {
  const [selectedModel, setSelectedModel] = useState("Random Forest")
  const [selectedTimeframe, setSelectedTimeframe] = useState("30")
  const [isTraining, setIsTraining] = useState(false)

  const handleTrainModel = async () => {
    setIsTraining(true)
    // Simulate model training
    await new Promise((resolve) => setTimeout(resolve, 3000))
    setIsTraining(false)
  }

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "increasing":
        return <TrendingUp className="h-4 w-4 text-green-600" />
      case "decreasing":
        return <TrendingDown className="h-4 w-4 text-red-600" />
      default:
        return <Activity className="h-4 w-4 text-blue-600" />
    }
  }

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case "high":
        return "text-red-600 bg-red-100"
      case "medium":
        return "text-yellow-600 bg-yellow-100"
      case "low":
        return "text-green-600 bg-green-100"
      default:
        return "text-gray-600 bg-gray-100"
    }
  }

  const getAlertIcon = (type: string) => {
    switch (type) {
      case "stockout_risk":
        return <AlertTriangle className="h-4 w-4 text-red-500" />
      case "overstock_risk":
        return <Package className="h-4 w-4 text-yellow-500" />
      case "demand_spike":
        return <TrendingUp className="h-4 w-4 text-blue-500" />
      default:
        return <Activity className="h-4 w-4 text-gray-500" />
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center">
                <Brain className="h-8 w-8 mr-3 text-purple-600" />
                ML Inventory Forecasting
              </h1>
              <p className="text-gray-600 mt-2">ระบบทำนายสต็อกด้วย Machine Learning</p>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" onClick={handleTrainModel} disabled={isTraining}>
                <RefreshCw className={`h-4 w-4 mr-2 ${isTraining ? "animate-spin" : ""}`} />
                {isTraining ? "กำลังเทรน..." : "Train Models"}
              </Button>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Export Predictions
              </Button>
              <Button variant="outline">
                <Settings className="h-4 w-4 mr-2" />
                Model Settings
              </Button>
            </div>
          </div>
        </div>

        {/* Model Performance Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {mockForecastingData.models.map((model) => (
            <Card key={model.name} className="relative overflow-hidden">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">{model.name}</p>
                    <p className="text-2xl font-bold mt-1">{model.accuracy}%</p>
                    <p className="text-xs text-gray-500 mt-1">Accuracy</p>
                  </div>
                  <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                    <Brain className="h-6 w-6 text-purple-600" />
                  </div>
                </div>
                <div className="mt-4">
                  <Badge
                    variant={
                      model.status === "active" ? "default" : model.status === "training" ? "secondary" : "outline"
                    }
                  >
                    {model.status === "active" && "Active"}
                    {model.status === "training" && "Training"}
                    {model.status === "inactive" && "Inactive"}
                  </Badge>
                  <p className="text-xs text-gray-500 mt-2">Last trained: {model.lastTrained}</p>
                </div>
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-purple-400 to-purple-600"></div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="predictions" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="predictions">Predictions</TabsTrigger>
            <TabsTrigger value="alerts">Smart Alerts</TabsTrigger>
            <TabsTrigger value="insights">AI Insights</TabsTrigger>
            <TabsTrigger value="performance">Model Performance</TabsTrigger>
          </TabsList>

          <TabsContent value="predictions" className="space-y-6">
            {/* Filters */}
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Model</label>
                    <Select value={selectedModel} onValueChange={setSelectedModel}>
                      <SelectTrigger className="w-48">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Random Forest">Random Forest</SelectItem>
                        <SelectItem value="ARIMA">ARIMA</SelectItem>
                        <SelectItem value="Neural Network">Neural Network</SelectItem>
                        <SelectItem value="Linear Regression">Linear Regression</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Timeframe</label>
                    <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="30">30 วัน</SelectItem>
                        <SelectItem value="60">60 วัน</SelectItem>
                        <SelectItem value="90">90 วัน</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-end">
                    <Button>
                      <Target className="h-4 w-4 mr-2" />
                      Generate Predictions
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Predictions Table */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <LineChart className="h-5 w-5 mr-2" />
                  Demand Predictions ({selectedTimeframe} วัน)
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="text-left p-4 font-medium">Product</th>
                        <th className="text-left p-4 font-medium">Current Stock</th>
                        <th className="text-left p-4 font-medium">Predicted Demand</th>
                        <th className="text-left p-4 font-medium">Recommended Order</th>
                        <th className="text-left p-4 font-medium">Confidence</th>
                        <th className="text-left p-4 font-medium">Trend</th>
                        <th className="text-left p-4 font-medium">Risk Level</th>
                      </tr>
                    </thead>
                    <tbody>
                      {mockForecastingData.predictions.map((prediction) => (
                        <tr key={prediction.productCode} className="border-t hover:bg-gray-50">
                          <td className="p-4">
                            <div>
                              <p className="font-medium">{prediction.productCode}</p>
                              <p className="text-sm text-gray-600">{prediction.productName}</p>
                            </div>
                          </td>
                          <td className="p-4">
                            <p className="font-medium">{prediction.currentStock} ชิ้น</p>
                          </td>
                          <td className="p-4">
                            <div>
                              <p className="font-medium">
                                {selectedTimeframe === "30" && prediction.predictedDemand30}
                                {selectedTimeframe === "60" && prediction.predictedDemand60}
                                {selectedTimeframe === "90" && prediction.predictedDemand90}
                                {" ชิ้น"}
                              </p>
                              <Badge variant="outline" className="text-xs mt-1">
                                Seasonality: {prediction.seasonality}
                              </Badge>
                            </div>
                          </td>
                          <td className="p-4">
                            <div>
                              <p className="font-medium">
                                {prediction.recommendedOrder > 0 ? `${prediction.recommendedOrder} ชิ้น` : "ไม่ต้องสั่ง"}
                              </p>
                              {prediction.recommendedOrder > 0 && (
                                <Button size="sm" className="mt-2">
                                  Create PO
                                </Button>
                              )}
                            </div>
                          </td>
                          <td className="p-4">
                            <div>
                              <p className="font-medium">{prediction.confidence}%</p>
                              <Progress value={prediction.confidence} className="h-2 mt-1" />
                            </div>
                          </td>
                          <td className="p-4">
                            <div className="flex items-center space-x-2">
                              {getTrendIcon(prediction.trend)}
                              <span className="text-sm capitalize">{prediction.trend}</span>
                            </div>
                          </td>
                          <td className="p-4">
                            <Badge className={getRiskColor(prediction.riskLevel)}>
                              {prediction.riskLevel === "high" && "สูง"}
                              {prediction.riskLevel === "medium" && "กลาง"}
                              {prediction.riskLevel === "low" && "ต่ำ"}
                            </Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="alerts" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <AlertTriangle className="h-5 w-5 mr-2 text-yellow-500" />
                  Smart Inventory Alerts
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockForecastingData.alerts.map((alert) => (
                    <div key={alert.id} className="flex items-start space-x-4 p-4 border rounded-lg hover:bg-gray-50">
                      <div className="flex-shrink-0 mt-1">{getAlertIcon(alert.type)}</div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium">{alert.product}</h4>
                          <Badge
                            variant={
                              alert.severity === "high"
                                ? "destructive"
                                : alert.severity === "medium"
                                  ? "default"
                                  : "secondary"
                            }
                          >
                            {alert.severity === "high" && "สูง"}
                            {alert.severity === "medium" && "กลาง"}
                            {alert.severity === "low" && "ต่ำ"}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600 mt-1">{alert.message}</p>
                        <div className="flex items-center justify-between mt-3">
                          <div className="flex items-center space-x-4">
                            <span className="text-xs text-gray-500">Confidence: {alert.confidence}%</span>
                            <span className="text-xs font-medium text-blue-600">{alert.action}</span>
                          </div>
                          <div className="flex space-x-2">
                            <Button size="sm" variant="outline">
                              Dismiss
                            </Button>
                            <Button size="sm">Take Action</Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="insights" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Zap className="h-5 w-5 mr-2 text-blue-500" />
                    AI-Generated Insights
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {mockForecastingData.insights.map((insight, index) => (
                      <div key={index} className="p-4 border rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-medium">{insight.title}</h4>
                          <Badge
                            variant={
                              insight.impact === "high"
                                ? "default"
                                : insight.impact === "medium"
                                  ? "secondary"
                                  : "outline"
                            }
                          >
                            {insight.impact === "high" && "High Impact"}
                            {insight.impact === "medium" && "Medium Impact"}
                            {insight.impact === "low" && "Low Impact"}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600 mb-3">{insight.description}</p>
                        <div className="bg-blue-50 p-3 rounded-lg">
                          <p className="text-sm font-medium text-blue-800">
                            💡 Recommendation: {insight.recommendation}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Calendar className="h-5 w-5 mr-2 text-green-500" />
                    Seasonal Patterns
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 bg-gradient-to-br from-green-50 to-blue-100 rounded-lg flex items-center justify-center">
                    <div className="text-center">
                      <PieChart className="h-16 w-16 text-green-500 mx-auto mb-4" />
                      <p className="text-gray-600">Seasonal Demand Analysis</p>
                      <p className="text-sm text-gray-500">แสดงรูปแบบความต้องการตามฤดูกาล</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="performance" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Model Accuracy Comparison</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {mockForecastingData.models.map((model) => (
                      <div key={model.name} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">{model.name}</span>
                          <span className="text-sm font-bold">{model.accuracy}%</span>
                        </div>
                        <Progress value={model.accuracy} className="h-2" />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Historical Performance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {mockHistoricalData.map((data, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <span className="text-sm font-medium">{data.month}</span>
                          <div className="text-xs text-gray-600">
                            Actual: {data.actual} | Predicted: {data.predicted}
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm font-bold text-green-600">{data.accuracy}%</span>
                          <CheckCircle className="h-4 w-4 text-green-500" />
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Prediction vs Actual Demand</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80 bg-gradient-to-br from-purple-50 to-blue-100 rounded-lg flex items-center justify-center">
                  <div className="text-center">
                    <BarChart3 className="h-16 w-16 text-purple-500 mx-auto mb-4" />
                    <p className="text-gray-600">Prediction Accuracy Chart</p>
                    <p className="text-sm text-gray-500">แสดงความแม่นยำของการทำนาย vs ความต้องการจริง</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
