"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Users,
  BarChart3,
  Settings,
  Bell,
  TrendingUp,
  Globe,
  Package,
  ShoppingCart,
  LayoutDashboard,
  LogOut,
  User,
  Package2,
  X,
  Menu,
  DollarSign,
} from "lucide-react"

// Mock data for mobile admin app
const mockMobileAdminData = {
  totalRevenue: 2450000,
  totalOrders: 156,
  totalProducts: 324,
  totalCustomers: 89,
  lowStockItems: 12,
  pendingOrders: 8,
  monthlyGrowth: 15.2,
  averageOrderValue: 15705,
}

const mockMobileAdminActivities = [
  {
    id: 1,
    type: "order",
    message: "คำสั่งซื้อใหม่ #ORD-2024-001",
    time: "5 นาทีที่แล้ว",
    status: "new",
  },
  {
    id: 2,
    type: "stock",
    message: "สินค้า LB-250G เหลือน้อย (10 ชิ้น)",
    time: "15 นาทีที่แล้ว",
    status: "warning",
  },
  {
    id: 3,
    type: "customer",
    message: "ลูกค้าใหม่ลงทะเบียน",
    time: "1 ชั่วโมงที่แล้ว",
    status: "info",
  },
  {
    id: 4,
    type: "payment",
    message: "ได้รับชำระเงิน ORD-2024-002",
    time: "2 ชั่วโมงที่แล้ว",
    status: "success",
  },
]

export default function MobileAdminApp() {
  const [activeTab, setActiveTab] = useState("dashboard")
  const [sidebarOpen, setSidebarOpen] = useState(true)

  // Sidebar Component
  const Sidebar = () => (
    <div
      className={`bg-gray-900 text-white h-screen fixed left-0 top-0 z-50 transition-all duration-300 ${sidebarOpen ? "w-64" : "w-16"}`}
    >
      <div className="p-4">
        <div className="flex items-center justify-between">
          <div className={`flex items-center space-x-2 ${!sidebarOpen && "hidden"}`}>
            <Package2 className="h-8 w-8 text-blue-400" />
            <h1 className="text-xl font-bold">KDP Admin Mobile</h1>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="text-white hover:bg-gray-800"
          >
            {sidebarOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </Button>
        </div>
      </div>

      <nav className="mt-8">
        <div className="px-4 space-y-2">
          {[
            { id: "dashboard", label: "แดชบอร์ด", icon: LayoutDashboard },
            { id: "products", label: "จัดการสินค้า", icon: Package },
            { id: "orders", label: "คำสั่งซื้อ", icon: ShoppingCart },
            { id: "customers", label: "ลูกค้า", icon: Users },
            { id: "analytics", label: "รายงาน", icon: BarChart3 },
            { id: "settings", label: "ตั้งค่า", icon: Settings },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors ${
                activeTab === item.id ? "bg-blue-600 text-white" : "text-gray-300 hover:bg-gray-800 hover:text-white"
              }`}
            >
              <item.icon className="h-5 w-5" />
              {sidebarOpen && <span>{item.label}</span>}
            </button>
          ))}
        </div>
      </nav>

      <div className="absolute bottom-4 left-4 right-4">
        <div className={`flex items-center space-x-3 p-3 bg-gray-800 rounded-lg ${!sidebarOpen && "justify-center"}`}>
          <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
            <User className="h-4 w-4 text-white" />
          </div>
          {sidebarOpen && (
            <div className="flex-1">
              <p className="text-sm font-medium">Admin User</p>
              <p className="text-xs text-gray-400">admin@kdp.co.th</p>
            </div>
          )}
          <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  )

  // Dashboard Content
  const DashboardContent = () => (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">ยอดขายรวม</p>
                <p className="text-2xl font-bold">฿{mockMobileAdminData.totalRevenue.toLocaleString()}</p>
                <p className="text-xs text-green-600 flex items-center mt-1">
                  <TrendingUp className="h-3 w-3 mr-1" />+{mockMobileAdminData.monthlyGrowth}% จากเดือนที่แล้ว
                </p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <DollarSign className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">คำสั่งซื้อ</p>
                <p className="text-2xl font-bold">{mockMobileAdminData.totalOrders}</p>
                <p className="text-xs text-blue-600">รอดำเนินการ {mockMobileAdminData.pendingOrders} รายการ</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <ShoppingCart className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>กิจกรรมล่าสุด</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {mockMobileAdminActivities.map((activity, index) => (
              <div key={index} className="flex items-start space-x-3">
                <div
                  className={`w-2 h-2 rounded-full mt-2 ${
                    activity.status === "new"
                      ? "bg-blue-500"
                      : activity.status === "warning"
                        ? "bg-orange-500"
                        : activity.status === "success"
                          ? "bg-green-500"
                          : "bg-gray-500"
                  }`}
                />
                <div className="flex-1">
                  <p className="text-sm">{activity.message}</p>
                  <p className="text-xs text-gray-500">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )

  // Products Content
  const ProductsContent = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">จัดการสินค้า</h2>
        <p className="text-gray-600">จัดการสินค้าทั้งหมดในระบบ</p>
      </div>
      <Card>
        <CardContent>
          <p>Products Content</p>
        </CardContent>
      </Card>
    </div>
  )

  // Orders Content
  const OrdersContent = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">คำสั่งซื้อ</h2>
        <p className="text-gray-600">จัดการคำสั่งซื้อทั้งหมด</p>
      </div>
      <Card>
        <CardContent>
          <p>Orders Content</p>
        </CardContent>
      </Card>
    </div>
  )

  // Customers Content
  const CustomersContent = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">ลูกค้า</h2>
        <p className="text-gray-600">จัดการข้อมูลลูกค้า</p>
      </div>
      <Card>
        <CardContent>
          <p>Customers Content</p>
        </CardContent>
      </Card>
    </div>
  )

  // Analytics Content
  const AnalyticsContent = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">รายงาน</h2>
        <p className="text-gray-600">ดูรายงานและสถิติ</p>
      </div>
      <Card>
        <CardContent>
          <p>Analytics Content</p>
        </CardContent>
      </Card>
    </div>
  )

  // Settings Content
  const SettingsContent = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">ตั้งค่า</h2>
        <p className="text-gray-600">ตั้งค่าระบบ</p>
      </div>
      <Card>
        <CardContent>
          <p>Settings Content</p>
        </CardContent>
      </Card>
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-50">
      <Sidebar />

      <div className={`transition-all duration-300 ${sidebarOpen ? "ml-64" : "ml-16"}`}>
        {/* Top Bar */}
        <div className="bg-white shadow-sm border-b p-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                {activeTab === "dashboard" && "แดชบอร์ด"}
                {activeTab === "products" && "จัดการสินค้า"}
                {activeTab === "orders" && "คำสั่งซื้อ"}
                {activeTab === "customers" && "ลูกค้า"}
                {activeTab === "analytics" && "รายงาน"}
                {activeTab === "settings" && "ตั้งค่า"}
              </h1>
              <p className="text-gray-600">
                {new Date().toLocaleDateString("th-TH", {
                  weekday: "long",
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </p>
            </div>

            <div className="flex items-center space-x-4">
              <Button variant="outline" size="sm">
                <Bell className="h-4 w-4 mr-2" />
                แจ้งเตือน
                <Badge className="ml-2">3</Badge>
              </Button>
              <Button variant="outline" size="sm">
                <Globe className="h-4 w-4 mr-2" />
                ดูหน้าเว็บ
              </Button>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="p-6">
          {activeTab === "dashboard" && <DashboardContent />}
          {activeTab === "products" && <ProductsContent />}
          {activeTab === "orders" && <OrdersContent />}
          {activeTab === "customers" && <CustomersContent />}
          {activeTab === "analytics" && <AnalyticsContent />}
          {activeTab === "settings" && <SettingsContent />}
        </div>
      </div>
    </div>
  )
}
