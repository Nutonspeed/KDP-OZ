"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Download, Plus } from "lucide-react"

// Mock data for advanced reports
const mockReportData = {
  totalRevenue: 2450000,
  totalOrders: 156,
  totalProducts: 324,
  totalCustomers: 89,
  lowStockItems: 12,
  pendingOrders: 8,
  monthlyGrowth: 15.2,
  averageOrderValue: 15705,
}

const mockReportActivities = [
  {
    id: 1,
    type: "order",
    message: "คำสั่งซื้อใหม่ #ORD-2024-001",
    time: "5 นาทีที่แล้ว",
    status: "new",
  },
  {
    id: 2,
    type: "stock",
    message: "สินค้า LB-250G เหลือน้อย (10 ชิ้น)",
    time: "15 นาทีที่แล้ว",
    status: "warning",
  },
  {
    id: 3,
    type: "customer",
    message: "ลูกค้าใหม่ลงทะเบียน",
    time: "1 ชั่วโมงที่แล้ว",
    status: "info",
  },
  {
    id: 4,
    type: "payment",
    message: "ได้รับชำระเงิน ORD-2024-002",
    time: "2 ชั่วโมงที่แล้ว",
    status: "success",
  },
]

export default function AdvancedReports() {
  const [activeTab, setActiveTab] = useState("sales")

  // Sales Reports
  const SalesReports = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">รายงานยอดขาย</h2>
        <p className="text-gray-600">วิเคราะห์ยอดขายและแนวโน้ม</p>
      </div>
      <Card>
        <CardContent>
          <p>Sales Reports Content</p>
        </CardContent>
      </Card>
    </div>
  )

  // Inventory Reports
  const InventoryReports = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">รายงานสินค้าคงคลัง</h2>
        <p className="text-gray-600">ติดตามสต็อกสินค้าและการเคลื่อนไหว</p>
      </div>
      <Card>
        <CardContent>
          <p>Inventory Reports Content</p>
        </CardContent>
      </Card>
    </div>
  )

  // Customer Reports
  const CustomerReports = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">รายงานลูกค้า</h2>
        <p className="text-gray-600">วิเคราะห์ข้อมูลลูกค้าและพฤติกรรมการซื้อ</p>
      </div>
      <Card>
        <CardContent>
          <p>Customer Reports Content</p>
        </CardContent>
      </Card>
    </div>
  )

  // Marketing Reports
  const MarketingReports = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">รายงานการตลาด</h2>
        <p className="text-gray-600">วัดผลแคมเปญการตลาดและโปรโมชั่น</p>
      </div>
      <Card>
        <CardContent>
          <p>Marketing Reports Content</p>
        </CardContent>
      </Card>
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Advanced Reports</h1>
              <p className="text-gray-600 mt-2">วิเคราะห์ข้อมูลและสร้างรายงานขั้นสูง</p>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                ส่งออกทั้งหมด
              </Button>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                สร้างรายงานใหม่
              </Button>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="sales">Sales</TabsTrigger>
            <TabsTrigger value="inventory">Inventory</TabsTrigger>
            <TabsTrigger value="customers">Customers</TabsTrigger>
            <TabsTrigger value="marketing">Marketing</TabsTrigger>
          </TabsList>

          <TabsContent value="sales">
            <SalesReports />
          </TabsContent>

          <TabsContent value="inventory">
            <InventoryReports />
          </TabsContent>

          <TabsContent value="customers">
            <CustomerReports />
          </TabsContent>

          <TabsContent value="marketing">
            <MarketingReports />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
