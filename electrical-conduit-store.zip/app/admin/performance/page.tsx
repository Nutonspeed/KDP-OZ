"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Activity,
  Server,
  Database,
  Globe,
  Cpu,
  HardDrive,
  MemoryStick,
  Wifi,
  AlertTriangle,
  CheckCircle,
  XCircle,
  TrendingUp,
  TrendingDown,
  RefreshCw,
  Download,
  Settings,
} from "lucide-react"

// Mock performance data
const mockPerformanceData = {
  systemHealth: {
    status: "healthy",
    uptime: "99.9%",
    lastUpdate: new Date().toISOString(),
  },
  serverMetrics: {
    cpu: { usage: 45, status: "normal" },
    memory: { usage: 68, total: 16, used: 10.9, status: "normal" },
    disk: { usage: 32, total: 500, used: 160, status: "normal" },
    network: { inbound: 125.5, outbound: 89.2, status: "normal" },
  },
  applicationMetrics: {
    responseTime: 245,
    throughput: 1250,
    errorRate: 0.02,
    activeUsers: 156,
  },
  databaseMetrics: {
    connections: 45,
    maxConnections: 100,
    queryTime: 12.5,
    slowQueries: 3,
  },
}

const mockAlerts = [
  {
    id: 1,
    type: "warning",
    message: "High memory usage detected (>80%)",
    timestamp: "2024-01-15T10:30:00Z",
    severity: "medium",
  },
  {
    id: 2,
    type: "info",
    message: "Database backup completed successfully",
    timestamp: "2024-01-15T09:00:00Z",
    severity: "low",
  },
  {
    id: 3,
    type: "error",
    message: "API endpoint /api/products timeout",
    timestamp: "2024-01-15T08:45:00Z",
    severity: "high",
  },
]

const mockPerformanceHistory = [
  { time: "00:00", cpu: 35, memory: 60, response: 180 },
  { time: "04:00", cpu: 28, memory: 55, response: 165 },
  { time: "08:00", cpu: 45, memory: 68, response: 245 },
  { time: "12:00", cpu: 52, memory: 72, response: 280 },
  { time: "16:00", cpu: 48, memory: 70, response: 260 },
  { time: "20:00", cpu: 42, memory: 65, response: 220 },
]

export default function PerformanceMonitoring() {
  const [activeTab, setActiveTab] = useState("overview")
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [realTimeData, setRealTimeData] = useState(mockPerformanceData)

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setRealTimeData((prev) => ({
        ...prev,
        serverMetrics: {
          ...prev.serverMetrics,
          cpu: {
            ...prev.serverMetrics.cpu,
            usage: Math.max(20, Math.min(80, prev.serverMetrics.cpu.usage + (Math.random() - 0.5) * 10)),
          },
          memory: {
            ...prev.serverMetrics.memory,
            usage: Math.max(40, Math.min(90, prev.serverMetrics.memory.usage + (Math.random() - 0.5) * 5)),
          },
        },
        applicationMetrics: {
          ...prev.applicationMetrics,
          responseTime: Math.max(100, Math.min(500, prev.applicationMetrics.responseTime + (Math.random() - 0.5) * 50)),
          activeUsers: Math.max(
            50,
            Math.min(300, prev.applicationMetrics.activeUsers + Math.floor((Math.random() - 0.5) * 20)),
          ),
        },
      }))
    }, 3000)

    return () => clearInterval(interval)
  }, [])

  const handleRefresh = async () => {
    setIsRefreshing(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))
    setIsRefreshing(false)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "healthy":
      case "normal":
        return "text-green-600 bg-green-100"
      case "warning":
        return "text-yellow-600 bg-yellow-100"
      case "error":
      case "critical":
        return "text-red-600 bg-red-100"
      default:
        return "text-gray-600 bg-gray-100"
    }
  }

  const getAlertIcon = (type: string) => {
    switch (type) {
      case "error":
        return <XCircle className="h-4 w-4 text-red-500" />
      case "warning":
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />
      case "info":
        return <CheckCircle className="h-4 w-4 text-blue-500" />
      default:
        return <CheckCircle className="h-4 w-4 text-gray-500" />
    }
  }

  // System Overview
  const SystemOverview = () => (
    <div className="space-y-6">
      {/* System Health Status */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">System Status</p>
                <div className="flex items-center mt-2">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-lg font-semibold text-green-600">Healthy</span>
                </div>
              </div>
              <Activity className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Uptime</p>
                <p className="text-2xl font-bold mt-1">{realTimeData.systemHealth.uptime}</p>
              </div>
              <Server className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Response Time</p>
                <p className="text-2xl font-bold mt-1">{Math.round(realTimeData.applicationMetrics.responseTime)}ms</p>
              </div>
              <Globe className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Users</p>
                <p className="text-2xl font-bold mt-1">{realTimeData.applicationMetrics.activeUsers}</p>
              </div>
              <Activity className="h-8 w-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Server Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Cpu className="h-5 w-5 mr-2" />
              CPU Usage
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Current Usage</span>
                <span className="text-2xl font-bold">{Math.round(realTimeData.serverMetrics.cpu.usage)}%</span>
              </div>
              <Progress value={realTimeData.serverMetrics.cpu.usage} className="h-3" />
              <div className="flex items-center justify-between text-sm text-gray-600">
                <span>Normal Range: 0-70%</span>
                <Badge className={getStatusColor(realTimeData.serverMetrics.cpu.status)}>
                  {realTimeData.serverMetrics.cpu.status}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <MemoryStick className="h-5 w-5 mr-2" />
              Memory Usage
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Current Usage</span>
                <span className="text-2xl font-bold">{Math.round(realTimeData.serverMetrics.memory.usage)}%</span>
              </div>
              <Progress value={realTimeData.serverMetrics.memory.usage} className="h-3" />
              <div className="flex items-center justify-between text-sm text-gray-600">
                <span>
                  {realTimeData.serverMetrics.memory.used}GB / {realTimeData.serverMetrics.memory.total}GB
                </span>
                <Badge className={getStatusColor(realTimeData.serverMetrics.memory.status)}>
                  {realTimeData.serverMetrics.memory.status}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <HardDrive className="h-5 w-5 mr-2" />
              Disk Usage
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Current Usage</span>
                <span className="text-2xl font-bold">{realTimeData.serverMetrics.disk.usage}%</span>
              </div>
              <Progress value={realTimeData.serverMetrics.disk.usage} className="h-3" />
              <div className="flex items-center justify-between text-sm text-gray-600">
                <span>
                  {realTimeData.serverMetrics.disk.used}GB / {realTimeData.serverMetrics.disk.total}GB
                </span>
                <Badge className={getStatusColor(realTimeData.serverMetrics.disk.status)}>
                  {realTimeData.serverMetrics.disk.status}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Wifi className="h-5 w-5 mr-2" />
              Network Traffic
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                  <span className="text-sm">Inbound</span>
                </div>
                <span className="font-semibold">{realTimeData.serverMetrics.network.inbound} MB/s</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <TrendingDown className="h-4 w-4 text-blue-500 mr-1" />
                  <span className="text-sm">Outbound</span>
                </div>
                <span className="font-semibold">{realTimeData.serverMetrics.network.outbound} MB/s</span>
              </div>
              <Badge className={getStatusColor(realTimeData.serverMetrics.network.status)}>
                {realTimeData.serverMetrics.network.status}
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )

  // Database Monitoring
  const DatabaseMonitoring = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Connections</p>
                <p className="text-2xl font-bold mt-1">{realTimeData.databaseMetrics.connections}</p>
                <p className="text-xs text-gray-500">Max: {realTimeData.databaseMetrics.maxConnections}</p>
              </div>
              <Database className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Avg Query Time</p>
                <p className="text-2xl font-bold mt-1">{realTimeData.databaseMetrics.queryTime}ms</p>
              </div>
              <Activity className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Slow Queries</p>
                <p className="text-2xl font-bold mt-1">{realTimeData.databaseMetrics.slowQueries}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Throughput</p>
                <p className="text-2xl font-bold mt-1">{realTimeData.applicationMetrics.throughput}</p>
                <p className="text-xs text-gray-500">queries/min</p>
              </div>
              <TrendingUp className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Database Connection Pool</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Connection Usage</span>
              <span className="text-lg font-bold">
                {realTimeData.databaseMetrics.connections}/{realTimeData.databaseMetrics.maxConnections}
              </span>
            </div>
            <Progress
              value={(realTimeData.databaseMetrics.connections / realTimeData.databaseMetrics.maxConnections) * 100}
              className="h-3"
            />
            <div className="grid grid-cols-3 gap-4 text-sm">
              <div>
                <p className="text-gray-600">Active</p>
                <p className="font-semibold">{realTimeData.databaseMetrics.connections}</p>
              </div>
              <div>
                <p className="text-gray-600">Idle</p>
                <p className="font-semibold">
                  {realTimeData.databaseMetrics.maxConnections - realTimeData.databaseMetrics.connections}
                </p>
              </div>
              <div>
                <p className="text-gray-600">Max</p>
                <p className="font-semibold">{realTimeData.databaseMetrics.maxConnections}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  // Alerts & Logs
  const AlertsAndLogs = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Recent Alerts</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {mockAlerts.map((alert) => (
              <div key={alert.id} className="flex items-start space-x-3 p-4 border rounded-lg">
                {getAlertIcon(alert.type)}
                <div className="flex-1">
                  <p className="text-sm font-medium">{alert.message}</p>
                  <p className="text-xs text-gray-500 mt-1">{new Date(alert.timestamp).toLocaleString()}</p>
                </div>
                <Badge
                  variant={
                    alert.severity === "high" ? "destructive" : alert.severity === "medium" ? "default" : "secondary"
                  }
                >
                  {alert.severity}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Performance Monitoring</h1>
              <p className="text-gray-600 mt-2">ติดตามประสิทธิภาพระบบแบบเรียลไทม์</p>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" onClick={handleRefresh} disabled={isRefreshing}>
                <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? "animate-spin" : ""}`} />
                {isRefreshing ? "กำลังอัพเดท..." : "รีเฟรช"}
              </Button>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                ส่งออกรายงาน
              </Button>
              <Button variant="outline">
                <Settings className="h-4 w-4 mr-2" />
                ตั้งค่า
              </Button>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="overview">System Overview</TabsTrigger>
            <TabsTrigger value="database">Database</TabsTrigger>
            <TabsTrigger value="alerts">Alerts & Logs</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <SystemOverview />
          </TabsContent>

          <TabsContent value="database">
            <DatabaseMonitoring />
          </TabsContent>

          <TabsContent value="alerts">
            <AlertsAndLogs />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
