"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import {
  Database,
  HardDrive,
  Cloud,
  Download,
  Upload,
  RefreshCw,
  Settings,
  Calendar,
  Clock,
  CheckCircle,
  XCircle,
  Archive,
  Shield,
} from "lucide-react"

// Mock backup data
const mockBackups = [
  {
    id: 1,
    name: "daily_backup_2024_01_15",
    type: "full",
    size: "2.4 GB",
    status: "completed",
    createdAt: "2024-01-15T02:00:00Z",
    duration: "12m 34s",
    location: "cloud",
  },
  {
    id: 2,
    name: "daily_backup_2024_01_14",
    type: "full",
    size: "2.3 GB",
    status: "completed",
    createdAt: "2024-01-14T02:00:00Z",
    duration: "11m 45s",
    location: "cloud",
  },
  {
    id: 3,
    name: "incremental_backup_2024_01_15_12",
    type: "incremental",
    size: "156 MB",
    status: "completed",
    createdAt: "2024-01-15T12:00:00Z",
    duration: "2m 15s",
    location: "local",
  },
  {
    id: 4,
    name: "daily_backup_2024_01_13",
    type: "full",
    size: "2.2 GB",
    status: "failed",
    createdAt: "2024-01-13T02:00:00Z",
    duration: "5m 12s",
    location: "cloud",
  },
]

const mockBackupStats = {
  totalBackups: 156,
  successfulBackups: 148,
  failedBackups: 8,
  totalSize: "45.2 GB",
  lastBackup: "2024-01-15T02:00:00Z",
  nextBackup: "2024-01-16T02:00:00Z",
  storageUsed: 68,
  retentionDays: 30,
}

const mockSchedules = [
  {
    id: 1,
    name: "Daily Full Backup",
    type: "full",
    frequency: "daily",
    time: "02:00",
    enabled: true,
    lastRun: "2024-01-15T02:00:00Z",
    nextRun: "2024-01-16T02:00:00Z",
  },
  {
    id: 2,
    name: "Hourly Incremental",
    type: "incremental",
    frequency: "hourly",
    time: "00",
    enabled: true,
    lastRun: "2024-01-15T14:00:00Z",
    nextRun: "2024-01-15T15:00:00Z",
  },
  {
    id: 3,
    name: "Weekly Archive",
    type: "archive",
    frequency: "weekly",
    time: "01:00",
    enabled: false,
    lastRun: "2024-01-08T01:00:00Z",
    nextRun: "2024-01-22T01:00:00Z",
  },
]

export default function BackupSystem() {
  const [activeTab, setActiveTab] = useState("overview")
  const [isBackingUp, setIsBackingUp] = useState(false)
  const [backupProgress, setBackupProgress] = useState(0)

  const handleCreateBackup = async () => {
    setIsBackingUp(true)
    setBackupProgress(0)

    // Simulate backup progress
    const interval = setInterval(() => {
      setBackupProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setIsBackingUp(false)
          return 100
        }
        return prev + Math.random() * 15
      })
    }, 500)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "text-green-600 bg-green-100"
      case "failed":
        return "text-red-600 bg-red-100"
      case "running":
        return "text-blue-600 bg-blue-100"
      default:
        return "text-gray-600 bg-gray-100"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "failed":
        return <XCircle className="h-4 w-4 text-red-500" />
      case "running":
        return <RefreshCw className="h-4 w-4 text-blue-500 animate-spin" />
      default:
        return <Clock className="h-4 w-4 text-gray-500" />
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "full":
        return <Database className="h-4 w-4 text-blue-500" />
      case "incremental":
        return <HardDrive className="h-4 w-4 text-green-500" />
      case "archive":
        return <Archive className="h-4 w-4 text-purple-500" />
      default:
        return <Database className="h-4 w-4 text-gray-500" />
    }
  }

  // Backup Overview
  const BackupOverview = () => (
    <div className="space-y-6">
      {/* Backup Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Backups</p>
                <p className="text-2xl font-bold mt-1">{mockBackupStats.totalBackups}</p>
              </div>
              <Database className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Success Rate</p>
                <p className="text-2xl font-bold mt-1 text-green-600">
                  {Math.round((mockBackupStats.successfulBackups / mockBackupStats.totalBackups) * 100)}%
                </p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Size</p>
                <p className="text-2xl font-bold mt-1">{mockBackupStats.totalSize}</p>
              </div>
              <HardDrive className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Storage Used</p>
                <p className="text-2xl font-bold mt-1">{mockBackupStats.storageUsed}%</p>
              </div>
              <Cloud className="h-8 w-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Backup Progress */}
      {isBackingUp && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <RefreshCw className="h-5 w-5 mr-2 animate-spin" />
              Backup in Progress
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Creating backup...</span>
                <span className="text-sm text-gray-600">{Math.round(backupProgress)}%</span>
              </div>
              <Progress value={backupProgress} className="h-3" />
              <p className="text-sm text-gray-600">
                Estimated time remaining: {Math.max(1, Math.round((100 - backupProgress) / 10))} minutes
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recent Backups */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Backups</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {mockBackups.slice(0, 5).map((backup) => (
              <div key={backup.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center space-x-4">
                  {getStatusIcon(backup.status)}
                  <div>
                    <h3 className="font-semibold">{backup.name}</h3>
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      <span>{new Date(backup.createdAt).toLocaleString()}</span>
                      <span>Size: {backup.size}</span>
                      <span>Duration: {backup.duration}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    {getTypeIcon(backup.type)}
                    <Badge variant="outline">{backup.type}</Badge>
                  </div>
                  <Badge className={getStatusColor(backup.status)}>{backup.status}</Badge>
                  <div className="flex items-center space-x-1">
                    {backup.location === "cloud" ? (
                      <Cloud className="h-4 w-4 text-blue-500" />
                    ) : (
                      <HardDrive className="h-4 w-4 text-gray-500" />
                    )}
                    <span className="text-sm text-gray-600">{backup.location}</span>
                  </div>
                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline">
                      <Download className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline">
                      <Upload className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Storage Usage */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Storage Usage</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Used Storage</span>
                <span className="text-lg font-bold">{mockBackupStats.storageUsed}%</span>
              </div>
              <Progress value={mockBackupStats.storageUsed} className="h-3" />
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div>
                  <p className="text-gray-600">Used</p>
                  <p className="font-semibold">{mockBackupStats.totalSize}</p>
                </div>
                <div>
                  <p className="text-gray-600">Available</p>
                  <p className="font-semibold">21.3 GB</p>
                </div>
                <div>
                  <p className="text-gray-600">Total</p>
                  <p className="font-semibold">66.5 GB</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Backup Schedule</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Last Backup</span>
                <span className="text-sm text-gray-600">{new Date(mockBackupStats.lastBackup).toLocaleString()}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Next Backup</span>
                <span className="text-sm text-gray-600">{new Date(mockBackupStats.nextBackup).toLocaleString()}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Retention Period</span>
                <span className="text-sm text-gray-600">{mockBackupStats.retentionDays} days</span>
              </div>
              <div className="pt-4 border-t">
                <Button className="w-full" onClick={handleCreateBackup} disabled={isBackingUp}>
                  {isBackingUp ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Creating Backup...
                    </>
                  ) : (
                    <>
                      <Database className="h-4 w-4 mr-2" />
                      Create Backup Now
                    </>
                  )}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )

  // Backup Schedules
  const BackupSchedules = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-bold">Backup Schedules</h3>
          <p className="text-gray-600">จัดการตารางการสำรองข้อมูลอัตโนมัติ</p>
        </div>
        <Button>
          <Calendar className="h-4 w-4 mr-2" />
          เพิ่มตารางใหม่
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {mockSchedules.map((schedule) => (
          <Card key={schedule.id}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  {getTypeIcon(schedule.type)}
                  <div>
                    <h3 className="font-semibold">{schedule.name}</h3>
                    <div className="flex items-center space-x-4 text-sm text-gray-600 mt-1">
                      <span>Type: {schedule.type}</span>
                      <span>Frequency: {schedule.frequency}</span>
                      <span>Time: {schedule.time}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="text-right text-sm">
                    <p className="text-gray-600">Last Run</p>
                    <p className="font-medium">{new Date(schedule.lastRun).toLocaleString()}</p>
                  </div>
                  <div className="text-right text-sm">
                    <p className="text-gray-600">Next Run</p>
                    <p className="font-medium">{new Date(schedule.nextRun).toLocaleString()}</p>
                  </div>
                  <Switch checked={schedule.enabled} />
                  <Button size="sm" variant="outline">
                    <Settings className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )

  // Backup Settings
  const BackupSettings = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-bold">Backup Settings</h3>
        <p className="text-gray-600">กำหนดค่าการสำรองข้อมูล</p>
      </div>

      <Tabs defaultValue="general" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="storage">Storage</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>General Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="auto-backup">Enable Automatic Backups</Label>
                  <p className="text-sm text-gray-600">สำรองข้อมูลอัตโนมัติตามตารางที่กำหนด</p>
                </div>
                <Switch id="auto-backup" defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="compress-backup">Compress Backups</Label>
                  <p className="text-sm text-gray-600">บีบอัดไฟล์สำรองข้อมูลเพื่อประหยัดพื้นที่</p>
                </div>
                <Switch id="compress-backup" defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="verify-backup">Verify Backup Integrity</Label>
                  <p className="text-sm text-gray-600">ตรวจสอบความถูกต้องของไฟล์สำรองข้อมูล</p>
                </div>
                <Switch id="verify-backup" defaultChecked />
              </div>
              <div>
                <Label htmlFor="retention-days">Retention Period (days)</Label>
                <Input id="retention-days" type="number" defaultValue="30" />
                <p className="text-sm text-gray-600 mt-1">จำนวนวันที่เก็บไฟล์สำรองข้อมูล</p>
              </div>
              <div>
                <Label htmlFor="max-backups">Maximum Backups</Label>
                <Input id="max-backups" type="number" defaultValue="50" />
                <p className="text-sm text-gray-600 mt-1">จำนวนไฟล์สำรองข้อมูลสูงสุดที่เก็บไว้</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="storage" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Storage Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="storage-type">Storage Type</Label>
                <Select defaultValue="cloud">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="local">Local Storage</SelectItem>
                    <SelectItem value="cloud">Cloud Storage</SelectItem>
                    <SelectItem value="both">Both Local & Cloud</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="cloud-provider">Cloud Provider</Label>
                <Select defaultValue="aws">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="aws">Amazon S3</SelectItem>
                    <SelectItem value="gcp">Google Cloud Storage</SelectItem>
                    <SelectItem value="azure">Azure Blob Storage</SelectItem>
                    <SelectItem value="dropbox">Dropbox</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="backup-path">Local Backup Path</Label>
                <Input id="backup-path" defaultValue="/var/backups/kdp-store" />
              </div>
              <div>
                <Label htmlFor="cloud-bucket">Cloud Bucket/Container</Label>
                <Input id="cloud-bucket" defaultValue="kdp-store-backups" />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="sync-cloud">Sync to Cloud</Label>
                  <p className="text-sm text-gray-600">อัพโหลดไฟล์สำรองข้อมูลไปยัง Cloud อัตโนมัติ</p>
                </div>
                <Switch id="sync-cloud" defaultChecked />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Security Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="encrypt-backup">Encrypt Backups</Label>
                  <p className="text-sm text-gray-600">เข้ารหัสไฟล์สำรองข้อมูลด้วย AES-256</p>
                </div>
                <Switch id="encrypt-backup" defaultChecked />
              </div>
              <div>
                <Label htmlFor="encryption-key">Encryption Key</Label>
                <Input id="encryption-key" type="password" placeholder="Enter encryption key" />
                <p className="text-sm text-gray-600 mt-1">กุญแจเข้ารหัสสำหรับไฟล์สำรองข้อมูล</p>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="secure-transfer">Secure Transfer</Label>
                  <p className="text-sm text-gray-600">ใช้ HTTPS/TLS สำหรับการส่งข้อมูล</p>
                </div>
                <Switch id="secure-transfer" defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="access-control">Access Control</Label>
                  <p className="text-sm text-gray-600">จำกัดการเข้าถึงไฟล์สำรองข้อมูล</p>
                </div>
                <Switch id="access-control" defaultChecked />
              </div>
              <div>
                <Label htmlFor="allowed-users">Allowed Users</Label>
                <Input id="allowed-users" placeholder="admin@kdp.co.th, backup@kdp.co.th" />
                <p className="text-sm text-gray-600 mt-1">ผู้ใช้ที่สามารถเข้าถึงไฟล์สำรองข้อมูลได้</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center">
                <Shield className="h-8 w-8 mr-3 text-blue-600" />
                Backup System
              </h1>
              <p className="text-gray-600 mt-2">ระบบสำรองข้อมูลอัตโนมัติ</p>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                ดาวน์โหลด
              </Button>
              <Button variant="outline">
                <Upload className="h-4 w-4 mr-2" />
                กู้คืนข้อมูล
              </Button>
              <Button onClick={handleCreateBackup} disabled={isBackingUp}>
                <Database className="h-4 w-4 mr-2" />
                สำรองข้อมูลทันที
              </Button>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="schedules">Schedules</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <BackupOverview />
          </TabsContent>

          <TabsContent value="schedules">
            <BackupSchedules />
          </TabsContent>

          <TabsContent value="settings">
            <BackupSettings />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
