"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Users,
  Package,
  ShoppingCart,
  TrendingUp,
  DollarSign,
  AlertTriangle,
  CheckCircle,
  Clock,
  BarChart3,
  Settings,
  Bell,
  Search,
  Filter,
  Download,
  RefreshCw,
} from "lucide-react"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import {
  LayoutDashboard,
  Package2,
  Edit,
  Trash2,
  Eye,
  Upload,
  RefreshCwIcon,
  FileText,
  Globe,
  Mail,
  Star,
  XCircle,
  AlertCircle,
  Menu,
  X,
  LogOut,
  User,
  Plus,
  UserCheck,
} from "lucide-react"
import Image from "next/image"

// Mock data
const mockStats = {
  totalUsers: 1247,
  totalProducts: 456,
  totalOrders: 892,
  totalRevenue: 125430.5,
  monthlyGrowth: 12.5,
  pendingOrders: 23,
  lowStockItems: 8,
  activeUsers: 156,
}

const mockRecentOrders = [
  {
    id: "ORD-001",
    customer: "บริษัท ABC จำกัด",
    product: "PVC Conduit 20mm x 100 pieces",
    amount: 4550.0,
    status: "completed",
    date: "2024-01-15T10:30:00Z",
  },
  {
    id: "ORD-002",
    customer: "ร้าน XYZ Hardware",
    product: "Metal Conduit 25mm x 50 pieces",
    amount: 4450.0,
    status: "pending",
    date: "2024-01-15T09:15:00Z",
  },
  {
    id: "ORD-003",
    customer: "โครงการ DEF",
    product: "Junction Box Set x 20 sets",
    amount: 7000.0,
    status: "processing",
    date: "2024-01-15T08:45:00Z",
  },
  {
    id: "ORD-004",
    customer: "บริษัท GHI Electric",
    product: "Cable Tray 200mm x 10 pieces",
    amount: 2800.0,
    status: "shipped",
    date: "2024-01-14T16:20:00Z",
  },
]

const mockLowStockProducts = [
  { id: 1, name: "PVC Conduit 20mm", stock: 5, minStock: 20, category: "PVC Conduits" },
  { id: 2, name: "Metal Junction Box", stock: 3, minStock: 15, category: "Junction Boxes" },
  { id: 3, name: "Flexible Conduit 32mm", stock: 8, minStock: 25, category: "Flexible Conduits" },
  { id: 4, name: "Cable Tray Bracket", stock: 2, minStock: 10, category: "Accessories" },
]

const mockTopProducts = [
  { name: "PVC Conduit 20mm", sales: 245, revenue: 11127.5 },
  { name: "Metal Conduit 25mm", sales: 189, revenue: 16821.0 },
  { name: "Junction Box 100x100", sales: 156, revenue: 5460.0 },
  { name: "Flexible Conduit 32mm", sales: 134, revenue: 16750.0 },
]

// Mock data for admin panel
const mockProducts = [
  {
    id: 1,
    code: "LB-75G",
    name: "Malleable Iron Conduit Body LB-75G",
    category: "Malleable Iron LB",
    size: '3/4"',
    price: 360.0,
    cost: 280.0,
    qty: 552,
    minStock: 50,
    status: "active",
    image: "/placeholder.svg?height=60&width=60&text=LB-75G",
    lastUpdated: "2024-01-15",
    supplier: "O-Z/Gedney",
    location: "A-01-15",
  },
  {
    id: 2,
    code: "T-75G",
    name: "Malleable Iron Conduit Body T-75G",
    category: "Malleable Iron T",
    size: '3/4"',
    price: 450.0,
    cost: 350.0,
    qty: 1085,
    minStock: 100,
    status: "active",
    image: "/placeholder.svg?height=60&width=60&text=T-75G",
    lastUpdated: "2024-01-14",
    supplier: "O-Z/Gedney",
    location: "A-02-20",
  },
  {
    id: 3,
    code: "BC-75G",
    name: "Flat Top Cover BC-75G",
    category: "Covers",
    size: '3/4"',
    price: 215.0,
    cost: 165.0,
    qty: 3734,
    minStock: 200,
    status: "active",
    image: "/placeholder.svg?height=60&width=60&text=BC-75G",
    lastUpdated: "2024-01-13",
    supplier: "O-Z/Gedney",
    location: "B-01-05",
  },
  {
    id: 4,
    code: "LB-250G",
    name: "Malleable Iron Conduit Body LB-250G",
    category: "Malleable Iron LB",
    size: '2-1/2"',
    price: 2300.0,
    cost: 1800.0,
    qty: 10,
    minStock: 20,
    status: "low_stock",
    image: "/placeholder.svg?height=60&width=60&text=LB-250G",
    lastUpdated: "2024-01-12",
    supplier: "O-Z/Gedney",
    location: "A-03-10",
  },
]

const mockOrders = [
  {
    id: "ORD-2024-001",
    customer: "บริษัท ABC จำกัด",
    email: "abc@company.com",
    phone: "02-123-4567",
    total: 15750.0,
    status: "pending",
    items: 5,
    date: "2024-01-15",
    paymentMethod: "bank_transfer",
    shippingAddress: "123 ถนนสุขุมวิท กรุงเทพฯ 10110",
  },
  {
    id: "ORD-2024-002",
    customer: "คุณสมชาย ใจดี",
    email: "somchai@email.com",
    phone: "08-1234-5678",
    total: 2850.0,
    status: "confirmed",
    items: 3,
    date: "2024-01-14",
    paymentMethod: "credit_card",
    shippingAddress: "456 ถนนพหลโยธิน นนทบุรี 11000",
  },
  {
    id: "ORD-2024-003",
    customer: "บริษัท XYZ เอ็นจิเนียริ่ง",
    email: "xyz@engineering.com",
    phone: "02-987-6543",
    total: 45200.0,
    status: "shipped",
    items: 12,
    date: "2024-01-13",
    paymentMethod: "bank_transfer",
    shippingAddress: "789 ถนนรัชดาภิเษก กรุงเทพฯ 10400",
  },
]

const mockCustomers = [
  {
    id: 1,
    name: "บริษัท ABC จำกัด",
    email: "abc@company.com",
    phone: "02-123-4567",
    type: "corporate",
    totalOrders: 15,
    totalSpent: 125000.0,
    lastOrder: "2024-01-15",
    status: "active",
    address: "123 ถนนสุขุมวิท กรุงเทพฯ 10110",
    taxId: "0123456789012",
  },
  {
    id: 2,
    name: "คุณสมชาย ใจดี",
    email: "somchai@email.com",
    phone: "08-1234-5678",
    type: "individual",
    totalOrders: 8,
    totalSpent: 45000.0,
    lastOrder: "2024-01-14",
    status: "active",
    address: "456 ถนนพหลโยธิน นนทบุรี 11000",
    taxId: "",
  },
]

export default function AdminDashboard() {
  const [stats, setStats] = useState(mockStats)
  const [isLoading, setIsLoading] = useState(false)
  const [activeTab, setActiveTab] = useState("dashboard")
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedProduct, setSelectedProduct] = useState(null)
  const [isAddProductOpen, setIsAddProductOpen] = useState(false)

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setStats((prev) => ({
        ...prev,
        activeUsers: Math.max(100, Math.min(200, prev.activeUsers + Math.floor((Math.random() - 0.5) * 10))),
        pendingOrders: Math.max(15, Math.min(35, prev.pendingOrders + Math.floor((Math.random() - 0.5) * 4))),
      }))
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  // Dashboard stats
  const dashboardStats = {
    totalRevenue: 2450000,
    totalOrders: 156,
    totalProducts: 324,
    totalCustomers: 89,
    lowStockItems: 12,
    pendingOrders: 8,
    monthlyGrowth: 15.2,
    averageOrderValue: 15705,
  }

  const recentActivity = [
    { type: "order", message: "คำสั่งซื้อใหม่ #ORD-2024-001", time: "5 นาทีที่แล้ว", status: "new" },
    { type: "stock", message: "สินค้า LB-250G เหลือน้อย (10 ชิ้น)", time: "15 นาทีที่แล้ว", status: "warning" },
    { type: "customer", message: "ลูกค้าใหม่ลงทะเบียน", time: "1 ชั่วโมงที่แล้ว", status: "info" },
    { type: "payment", message: "ได้รับชำระเงิน ORD-2024-002", time: "2 ชั่วโมงที่แล้ว", status: "success" },
  ]

  const handleRefresh = async () => {
    setIsLoading(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))
    setIsLoading(false)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "text-green-600 bg-green-100"
      case "pending":
        return "text-yellow-600 bg-yellow-100"
      case "processing":
        return "text-blue-600 bg-blue-100"
      case "shipped":
        return "text-purple-600 bg-purple-100"
      case "cancelled":
        return "text-red-600 bg-red-100"
      default:
        return "text-gray-600 bg-gray-100"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "pending":
        return <Clock className="h-4 w-4 text-yellow-500" />
      case "processing":
        return <RefreshCw className="h-4 w-4 text-blue-500" />
      case "shipped":
        return <Package className="h-4 w-4 text-purple-500" />
      default:
        return <AlertTriangle className="h-4 w-4 text-gray-500" />
    }
  }

  const Sidebar = () => (
    <div
      className={`bg-gray-900 text-white h-screen fixed left-0 top-0 z-50 transition-all duration-300 ${sidebarOpen ? "w-64" : "w-16"}`}
    >
      <div className="p-4">
        <div className="flex items-center justify-between">
          <div className={`flex items-center space-x-2 ${!sidebarOpen && "hidden"}`}>
            <Package2 className="h-8 w-8 text-blue-400" />
            <h1 className="text-xl font-bold">KDP Admin</h1>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="text-white hover:bg-gray-800"
          >
            {sidebarOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </Button>
        </div>
      </div>

      <nav className="mt-8">
        <div className="px-4 space-y-2">
          {[
            { id: "dashboard", label: "แดชบอร์ด", icon: LayoutDashboard },
            { id: "products", label: "จัดการสินค้า", icon: Package },
            { id: "orders", label: "คำสั่งซื้อ", icon: ShoppingCart },
            { id: "customers", label: "ลูกค้า", icon: Users },
            { id: "analytics", label: "รายงาน", icon: BarChart3 },
            { id: "settings", label: "ตั้งค่า", icon: Settings },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors ${
                activeTab === item.id ? "bg-blue-600 text-white" : "text-gray-300 hover:bg-gray-800 hover:text-white"
              }`}
            >
              <item.icon className="h-5 w-5" />
              {sidebarOpen && <span>{item.label}</span>}
            </button>
          ))}
        </div>
      </nav>

      <div className="absolute bottom-4 left-4 right-4">
        <div className={`flex items-center space-x-3 p-3 bg-gray-800 rounded-lg ${!sidebarOpen && "justify-center"}`}>
          <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
            <User className="h-4 w-4 text-white" />
          </div>
          {sidebarOpen && (
            <div className="flex-1">
              <p className="text-sm font-medium">Admin User</p>
              <p className="text-xs text-gray-400">admin@kdp.co.th</p>
            </div>
          )}
          <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  )

  const DashboardContentNew = () => (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
              <p className="text-gray-600 mt-2">ภาพรวมการจัดการร้านค้า</p>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" onClick={handleRefresh} disabled={isLoading}>
                <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? "animate-spin" : ""}`} />
                {isLoading ? "กำลังอัพเดท..." : "รีเฟรช"}
              </Button>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                ส่งออกรายงาน
              </Button>
              <Link href="/admin/advanced">
                <Button>
                  <Settings className="h-4 w-4 mr-2" />
                  Advanced Admin
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Users</p>
                  <p className="text-2xl font-bold mt-1">{stats.totalUsers.toLocaleString()}</p>
                  <p className="text-xs text-green-600 mt-1">+{stats.monthlyGrowth}% from last month</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <Users className="h-6 w-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Products</p>
                  <p className="text-2xl font-bold mt-1">{stats.totalProducts}</p>
                  <p className="text-xs text-yellow-600 mt-1">{stats.lowStockItems} low stock items</p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <Package className="h-6 w-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Orders</p>
                  <p className="text-2xl font-bold mt-1">{stats.totalOrders}</p>
                  <p className="text-xs text-blue-600 mt-1">{stats.pendingOrders} pending orders</p>
                </div>
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                  <ShoppingCart className="h-6 w-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Revenue</p>
                  <p className="text-2xl font-bold mt-1">฿{stats.totalRevenue.toLocaleString()}</p>
                  <p className="text-xs text-green-600 mt-1">+{stats.monthlyGrowth}% from last month</p>
                </div>
                <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                  <DollarSign className="h-6 w-6 text-orange-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Recent Orders */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Recent Orders</span>
                <Link href="/admin/orders">
                  <Button variant="outline" size="sm">
                    View All
                  </Button>
                </Link>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockRecentOrders.map((order) => (
                  <div
                    key={order.id}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50"
                  >
                    <div className="flex items-center space-x-4">
                      {getStatusIcon(order.status)}
                      <div>
                        <h3 className="font-semibold">{order.id}</h3>
                        <p className="text-sm text-gray-600">{order.customer}</p>
                        <p className="text-xs text-gray-500">{order.product}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold">฿{order.amount.toLocaleString()}</p>
                      <Badge className={getStatusColor(order.status)}>{order.status}</Badge>
                      <p className="text-xs text-gray-500 mt-1">{new Date(order.date).toLocaleDateString()}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Low Stock Alert */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <AlertTriangle className="h-5 w-5 mr-2 text-yellow-500" />
                Low Stock Alert
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockLowStockProducts.map((product) => (
                  <div key={product.id} className="p-3 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-sm">{product.name}</h4>
                      <Badge variant="outline" className="text-xs">
                        {product.category}
                      </Badge>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span>Current: {product.stock}</span>
                        <span>Min: {product.minStock}</span>
                      </div>
                      <Progress value={(product.stock / product.minStock) * 100} className="h-2" />
                      <Button size="sm" className="w-full">
                        Reorder Now
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Top Products & Quick Actions */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Top Products */}
          <Card>
            <CardHeader>
              <CardTitle>Top Selling Products</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockTopProducts.map((product, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <span className="text-sm font-bold text-blue-600">#{index + 1}</span>
                      </div>
                      <div>
                        <h4 className="font-medium">{product.name}</h4>
                        <p className="text-sm text-gray-600">{product.sales} units sold</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold">฿{product.revenue.toLocaleString()}</p>
                      <p className="text-xs text-gray-500">Revenue</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <Link href="/admin/products">
                  <Button
                    variant="outline"
                    className="w-full h-20 flex flex-col items-center justify-center bg-transparent"
                  >
                    <Package className="h-6 w-6 mb-2" />
                    <span>Manage Products</span>
                  </Button>
                </Link>

                <Link href="/admin/orders">
                  <Button
                    variant="outline"
                    className="w-full h-20 flex flex-col items-center justify-center bg-transparent"
                  >
                    <ShoppingCart className="h-6 w-6 mb-2" />
                    <span>View Orders</span>
                  </Button>
                </Link>

                <Link href="/admin/users">
                  <Button
                    variant="outline"
                    className="w-full h-20 flex flex-col items-center justify-center bg-transparent"
                  >
                    <Users className="h-6 w-6 mb-2" />
                    <span>Manage Users</span>
                  </Button>
                </Link>

                <Link href="/admin/analytics">
                  <Button
                    variant="outline"
                    className="w-full h-20 flex flex-col items-center justify-center bg-transparent"
                  >
                    <BarChart3 className="h-6 w-6 mb-2" />
                    <span>View Analytics</span>
                  </Button>
                </Link>

                <Link href="/admin/inventory">
                  <Button
                    variant="outline"
                    className="w-full h-20 flex flex-col items-center justify-center bg-transparent"
                  >
                    <AlertTriangle className="h-6 w-6 mb-2" />
                    <span>Inventory Alert</span>
                  </Button>
                </Link>

                <Link href="/admin/settings">
                  <Button
                    variant="outline"
                    className="w-full h-20 flex flex-col items-center justify-center bg-transparent"
                  >
                    <Settings className="h-6 w-6 mb-2" />
                    <span>Settings</span>
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )

  const DashboardContent = () => <DashboardContentNew />

  const ProductsContent = () => (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">จัดการสินค้า</h2>
          <p className="text-gray-600">จัดการสินค้าทั้งหมดในระบบ</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <Upload className="h-4 w-4 mr-2" />
            นำเข้า Excel
          </Button>
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            ส่งออก
          </Button>
          <Button onClick={() => setIsAddProductOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            เพิ่มสินค้า
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-4">
            <div className="flex-1 min-w-64">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="ค้นหาสินค้า รหัส หรือชื่อ..."
                  className="pl-10"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <Select>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="หมวดหมู่" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">ทั้งหมด</SelectItem>
                <SelectItem value="malleable-iron">Malleable Iron</SelectItem>
                <SelectItem value="covers">Covers</SelectItem>
                <SelectItem value="gaskets">Gaskets</SelectItem>
              </SelectContent>
            </Select>
            <Select>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="สถานะ" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">ทั้งหมด</SelectItem>
                <SelectItem value="active">ใช้งาน</SelectItem>
                <SelectItem value="inactive">ไม่ใช้งาน</SelectItem>
                <SelectItem value="low_stock">เหลือน้อย</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline">
              <Filter className="h-4 w-4 mr-2" />
              ตัวกรอง
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Products Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left p-4 font-medium">สินค้า</th>
                  <th className="text-left p-4 font-medium">หมวดหมู่</th>
                  <th className="text-left p-4 font-medium">ราคา</th>
                  <th className="text-left p-4 font-medium">คงเหลือ</th>
                  <th className="text-left p-4 font-medium">สถานะ</th>
                  <th className="text-left p-4 font-medium">อัพเดท</th>
                  <th className="text-left p-4 font-medium">จัดการ</th>
                </tr>
              </thead>
              <tbody>
                {mockProducts.map((product) => (
                  <tr key={product.id} className="border-t hover:bg-gray-50">
                    <td className="p-4">
                      <div className="flex items-center space-x-3">
                        <Image
                          src={product.image || "/placeholder.svg"}
                          alt={product.code}
                          width={50}
                          height={50}
                          className="rounded"
                        />
                        <div>
                          <p className="font-medium">{product.code}</p>
                          <p className="text-sm text-gray-600">{product.name}</p>
                          <p className="text-xs text-gray-500">Size: {product.size}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-4">
                      <Badge variant="outline">{product.category}</Badge>
                    </td>
                    <td className="p-4">
                      <div>
                        <p className="font-medium">฿{product.price.toLocaleString()}</p>
                        <p className="text-sm text-gray-500">ต้นทุน: ฿{product.cost.toLocaleString()}</p>
                      </div>
                    </td>
                    <td className="p-4">
                      <div>
                        <p className="font-medium">{product.qty} ชิ้น</p>
                        <p className="text-xs text-gray-500">ขั้นต่ำ: {product.minStock}</p>
                        {product.qty <= product.minStock && (
                          <Badge variant="destructive" className="text-xs mt-1">
                            เหลือน้อย
                          </Badge>
                        )}
                      </div>
                    </td>
                    <td className="p-4">
                      <Badge variant={product.status === "active" ? "default" : "secondary"}>
                        {product.status === "active" ? "ใช้งาน" : "เหลือน้อย"}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <p className="text-sm">{product.lastUpdated}</p>
                      <p className="text-xs text-gray-500">ตำแหน่ง: {product.location}</p>
                    </td>
                    <td className="p-4">
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline" className="text-red-600 hover:text-red-700 bg-transparent">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Add Product Dialog */}
      <Dialog open={isAddProductOpen} onOpenChange={setIsAddProductOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>เพิ่มสินค้าใหม่</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-4">
              <div>
                <Label htmlFor="code">รหัสสินค้า</Label>
                <Input id="code" placeholder="เช่น LB-100G" />
              </div>
              <div>
                <Label htmlFor="name">ชื่อสินค้า</Label>
                <Input id="name" placeholder="ชื่อสินค้าภาษาไทย" />
              </div>
              <div>
                <Label htmlFor="category">หมวดหมู่</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="เลือกหมวดหมู่" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="malleable-iron-lb">Malleable Iron LB</SelectItem>
                    <SelectItem value="malleable-iron-t">Malleable Iron T</SelectItem>
                    <SelectItem value="covers">Covers</SelectItem>
                    <SelectItem value="gaskets">Gaskets</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="size">ขนาด</Label>
                <Input id="size" placeholder='เช่น 3/4"' />
              </div>
              <div>
                <Label htmlFor="material">วัสดุ</Label>
                <Input id="material" placeholder="เช่น Malleable Iron HDG" />
              </div>
            </div>
            <div className="space-y-4">
              <div>
                <Label htmlFor="price">ราคาขาย</Label>
                <Input id="price" type="number" placeholder="0.00" />
              </div>
              <div>
                <Label htmlFor="cost">ราคาต้นทุน</Label>
                <Input id="cost" type="number" placeholder="0.00" />
              </div>
              <div>
                <Label htmlFor="qty">จำนวนคงเหลือ</Label>
                <Input id="qty" type="number" placeholder="0" />
              </div>
              <div>
                <Label htmlFor="minStock">จำนวนขั้นต่ำ</Label>
                <Input id="minStock" type="number" placeholder="0" />
              </div>
              <div>
                <Label htmlFor="location">ตำแหน่งเก็บ</Label>
                <Input id="location" placeholder="เช่น A-01-15" />
              </div>
            </div>
            <div className="col-span-2 space-y-4">
              <div>
                <Label htmlFor="description">รายละเอียด</Label>
                <Textarea id="description" placeholder="รายละเอียดสินค้า..." />
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="active" />
                <Label htmlFor="active">เปิดใช้งาน</Label>
              </div>
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setIsAddProductOpen(false)}>
                  ยกเลิก
                </Button>
                <Button>บันทึก</Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )

  const OrdersContent = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">จัดการคำสั่งซื้อ</h2>
          <p className="text-gray-600">ติดตามและจัดการคำสั่งซื้อทั้งหมด</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            ส่งออกรายงาน
          </Button>
          <Button variant="outline">
            <RefreshCwIcon className="h-4 w-4 mr-2" />
            รีเฟรช
          </Button>
        </div>
      </div>

      {/* Order Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">รอดำเนินการ</p>
                <p className="text-2xl font-bold text-orange-600">8</p>
              </div>
              <AlertCircle className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">ยืนยันแล้ว</p>
                <p className="text-2xl font-bold text-blue-600">15</p>
              </div>
              <CheckCircle className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">จัดส่งแล้ว</p>
                <p className="text-2xl font-bold text-green-600">42</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">ยกเลิก</p>
                <p className="text-2xl font-bold text-red-600">3</p>
              </div>
              <XCircle className="h-8 w-8 text-red-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Orders Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left p-4 font-medium">คำสั่งซื้อ</th>
                  <th className="text-left p-4 font-medium">ลูกค้า</th>
                  <th className="text-left p-4 font-medium">ยอดรวม</th>
                  <th className="text-left p-4 font-medium">สถานะ</th>
                  <th className="text-left p-4 font-medium">วันที่</th>
                  <th className="text-left p-4 font-medium">การชำระ</th>
                  <th className="text-left p-4 font-medium">จัดการ</th>
                </tr>
              </thead>
              <tbody>
                {mockOrders.map((order) => (
                  <tr key={order.id} className="border-t hover:bg-gray-50">
                    <td className="p-4">
                      <div>
                        <p className="font-medium">{order.id}</p>
                        <p className="text-sm text-gray-600">{order.items} รายการ</p>
                      </div>
                    </td>
                    <td className="p-4">
                      <div>
                        <p className="font-medium">{order.customer}</p>
                        <p className="text-sm text-gray-600">{order.email}</p>
                        <p className="text-sm text-gray-600">{order.phone}</p>
                      </div>
                    </td>
                    <td className="p-4">
                      <p className="font-medium">฿{order.total.toLocaleString()}</p>
                    </td>
                    <td className="p-4">
                      <Badge
                        variant={
                          order.status === "pending"
                            ? "secondary"
                            : order.status === "confirmed"
                              ? "default"
                              : order.status === "shipped"
                                ? "outline"
                                : "destructive"
                        }
                      >
                        {order.status === "pending" && "รอดำเนินการ"}
                        {order.status === "confirmed" && "ยืนยันแล้ว"}
                        {order.status === "shipped" && "จัดส่งแล้ว"}
                        {order.status === "cancelled" && "ยกเลิก"}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <p className="text-sm">{order.date}</p>
                    </td>
                    <td className="p-4">
                      <Badge variant="outline">
                        {order.paymentMethod === "bank_transfer" && "โอนเงิน"}
                        {order.paymentMethod === "credit_card" && "บัตรเครดิต"}
                        {order.paymentMethod === "cash" && "เงินสด"}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <FileText className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const CustomersContent = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">จัดการลูกค้า</h2>
          <p className="text-gray-600">ข้อมูลลูกค้าและประวัติการซื้อ</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            ส่งออกข้อมูล
          </Button>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            เพิ่มลูกค้า
          </Button>
        </div>
      </div>

      {/* Customer Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">ลูกค้าทั้งหมด</p>
                <p className="text-2xl font-bold">89</p>
              </div>
              <Users className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">ลูกค้าองค์กร</p>
                <p className="text-2xl font-bold">45</p>
              </div>
              <UserCheck className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">ลูกค้าใหม่เดือนนี้</p>
                <p className="text-2xl font-bold">12</p>
              </div>
              <TrendingUp className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Customers Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left p-4 font-medium">ลูกค้า</th>
                  <th className="text-left p-4 font-medium">ประเภท</th>
                  <th className="text-left p-4 font-medium">คำสั่งซื้อ</th>
                  <th className="text-left p-4 font-medium">ยอดรวม</th>
                  <th className="text-left p-4 font-medium">ซื้อล่าสุด</th>
                  <th className="text-left p-4 font-medium">สถานะ</th>
                  <th className="text-left p-4 font-medium">จัดการ</th>
                </tr>
              </thead>
              <tbody>
                {mockCustomers.map((customer) => (
                  <tr key={customer.id} className="border-t hover:bg-gray-50">
                    <td className="p-4">
                      <div>
                        <p className="font-medium">{customer.name}</p>
                        <p className="text-sm text-gray-600">{customer.email}</p>
                        <p className="text-sm text-gray-600">{customer.phone}</p>
                      </div>
                    </td>
                    <td className="p-4">
                      <Badge variant={customer.type === "corporate" ? "default" : "outline"}>
                        {customer.type === "corporate" ? "องค์กร" : "บุคคล"}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <p className="font-medium">{customer.totalOrders} คำสั่ง</p>
                    </td>
                    <td className="p-4">
                      <p className="font-medium">฿{customer.totalSpent.toLocaleString()}</p>
                    </td>
                    <td className="p-4">
                      <p className="text-sm">{customer.lastOrder}</p>
                    </td>
                    <td className="p-4">
                      <Badge variant={customer.status === "active" ? "default" : "secondary"}>
                        {customer.status === "active" ? "ใช้งาน" : "ไม่ใช้งาน"}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Mail className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const AnalyticsContent = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">รายงานและการวิเคราะห์</h2>
          <p className="text-gray-600">ข้อมูลสถิติและรายงานการขาย</p>
        </div>
        <div className="flex space-x-2">
          <Select>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="เลือกช่วงเวลา" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="today">วันนี้</SelectItem>
              <SelectItem value="week">สัปดาห์นี้</SelectItem>
              <SelectItem value="month">เดือนนี้</SelectItem>
              <SelectItem value="year">ปีนี้</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            ส่งออกรายงาน
          </Button>
        </div>
      </div>

      {/* Analytics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">ยอดขายวันนี้</p>
                <p className="text-2xl font-bold">฿125,000</p>
                <p className="text-xs text-green-600 flex items-center mt-1">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  +12% จากเมื่อวาน
                </p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <DollarSign className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">คำสั่งซื้อวันนี้</p>
                <p className="text-2xl font-bold">24</p>
                <p className="text-xs text-blue-600">เฉลี่ย ฿5,208 ต่อคำสั่ง</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <ShoppingCart className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">สินค้าขายดี</p>
                <p className="text-2xl font-bold">T-75G</p>
                <p className="text-xs text-purple-600">ขาย 45 ชิ้นวันนี้</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                <Star className="h-6 w-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">อัตราแปลง</p>
                <p className="text-2xl font-bold">3.2%</p>
                <p className="text-xs text-orange-600">จากผู้เยี่ยมชม 750 คน</p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                <TrendingUp className="h-6 w-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Placeholder */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>ยอดขายรายเดือน</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 bg-gray-100 rounded-lg flex items-center justify-center">
              <p className="text-gray-500">กราฟยอดขายรายเดือน</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>สินค้าขายดี Top 10</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {mockProducts.slice(0, 5).map((product, index) => (
                <div key={product.id} className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <span className="text-sm font-medium text-gray-500">#{index + 1}</span>
                    <span className="text-sm">{product.code}</span>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">฿{(product.price * 10).toLocaleString()}</p>
                    <p className="text-xs text-gray-500">10 ชิ้น</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )

  const SettingsContent = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">ตั้งค่าระบบ</h2>
        <p className="text-gray-600">จัดการการตั้งค่าทั่วไปของระบบ</p>
      </div>

      <Tabs defaultValue="general" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="general">ทั่วไป</TabsTrigger>
          <TabsTrigger value="payment">การชำระเงิน</TabsTrigger>
          <TabsTrigger value="shipping">การจัดส่ง</TabsTrigger>
          <TabsTrigger value="notifications">การแจ้งเตือน</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>ข้อมูลบริษัท</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="company-name">ชื่อบริษัท</Label>
                  <Input id="company-name" defaultValue="บริษัท เคดีพี เอ็นจิเนียริ่ง แอนด์ ซัพพลาย จำกัด" />
                </div>
                <div>
                  <Label htmlFor="tax-id">เลขประจำตัวผู้เสียภาษี</Label>
                  <Input id="tax-id" defaultValue="0123456789012" />
                </div>
                <div>
                  <Label htmlFor="phone">โทรศัพท์</Label>
                  <Input id="phone" defaultValue="0-2925-9633-4" />
                </div>
                <div>
                  <Label htmlFor="email">อีเมล</Label>
                  <Input id="email" defaultValue="info@kdp.co.th" />
                </div>
              </div>
              <div>
                <Label htmlFor="address">ที่อยู่</Label>
                <Textarea
                  id="address"
                  defaultValue="14/1763 Moo 13 Kanchanaphisek Rd. Bang Bua Thong, Bang Bua Thong Nonthaburi 11110"
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>การตั้งค่าเว็บไซต์</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="site-title">ชื่อเว็บไซต์</Label>
                <Input id="site-title" defaultValue="KDP Engineering & Supply - O-Z/Gedney Conduit" />
              </div>
              <div>
                <Label htmlFor="site-description">คำอธิบายเว็บไซต์</Label>
                <Textarea id="site-description" defaultValue="ตัวแทนจำหน่าย O-Z/Gedney Conduit อย่างเป็นทางการ" />
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="maintenance" />
                <Label htmlFor="maintenance">โหมดปิดปรับปรุง</Label>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payment" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>วิธีการชำระเงิน</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <Switch id="bank-transfer" defaultChecked />
                    <div>
                      <p className="font-medium">โอนเงินผ่านธนาคาร</p>
                      <p className="text-sm text-gray-600">รับชำระผ่านการโอนเงิน</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">
                    ตั้งค่า
                  </Button>
                </div>

                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <Switch id="credit-card" />
                    <div>
                      <p className="font-medium">บัตรเครดิต/เดบิต</p>
                      <p className="text-sm text-gray-600">รับชำระผ่านบัตร</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">
                    ตั้งค่า
                  </Button>
                </div>

                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <Switch id="cash" defaultChecked />
                    <div>
                      <p className="font-medium">เงินสด</p>
                      <p className="text-sm text-gray-600">รับชำระเงินสด</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">
                    ตั้งค่า
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="shipping" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>การจัดส่ง</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="free-shipping">ยอดขั้นต่ำสำหรับจัดส่งฟรี</Label>
                <Input id="free-shipping" type="number" defaultValue="5000" />
              </div>
              <div>
                <Label htmlFor="shipping-cost">ค่าจัดส่งมาตรฐาน</Label>
                <Input id="shipping-cost" type="number" defaultValue="100" />
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="same-day" />
                <Label htmlFor="same-day">บริการจัดส่งด่วนในวันเดียวกัน</Label>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>การแจ้งเตือน</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">คำสั่งซื้อใหม่</p>
                    <p className="text-sm text-gray-600">แจ้งเตือนเมื่อมีคำสั่งซื้อใหม่</p>
                  </div>
                  <Switch defaultChecked />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">สินค้าเหลือน้อย</p>
                    <p className="text-sm text-gray-600">แจ้งเตือนเมื่อสินค้าเหลือน้อย</p>
                  </div>
                  <Switch defaultChecked />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">การชำระเงิน</p>
                    <p className="text-sm text-gray-600">แจ้งเตือนเมื่อได้รับการชำระเงิน</p>
                  </div>
                  <Switch defaultChecked />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex justify-end">
        <Button>บันทึกการตั้งค่า</Button>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <Sidebar />

      <div className={`transition-all duration-300 ${sidebarOpen ? "ml-64" : "ml-16"}`}>
        {/* Top Bar */}
        <div className="bg-white shadow-sm border-b p-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                {activeTab === "dashboard" && "แดชบอร์ด"}
                {activeTab === "products" && "จัดการสินค้า"}
                {activeTab === "orders" && "คำสั่งซื้อ"}
                {activeTab === "customers" && "ลูกค้า"}
                {activeTab === "analytics" && "รายงาน"}
                {activeTab === "settings" && "ตั้งค่า"}
              </h1>
              <p className="text-gray-600">
                {new Date().toLocaleDateString("th-TH", {
                  weekday: "long",
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </p>
            </div>

            <div className="flex items-center space-x-4">
              <Button variant="outline" size="sm">
                <Bell className="h-4 w-4 mr-2" />
                แจ้งเตือน
                <Badge className="ml-2">3</Badge>
              </Button>
              <Button variant="outline" size="sm">
                <Globe className="h-4 w-4 mr-2" />
                ดูหน้าเว็บ
              </Button>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="p-6">
          {activeTab === "dashboard" && <DashboardContent />}
          {activeTab === "products" && <ProductsContent />}
          {activeTab === "orders" && <OrdersContent />}
          {activeTab === "customers" && <CustomersContent />}
          {activeTab === "analytics" && <AnalyticsContent />}
          {activeTab === "settings" && <SettingsContent />}
        </div>
      </div>
    </div>
  )
}
