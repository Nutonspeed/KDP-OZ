"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Code,
  Key,
  Activity,
  BarChart3,
  Globe,
  Clock,
  Users,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Eye,
  Edit,
  Trash2,
  Plus,
  Copy,
  RefreshCw,
  Download,
  Monitor,
  TrendingUp,
  FileText,
  Search,
  Filter,
} from "lucide-react"

// Mock data for API management
const mockApiKeys = [
  {
    id: 1,
    name: "Mobile App - Production",
    key: "kdp_live_sk_1234567890abcdef",
    permissions: ["read", "write"],
    lastUsed: "2024-01-15 14:30",
    requests: 15420,
    status: "active",
    rateLimit: "1000/hour",
    createdBy: "Admin User",
    createdAt: "2024-01-01",
  },
  {
    id: 2,
    name: "Website Integration",
    key: "kdp_live_sk_abcdef1234567890",
    permissions: ["read"],
    lastUsed: "2024-01-15 13:45",
    requests: 8950,
    status: "active",
    rateLimit: "500/hour",
    createdBy: "Developer",
    createdAt: "2024-01-05",
  },
  {
    id: 3,
    name: "Third Party Service",
    key: "kdp_test_sk_9876543210fedcba",
    permissions: ["read"],
    lastUsed: "2024-01-10 09:20",
    requests: 234,
    status: "inactive",
    rateLimit: "100/hour",
    createdBy: "Sales Manager",
    createdAt: "2024-01-10",
  },
]

const mockApiEndpoints = [
  {
    id: 1,
    method: "GET",
    path: "/api/v2/products",
    description: "ดึงรายการสินค้าทั้งหมด",
    requests: 45230,
    avgResponseTime: 245,
    errorRate: 0.02,
    status: "healthy",
    lastUpdated: "2024-01-15",
  },
  {
    id: 2,
    method: "POST",
    path: "/api/v2/orders",
    description: "สร้างคำสั่งซื้อใหม่",
    requests: 12450,
    avgResponseTime: 890,
    errorRate: 0.15,
    status: "warning",
    lastUpdated: "2024-01-15",
  },
  {
    id: 3,
    method: "GET",
    path: "/api/v2/customers/{id}",
    description: "ดึงข้อมูลลูกค้า",
    requests: 8920,
    avgResponseTime: 156,
    errorRate: 0.01,
    status: "healthy",
    lastUpdated: "2024-01-15",
  },
  {
    id: 4,
    method: "PUT",
    path: "/api/v2/inventory/{id}",
    description: "อัพเดทสต็อกสินค้า",
    requests: 3450,
    avgResponseTime: 1250,
    errorRate: 2.5,
    status: "error",
    lastUpdated: "2024-01-15",
  },
]

const mockApiLogs = [
  {
    id: 1,
    timestamp: "2024-01-15 14:30:25",
    method: "GET",
    endpoint: "/api/v2/products",
    statusCode: 200,
    responseTime: 245,
    userAgent: "KDP-Mobile-App/2.1.0",
    ip: "192.168.1.100",
    apiKey: "kdp_live_sk_1234...cdef",
  },
  {
    id: 2,
    timestamp: "2024-01-15 14:30:20",
    method: "POST",
    endpoint: "/api/v2/orders",
    statusCode: 201,
    responseTime: 890,
    userAgent: "KDP-Website/1.0",
    ip: "192.168.1.101",
    apiKey: "kdp_live_sk_abcd...7890",
  },
  {
    id: 3,
    timestamp: "2024-01-15 14:30:15",
    method: "GET",
    endpoint: "/api/v2/customers/123",
    statusCode: 404,
    responseTime: 156,
    userAgent: "PostmanRuntime/7.32.3",
    ip: "192.168.1.102",
    apiKey: "kdp_test_sk_9876...dcba",
  },
]

export default function ApiManagement() {
  const [activeTab, setActiveTab] = useState("overview")
  const [searchTerm, setSearchTerm] = useState("")

  // API Overview Dashboard
  const ApiOverview = () => (
    <div className="space-y-6">
      {/* API Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Requests</p>
                <p className="text-2xl font-bold">125,420</p>
                <p className="text-xs text-green-600 flex items-center mt-1">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  +15.2% จากเดือนที่แล้ว
                </p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <Activity className="h-6 w-6 text-blue-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-400 to-blue-600"></div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Avg Response Time</p>
                <p className="text-2xl font-bold">245ms</p>
                <p className="text-xs text-green-600">-12ms จากเดือนที่แล้ว</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <Clock className="h-6 w-6 text-green-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-green-400 to-green-600"></div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Error Rate</p>
                <p className="text-2xl font-bold">0.08%</p>
                <p className="text-xs text-green-600">-0.02% จากเดือนที่แล้ว</p>
              </div>
              <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                <AlertTriangle className="h-6 w-6 text-red-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-red-400 to-red-600"></div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active API Keys</p>
                <p className="text-2xl font-bold">12</p>
                <p className="text-xs text-blue-600">3 ใหม่เดือนนี้</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                <Key className="h-6 w-6 text-purple-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-purple-400 to-purple-600"></div>
          </CardContent>
        </Card>
      </div>

      {/* API Performance Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>API Request Volume</span>
              <Select defaultValue="24h">
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1h">1 ชั่วโมง</SelectItem>
                  <SelectItem value="24h">24 ชั่วโมง</SelectItem>
                  <SelectItem value="7d">7 วัน</SelectItem>
                  <SelectItem value="30d">30 วัน</SelectItem>
                </SelectContent>
              </Select>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80 bg-gradient-to-br from-blue-50 to-indigo-100 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <BarChart3 className="h-16 w-16 text-blue-500 mx-auto mb-4" />
                <p className="text-gray-600">กราฟปริมาณการใช้งาน API</p>
                <p className="text-sm text-gray-500">แสดงจำนวน Request ต่อช่วงเวลา</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Response Time Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80 bg-gradient-to-br from-green-50 to-teal-100 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <Clock className="h-16 w-16 text-green-500 mx-auto mb-4" />
                <p className="text-gray-600">การกระจายตัวของ Response Time</p>
                <p className="text-sm text-gray-500">แสดงประสิทธิภาพ API แต่ละ Endpoint</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Top Endpoints */}
      <Card>
        <CardHeader>
          <CardTitle>API Endpoints ที่ใช้งานมากที่สุด</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {mockApiEndpoints.slice(0, 5).map((endpoint, index) => (
              <div key={endpoint.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-4">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                    <span className="text-sm font-bold text-blue-600">#{index + 1}</span>
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <Badge
                        variant={
                          endpoint.method === "GET"
                            ? "default"
                            : endpoint.method === "POST"
                              ? "secondary"
                              : endpoint.method === "PUT"
                                ? "outline"
                                : "destructive"
                        }
                      >
                        {endpoint.method}
                      </Badge>
                      <code className="text-sm font-mono">{endpoint.path}</code>
                    </div>
                    <p className="text-sm text-gray-600 mt-1">{endpoint.description}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium">{endpoint.requests.toLocaleString()} requests</p>
                  <p className="text-sm text-gray-600">{endpoint.avgResponseTime}ms avg</p>
                  <div className="flex items-center space-x-1 mt-1">
                    <div
                      className={`w-2 h-2 rounded-full ${
                        endpoint.status === "healthy"
                          ? "bg-green-500"
                          : endpoint.status === "warning"
                            ? "bg-yellow-500"
                            : "bg-red-500"
                      }`}
                    />
                    <span className="text-xs text-gray-500">{endpoint.errorRate}% error</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )

  // API Keys Management
  const ApiKeysManagement = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-bold">API Keys Management</h3>
          <p className="text-gray-600">จัดการ API Keys และสิทธิ์การเข้าถึง</p>
        </div>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          สร้าง API Key ใหม่
        </Button>
      </div>

      {/* API Keys Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Active Keys</p>
                <p className="text-2xl font-bold text-green-600">8</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Inactive Keys</p>
                <p className="text-2xl font-bold text-gray-600">4</p>
              </div>
              <XCircle className="h-8 w-8 text-gray-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Rate Limited</p>
                <p className="text-2xl font-bold text-orange-600">2</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Requests</p>
                <p className="text-2xl font-bold text-blue-600">24.6K</p>
              </div>
              <Activity className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* API Keys Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left p-4 font-medium">API Key</th>
                  <th className="text-left p-4 font-medium">สิทธิ์</th>
                  <th className="text-left p-4 font-medium">การใช้งาน</th>
                  <th className="text-left p-4 font-medium">Rate Limit</th>
                  <th className="text-left p-4 font-medium">สถานะ</th>
                  <th className="text-left p-4 font-medium">ใช้งานล่าสุด</th>
                  <th className="text-left p-4 font-medium">จัดการ</th>
                </tr>
              </thead>
              <tbody>
                {mockApiKeys.map((apiKey) => (
                  <tr key={apiKey.id} className="border-t hover:bg-gray-50">
                    <td className="p-4">
                      <div>
                        <p className="font-medium">{apiKey.name}</p>
                        <div className="flex items-center space-x-2 mt-1">
                          <code className="text-xs bg-gray-100 px-2 py-1 rounded">
                            {apiKey.key.substring(0, 20)}...
                          </code>
                          <Button size="sm" variant="ghost" className="h-6 w-6 p-0">
                            <Copy className="h-3 w-3" />
                          </Button>
                        </div>
                        <p className="text-xs text-gray-500 mt-1">
                          สร้างโดย {apiKey.createdBy} • {apiKey.createdAt}
                        </p>
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex flex-wrap gap-1">
                        {apiKey.permissions.map((permission) => (
                          <Badge key={permission} variant="outline" className="text-xs">
                            {permission === "read" && "อ่าน"}
                            {permission === "write" && "เขียน"}
                            {permission === "delete" && "ลบ"}
                          </Badge>
                        ))}
                      </div>
                    </td>
                    <td className="p-4">
                      <div>
                        <p className="font-medium">{apiKey.requests.toLocaleString()}</p>
                        <p className="text-xs text-gray-600">requests</p>
                      </div>
                    </td>
                    <td className="p-4">
                      <Badge variant="outline">{apiKey.rateLimit}</Badge>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-2">
                        <div
                          className={`w-2 h-2 rounded-full ${
                            apiKey.status === "active" ? "bg-green-500" : "bg-gray-400"
                          }`}
                        />
                        <Badge variant={apiKey.status === "active" ? "default" : "secondary"}>
                          {apiKey.status === "active" ? "ใช้งาน" : "ไม่ใช้งาน"}
                        </Badge>
                      </div>
                    </td>
                    <td className="p-4">
                      <p className="text-sm">{apiKey.lastUsed}</p>
                    </td>
                    <td className="p-4">
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <RefreshCw className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline" className="text-red-600 hover:text-red-700 bg-transparent">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Create New API Key Form */}
      <Card>
        <CardHeader>
          <CardTitle>สร้าง API Key ใหม่</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="key-name">ชื่อ API Key</Label>
              <Input id="key-name" placeholder="เช่น Mobile App Production" />
            </div>
            <div>
              <Label htmlFor="key-environment">Environment</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="เลือก Environment" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="production">Production</SelectItem>
                  <SelectItem value="staging">Staging</SelectItem>
                  <SelectItem value="development">Development</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <Label>สิทธิ์การเข้าถึง</Label>
            <div className="grid grid-cols-3 gap-4 mt-2">
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="read-permission" defaultChecked />
                <Label htmlFor="read-permission">อ่านข้อมูล (Read)</Label>
              </div>
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="write-permission" />
                <Label htmlFor="write-permission">เขียนข้อมูล (Write)</Label>
              </div>
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="delete-permission" />
                <Label htmlFor="delete-permission">ลบข้อมูล (Delete)</Label>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="rate-limit">Rate Limit</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="เลือก Rate Limit" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="100">100 requests/hour</SelectItem>
                  <SelectItem value="500">500 requests/hour</SelectItem>
                  <SelectItem value="1000">1,000 requests/hour</SelectItem>
                  <SelectItem value="5000">5,000 requests/hour</SelectItem>
                  <SelectItem value="unlimited">Unlimited</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="expiry-date">วันหมดอายุ (ไม่บังคับ)</Label>
              <Input id="expiry-date" type="date" />
            </div>
          </div>
          <div>
            <Label htmlFor="description">คำอธิบาย</Label>
            <Textarea id="description" placeholder="อธิบายการใช้งาน API Key นี้..." rows={3} />
          </div>
          <div className="flex space-x-2">
            <Button>
              <Key className="h-4 w-4 mr-2" />
              สร้าง API Key
            </Button>
            <Button variant="outline" className="bg-transparent">
              ยกเลิก
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  // API Documentation
  const ApiDocumentation = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-bold">API Documentation</h3>
          <p className="text-gray-600">เอกสารและตัวอย่างการใช้งาน API</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            ดาวน์โหลด OpenAPI Spec
          </Button>
          <Button variant="outline">
            <Globe className="h-4 w-4 mr-2" />
            Swagger UI
          </Button>
        </div>
      </div>

      {/* API Endpoints */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>API Endpoints</span>
            <div className="flex items-center space-x-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="ค้นหา endpoint..."
                  className="pl-10 w-64"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <Button variant="outline" size="sm">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left p-4 font-medium">Method</th>
                  <th className="text-left p-4 font-medium">Endpoint</th>
                  <th className="text-left p-4 font-medium">คำอธิบาย</th>
                  <th className="text-left p-4 font-medium">Requests</th>
                  <th className="text-left p-4 font-medium">Avg Response</th>
                  <th className="text-left p-4 font-medium">Error Rate</th>
                  <th className="text-left p-4 font-medium">สถานะ</th>
                  <th className="text-left p-4 font-medium">จัดการ</th>
                </tr>
              </thead>
              <tbody>
                {mockApiEndpoints.map((endpoint) => (
                  <tr key={endpoint.id} className="border-t hover:bg-gray-50">
                    <td className="p-4">
                      <Badge
                        variant={
                          endpoint.method === "GET"
                            ? "default"
                            : endpoint.method === "POST"
                              ? "secondary"
                              : endpoint.method === "PUT"
                                ? "outline"
                                : "destructive"
                        }
                      >
                        {endpoint.method}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <code className="text-sm font-mono bg-gray-100 px-2 py-1 rounded">{endpoint.path}</code>
                    </td>
                    <td className="p-4">
                      <p className="text-sm">{endpoint.description}</p>
                    </td>
                    <td className="p-4">
                      <p className="font-medium">{endpoint.requests.toLocaleString()}</p>
                    </td>
                    <td className="p-4">
                      <p className="font-medium">{endpoint.avgResponseTime}ms</p>
                    </td>
                    <td className="p-4">
                      <p
                        className={`font-medium ${
                          endpoint.errorRate < 0.1
                            ? "text-green-600"
                            : endpoint.errorRate < 1
                              ? "text-yellow-600"
                              : "text-red-600"
                        }`}
                      >
                        {endpoint.errorRate}%
                      </p>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-2">
                        <div
                          className={`w-2 h-2 rounded-full ${
                            endpoint.status === "healthy"
                              ? "bg-green-500"
                              : endpoint.status === "warning"
                                ? "bg-yellow-500"
                                : "bg-red-500"
                          }`}
                        />
                        <Badge
                          variant={
                            endpoint.status === "healthy"
                              ? "default"
                              : endpoint.status === "warning"
                                ? "secondary"
                                : "destructive"
                          }
                        >
                          {endpoint.status === "healthy" && "ปกติ"}
                          {endpoint.status === "warning" && "เตือน"}
                          {endpoint.status === "error" && "ข้อผิดพลาด"}
                        </Badge>
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Code className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <BarChart3 className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* API Examples */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>ตัวอย่างการใช้งาน</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h4 className="font-medium mb-2">GET /api/v2/products</h4>
                <div className="bg-gray-900 text-green-400 p-4 rounded-lg text-sm font-mono">
                  <div className="text-gray-400"># cURL</div>
                  <div>curl -X GET \</div>
                  <div className="ml-2">'https://api.kdp.co.th/v2/products' \</div>
                  <div className="ml-2">-H 'Authorization: Bearer YOUR_API_KEY' \</div>
                  <div className="ml-2">-H 'Content-Type: application/json'</div>
                </div>
              </div>
              <div>
                <h4 className="font-medium mb-2">Response</h4>
                <div className="bg-gray-900 text-blue-400 p-4 rounded-lg text-sm font-mono">
                  <div>{"{"}</div>
                  <div className="ml-2">"status": "success",</div>
                  <div className="ml-2">"data": [</div>
                  <div className="ml-4">{"{"}</div>
                  <div className="ml-6">"id": "T-75G",</div>
                  <div className="ml-6">"name": "T-75G Conduit",</div>
                  <div className="ml-6">"price": 450,</div>
                  <div className="ml-6">"stock": 150</div>
                  <div className="ml-4">{"}"}</div>
                  <div className="ml-2">]</div>
                  <div>{"}"}</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Authentication</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h4 className="font-medium mb-2">Bearer Token</h4>
                <p className="text-sm text-gray-600 mb-2">ใช้ API Key ในส่วน Header ของ HTTP Request</p>
                <div className="bg-gray-900 text-yellow-400 p-4 rounded-lg text-sm font-mono">
                  <div>Authorization: Bearer kdp_live_sk_1234567890abcdef</div>
                </div>
              </div>
              <div>
                <h4 className="font-medium mb-2">Rate Limiting</h4>
                <p className="text-sm text-gray-600 mb-2">API มีการจำกัดจำนวน Request ตาม API Key</p>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>X-RateLimit-Limit:</span>
                    <span className="font-mono">1000</span>
                  </div>
                  <div className="flex justify-between">
                    <span>X-RateLimit-Remaining:</span>
                    <span className="font-mono">999</span>
                  </div>
                  <div className="flex justify-between">
                    <span>X-RateLimit-Reset:</span>
                    <span className="font-mono">1642694400</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )

  // API Logs & Monitoring
  const ApiLogs = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-bold">API Logs & Monitoring</h3>
          <p className="text-gray-600">ติดตามการใช้งาน API แบบเรียลไทม์</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <RefreshCw className="h-4 w-4 mr-2" />
            รีเฟรช
          </Button>
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            ส่งออกบันทึก
          </Button>
        </div>
      </div>

      {/* Real-time Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Requests/min</p>
                <p className="text-2xl font-bold text-blue-600">245</p>
              </div>
              <Activity className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Success Rate</p>
                <p className="text-2xl font-bold text-green-600">99.2%</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Avg Latency</p>
                <p className="text-2xl font-bold text-purple-600">245ms</p>
              </div>
              <Clock className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Active Connections</p>
                <p className="text-2xl font-bold text-orange-600">156</p>
              </div>
              <Users className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* API Logs Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>API Request Logs</span>
            <div className="flex items-center space-x-2">
              <Select defaultValue="all">
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">ทั้งหมด</SelectItem>
                  <SelectItem value="2xx">Success (2xx)</SelectItem>
                  <SelectItem value="4xx">Client Error (4xx)</SelectItem>
                  <SelectItem value="5xx">Server Error (5xx)</SelectItem>
                </SelectContent>
              </Select>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-sm text-gray-600">Live</span>
              </div>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left p-4 font-medium">เวลา</th>
                  <th className="text-left p-4 font-medium">Method</th>
                  <th className="text-left p-4 font-medium">Endpoint</th>
                  <th className="text-left p-4 font-medium">Status</th>
                  <th className="text-left p-4 font-medium">Response Time</th>
                  <th className="text-left p-4 font-medium">IP Address</th>
                  <th className="text-left p-4 font-medium">API Key</th>
                  <th className="text-left p-4 font-medium">จัดการ</th>
                </tr>
              </thead>
              <tbody>
                {mockApiLogs.map((log) => (
                  <tr key={log.id} className="border-t hover:bg-gray-50">
                    <td className="p-4">
                      <p className="text-sm font-mono">{log.timestamp}</p>
                    </td>
                    <td className="p-4">
                      <Badge
                        variant={
                          log.method === "GET"
                            ? "default"
                            : log.method === "POST"
                              ? "secondary"
                              : log.method === "PUT"
                                ? "outline"
                                : "destructive"
                        }
                      >
                        {log.method}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <code className="text-sm font-mono">{log.endpoint}</code>
                    </td>
                    <td className="p-4">
                      <Badge
                        variant={
                          log.statusCode >= 200 && log.statusCode < 300
                            ? "default"
                            : log.statusCode >= 400 && log.statusCode < 500
                              ? "secondary"
                              : "destructive"
                        }
                      >
                        {log.statusCode}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <p
                        className={`font-medium ${
                          log.responseTime < 200
                            ? "text-green-600"
                            : log.responseTime < 500
                              ? "text-yellow-600"
                              : "text-red-600"
                        }`}
                      >
                        {log.responseTime}ms
                      </p>
                    </td>
                    <td className="p-4">
                      <p className="text-sm font-mono">{log.ip}</p>
                    </td>
                    <td className="p-4">
                      <code className="text-xs bg-gray-100 px-2 py-1 rounded">{log.apiKey}</code>
                    </td>
                    <td className="p-4">
                      <Button size="sm" variant="outline">
                        <Eye className="h-4 w-4" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Performance Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Response Time Trends</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 bg-gradient-to-br from-blue-50 to-purple-100 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <Clock className="h-16 w-16 text-blue-500 mx-auto mb-4" />
                <p className="text-gray-600">กราฟแนวโน้ม Response Time</p>
                <p className="text-sm text-gray-500">แสดงประสิทธิภาพ API ย้อนหลัง 24 ชั่วโมง</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Error Rate Analysis</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 bg-gradient-to-br from-red-50 to-orange-100 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <AlertTriangle className="h-16 w-16 text-red-500 mx-auto mb-4" />
                <p className="text-gray-600">การวิเคราะห์อัตราข้อผิดพลาด</p>
                <p className="text-sm text-gray-500">แยกตามประเภทข้อผิดพลาดและ Endpoint</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center">
                <Code className="h-8 w-8 mr-3 text-blue-600" />
                API Management
              </h1>
              <p className="text-gray-600 mt-2">จัดการ API Keys, Documentation และ Monitoring</p>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline">
                <Monitor className="h-4 w-4 mr-2" />
                System Status
              </Button>
              <Button variant="outline">
                <FileText className="h-4 w-4 mr-2" />
                API Docs
              </Button>
              <Button>
                <Key className="h-4 w-4 mr-2" />
                สร้าง API Key
              </Button>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="overview" className="flex items-center space-x-2">
              <BarChart3 className="h-4 w-4" />
              <span>ภาพรวม</span>
            </TabsTrigger>
            <TabsTrigger value="keys" className="flex items-center space-x-2">
              <Key className="h-4 w-4" />
              <span>API Keys</span>
            </TabsTrigger>
            <TabsTrigger value="docs" className="flex items-center space-x-2">
              <FileText className="h-4 w-4" />
              <span>Documentation</span>
            </TabsTrigger>
            <TabsTrigger value="logs" className="flex items-center space-x-2">
              <Activity className="h-4 w-4" />
              <span>Logs & Monitoring</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <ApiOverview />
          </TabsContent>

          <TabsContent value="keys">
            <ApiKeysManagement />
          </TabsContent>

          <TabsContent value="docs">
            <ApiDocumentation />
          </TabsContent>

          <TabsContent value="logs">
            <ApiLogs />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
