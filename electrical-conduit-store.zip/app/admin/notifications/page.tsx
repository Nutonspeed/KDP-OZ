"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Progress } from "@/components/ui/progress"
import {
  Bell,
  Mail,
  MessageSquare,
  Smartphone,
  Settings,
  Plus,
  Edit,
  Trash2,
  Eye,
  Send,
  Clock,
  Target,
  TrendingUp,
  BarChart3,
  CheckCircle,
  Zap,
  Filter,
  Search,
  User,
  Star,
  FileText,
} from "lucide-react"

// Mock data for advanced notifications
const mockNotificationChannels = [
  {
    id: 1,
    name: "Email",
    type: "email",
    icon: Mail,
    status: "active",
    sent: 15420,
    delivered: 14890,
    opened: 3678,
    clicked: 892,
    deliveryRate: 96.6,
    openRate: 24.7,
    clickRate: 5.8,
  },
  {
    id: 2,
    name: "Push Notifications",
    type: "push",
    icon: Smartphone,
    status: "active",
    sent: 8950,
    delivered: 8756,
    opened: 2634,
    clicked: 456,
    deliveryRate: 97.8,
    openRate: 30.1,
    clickRate: 5.1,
  },
  {
    id: 3,
    name: "SMS",
    type: "sms",
    icon: MessageSquare,
    status: "active",
    sent: 2340,
    delivered: 2298,
    opened: 1834,
    clicked: 234,
    deliveryRate: 98.2,
    openRate: 79.8,
    clickRate: 10.0,
  },
  {
    id: 4,
    name: "LINE Notify",
    type: "line",
    icon: MessageSquare,
    status: "active",
    sent: 5670,
    delivered: 5598,
    opened: 4456,
    clicked: 1123,
    deliveryRate: 98.7,
    openRate: 79.6,
    clickRate: 20.1,
  },
]

const mockNotificationTemplates = [
  {
    id: 1,
    name: "ยินดีต้อนรับสมาชิกใหม่",
    type: "welcome",
    channels: ["email", "push"],
    status: "active",
    usage: 245,
    lastUsed: "2024-01-15",
    openRate: 45.2,
    clickRate: 12.8,
  },
  {
    id: 2,
    name: "ยืนยันคำสั่งซื้อ",
    type: "order_confirmation",
    channels: ["email", "sms", "line"],
    status: "active",
    usage: 1890,
    lastUsed: "2024-01-15",
    openRate: 89.5,
    clickRate: 23.4,
  },
  {
    id: 3,
    name: "แจ้งเตือนสินค้าเหลือน้อย",
    type: "low_stock",
    channels: ["email", "push"],
    status: "active",
    usage: 67,
    lastUsed: "2024-01-14",
    openRate: 67.8,
    clickRate: 34.2,
  },
  {
    id: 4,
    name: "โปรโมชั่นพิเศษ",
    type: "promotion",
    channels: ["email", "push", "sms", "line"],
    status: "draft",
    usage: 0,
    lastUsed: null,
    openRate: 0,
    clickRate: 0,
  },
]

const mockNotificationRules = [
  {
    id: 1,
    name: "แจ้งเตือนคำสั่งซื้อใหม่",
    trigger: "order_created",
    conditions: "amount > 1000",
    actions: ["email_admin", "line_notify"],
    status: "active",
    triggered: 234,
    lastTriggered: "2024-01-15 14:30",
  },
  {
    id: 2,
    name: "แจ้งเตือนสต็อกต่ำ",
    trigger: "stock_low",
    conditions: "quantity < 10",
    actions: ["email_inventory", "push_admin"],
    status: "active",
    triggered: 12,
    lastTriggered: "2024-01-15 09:15",
  },
  {
    id: 3,
    name: "ลูกค้าใหม่ลงทะเบียน",
    trigger: "user_registered",
    conditions: "always",
    actions: ["welcome_email", "push_welcome"],
    status: "active",
    triggered: 45,
    lastTriggered: "2024-01-15 16:20",
  },
]

const mockNotificationHistory = [
  {
    id: 1,
    title: "ยืนยันคำสั่งซื้อ #ORD-2024-156",
    recipient: "customer@email.com",
    channel: "email",
    status: "delivered",
    sentAt: "2024-01-15 14:30",
    deliveredAt: "2024-01-15 14:31",
    openedAt: "2024-01-15 15:45",
    clickedAt: null,
  },
  {
    id: 2,
    title: "โปรโมชั่นพิเศษ LB Series",
    recipient: "+66812345678",
    channel: "sms",
    status: "delivered",
    sentAt: "2024-01-15 14:25",
    deliveredAt: "2024-01-15 14:26",
    openedAt: "2024-01-15 14:27",
    clickedAt: "2024-01-15 14:28",
  },
  {
    id: 3,
    title: "สินค้าเหลือน้อย: T-75G",
    recipient: "admin@kdp.co.th",
    channel: "line",
    status: "failed",
    sentAt: "2024-01-15 14:20",
    deliveredAt: null,
    openedAt: null,
    clickedAt: null,
    error: "Invalid LINE token",
  },
]

export default function AdvancedNotifications() {
  const [activeTab, setActiveTab] = useState("overview")
  const [searchTerm, setSearchTerm] = useState("")

  // Notifications Overview
  const NotificationsOverview = () => (
    <div className="space-y-6">
      {/* Notification Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">ส่งวันนี้</p>
                <p className="text-2xl font-bold">2,456</p>
                <p className="text-xs text-green-600 flex items-center mt-1">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  +18.2% จากเมื่อวาน
                </p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <Send className="h-6 w-6 text-blue-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-400 to-blue-600"></div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">อัตราการส่งสำเร็จ</p>
                <p className="text-2xl font-bold">97.8%</p>
                <p className="text-xs text-green-600">+0.5% จากเดือนที่แล้ว</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-green-400 to-green-600"></div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">อัตราการเปิด</p>
                <p className="text-2xl font-bold">34.5%</p>
                <p className="text-xs text-purple-600">+2.1% จากเดือนที่แล้ว</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                <Eye className="h-6 w-6 text-purple-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-purple-400 to-purple-600"></div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">อัตราการคลิก</p>
                <p className="text-2xl font-bold">8.9%</p>
                <p className="text-xs text-orange-600">+1.2% จากเดือนที่แล้ว</p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                <Target className="h-6 w-6 text-orange-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-orange-400 to-orange-600"></div>
          </CardContent>
        </Card>
      </div>

      {/* Channel Performance */}
      <Card>
        <CardHeader>
          <CardTitle>ประสิทธิภาพช่องทางการแจ้งเตือน</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {mockNotificationChannels.map((channel) => (
              <Card key={channel.id} className="border-2">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <channel.icon className="h-5 w-5 text-blue-600" />
                      <span className="text-lg">{channel.name}</span>
                    </div>
                    <Badge variant={channel.status === "active" ? "default" : "secondary"}>
                      {channel.status === "active" ? "ใช้งาน" : "ปิด"}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-gray-600">ส่งแล้ว</p>
                      <p className="font-medium">{channel.sent.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">ส่งสำเร็จ</p>
                      <p className="font-medium">{channel.delivered.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">เปิดแล้ว</p>
                      <p className="font-medium">{channel.opened.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">คลิกแล้ว</p>
                      <p className="font-medium">{channel.clicked.toLocaleString()}</p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>อัตราส่งสำเร็จ</span>
                        <span className="font-medium text-green-600">{channel.deliveryRate}%</span>
                      </div>
                      <Progress value={channel.deliveryRate} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>อัตราเปิด</span>
                        <span className="font-medium text-blue-600">{channel.openRate}%</span>
                      </div>
                      <Progress value={channel.openRate} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>อัตราคลิก</span>
                        <span className="font-medium text-purple-600">{channel.clickRate}%</span>
                      </div>
                      <Progress value={channel.clickRate} className="h-2" />
                    </div>
                  </div>
                  <Button size="sm" variant="outline" className="w-full bg-transparent">
                    <Settings className="h-4 w-4 mr-2" />
                    ตั้งค่า
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Performance Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>แนวโน้มการส่งการแจ้งเตือน</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80 bg-gradient-to-br from-blue-50 to-indigo-100 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <BarChart3 className="h-16 w-16 text-blue-500 mx-auto mb-4" />
                <p className="text-gray-600">กราฟแนวโน้มการส่งการแจ้งเตือน</p>
                <p className="text-sm text-gray-500">แสดงปริมาณการส่งรายวัน</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>การเปรียบเทียบช่องทาง</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80 bg-gradient-to-br from-green-50 to-teal-100 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <Target className="h-16 w-16 text-green-500 mx-auto mb-4" />
                <p className="text-gray-600">การเปรียบเทียบประสิทธิภาพ</p>
                <p className="text-sm text-gray-500">แสดงอัตราเปิดและคลิกแต่ละช่องทาง</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )

  // Template Management
  const TemplateManagement = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-bold">จัดการเทมเพลต</h3>
          <p className="text-gray-600">สร้างและจัดการเทมเพลตการแจ้งเตือน</p>
        </div>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          สร้างเทมเพลตใหม่
        </Button>
      </div>

      {/* Template Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">เทมเพลตทั้งหมด</p>
                <p className="text-2xl font-bold text-blue-600">24</p>
              </div>
              <FileText className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">ใช้งานอยู่</p>
                <p className="text-2xl font-bold text-green-600">18</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">ร่าง</p>
                <p className="text-2xl font-bold text-orange-600">6</p>
              </div>
              <Edit className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">ใช้งานวันนี้</p>
                <p className="text-2xl font-bold text-purple-600">156</p>
              </div>
              <Send className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Templates Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left p-4 font-medium">เทมเพลต</th>
                  <th className="text-left p-4 font-medium">ประเภท</th>
                  <th className="text-left p-4 font-medium">ช่องทาง</th>
                  <th className="text-left p-4 font-medium">การใช้งาน</th>
                  <th className="text-left p-4 font-medium">ประสิทธิภาพ</th>
                  <th className="text-left p-4 font-medium">อัพเดทล่าสุด</th>
                  <th className="text-left p-4 font-medium">สถานะ</th>
                  <th className="text-left p-4 font-medium">จัดการ</th>
                </tr>
              </thead>
              <tbody>
                {mockNotificationTemplates.map((template) => (
                  <tr key={template.id} className="border-t hover:bg-gray-50">
                    <td className="p-4">
                      <div>
                        <p className="font-medium">{template.name}</p>
                        <p className="text-sm text-gray-600">ID: {template.type}</p>
                      </div>
                    </td>
                    <td className="p-4">
                      <Badge variant="outline">
                        {template.type === "welcome" && "ยินดีต้อนรับ"}
                        {template.type === "order_confirmation" && "ยืนยันคำสั่งซื้อ"}
                        {template.type === "low_stock" && "สต็อกต่ำ"}
                        {template.type === "promotion" && "โปรโมชั่น"}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <div className="flex flex-wrap gap-1">
                        {template.channels.map((channel) => (
                          <Badge key={channel} variant="outline" className="text-xs">
                            {channel === "email" && "📧"}
                            {channel === "push" && "📱"}
                            {channel === "sms" && "💬"}
                            {channel === "line" && "💚"}
                          </Badge>
                        ))}
                      </div>
                    </td>
                    <td className="p-4">
                      <p className="font-medium">{template.usage.toLocaleString()}</p>
                      <p className="text-sm text-gray-600">ครั้ง</p>
                    </td>
                    <td className="p-4">
                      <div className="text-sm">
                        <p className="text-green-600">เปิด: {template.openRate}%</p>
                        <p className="text-blue-600">คลิก: {template.clickRate}%</p>
                      </div>
                    </td>
                    <td className="p-4">
                      <p className="text-sm">{template.lastUsed || "ยังไม่ได้ใช้"}</p>
                    </td>
                    <td className="p-4">
                      <Badge variant={template.status === "active" ? "default" : "secondary"}>
                        {template.status === "active" ? "ใช้งาน" : "ร่าง"}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Send className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline" className="text-red-600 hover:text-red-700 bg-transparent">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Create Template Form */}
      <Card>
        <CardHeader>
          <CardTitle>สร้างเทมเพลตใหม่</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="template-name">ชื่อเทมเพลต</Label>
              <Input id="template-name" placeholder="เช่น ยืนยันคำสั่งซื้อ" />
            </div>
            <div>
              <Label htmlFor="template-type">ประเภท</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="เลือกประเภท" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="welcome">ยินดีต้อนรับ</SelectItem>
                  <SelectItem value="order_confirmation">ยืนยันคำสั่งซื้อ</SelectItem>
                  <SelectItem value="shipping">การจัดส่ง</SelectItem>
                  <SelectItem value="promotion">โปรโมชั่น</SelectItem>
                  <SelectItem value="reminder">การแจ้งเตือน</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <Label>ช่องทางการส่ง</Label>
            <div className="grid grid-cols-4 gap-4 mt-2">
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="email-channel" defaultChecked />
                <Label htmlFor="email-channel">📧 Email</Label>
              </div>
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="push-channel" />
                <Label htmlFor="push-channel">📱 Push</Label>
              </div>
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="sms-channel" />
                <Label htmlFor="sms-channel">💬 SMS</Label>
              </div>
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="line-channel" />
                <Label htmlFor="line-channel">💚 LINE</Label>
              </div>
            </div>
          </div>
          <div>
            <Label htmlFor="template-subject">หัวข้อ</Label>
            <Input id="template-subject" placeholder="หัวข้อการแจ้งเตือน" />
          </div>
          <div>
            <Label htmlFor="template-content">เนื้อหา</Label>
            <Textarea id="template-content" placeholder="เขียนเนื้อหาการแจ้งเตือน..." rows={5} />
          </div>
          <div className="flex space-x-2">
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              สร้างเทมเพลต
            </Button>
            <Button variant="outline" className="bg-transparent">
              <Eye className="h-4 w-4 mr-2" />
              ดูตัวอย่าง
            </Button>
            <Button variant="outline" className="bg-transparent">
              บันทึกร่าง
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  // Automation Rules
  const AutomationRules = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-bold">กฎการแจ้งเตือนอัตโนมัติ</h3>
          <p className="text-gray-600">ตั้งค่าการแจ้งเตือนอัตโนมัติตามเงื่อนไข</p>
        </div>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          สร้างกฎใหม่
        </Button>
      </div>

      {/* Rules Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">กฎทั้งหมด</p>
                <p className="text-2xl font-bold text-blue-600">12</p>
              </div>
              <Zap className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">ใช้งานอยู่</p>
                <p className="text-2xl font-bold text-green-600">9</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">ทริกเกอร์วันนี้</p>
                <p className="text-2xl font-bold text-purple-600">234</p>
              </div>
              <Target className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">อัตราสำเร็จ</p>
                <p className="text-2xl font-bold text-orange-600">98.5%</p>
              </div>
              <Star className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Rules Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left p-4 font-medium">ชื่อกฎ</th>
                  <th className="text-left p-4 font-medium">ทริกเกอร์</th>
                  <th className="text-left p-4 font-medium">เงื่อนไข</th>
                  <th className="text-left p-4 font-medium">การดำเนินการ</th>
                  <th className="text-left p-4 font-medium">ทริกเกอร์แล้ว</th>
                  <th className="text-left p-4 font-medium">ล่าสุด</th>
                  <th className="text-left p-4 font-medium">สถานะ</th>
                  <th className="text-left p-4 font-medium">จัดการ</th>
                </tr>
              </thead>
              <tbody>
                {mockNotificationRules.map((rule) => (
                  <tr key={rule.id} className="border-t hover:bg-gray-50">
                    <td className="p-4">
                      <p className="font-medium">{rule.name}</p>
                    </td>
                    <td className="p-4">
                      <Badge variant="outline">
                        {rule.trigger === "order_created" && "คำสั่งซื้อใหม่"}
                        {rule.trigger === "stock_low" && "สต็อกต่ำ"}
                        {rule.trigger === "user_registered" && "สมาชิกใหม่"}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <code className="text-sm bg-gray-100 px-2 py-1 rounded">{rule.conditions}</code>
                    </td>
                    <td className="p-4">
                      <div className="flex flex-wrap gap-1">
                        {rule.actions.map((action, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {action.includes("email") && "📧"}
                            {action.includes("push") && "📱"}
                            {action.includes("line") && "💚"}
                            {action.replace("_", " ")}
                          </Badge>
                        ))}
                      </div>
                    </td>
                    <td className="p-4">
                      <p className="font-medium">{rule.triggered}</p>
                      <p className="text-sm text-gray-600">ครั้ง</p>
                    </td>
                    <td className="p-4">
                      <p className="text-sm">{rule.lastTriggered}</p>
                    </td>
                    <td className="p-4">
                      <Badge variant={rule.status === "active" ? "default" : "secondary"}>
                        {rule.status === "active" ? "ใช้งาน" : "ปิด"}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline" className="text-red-600 hover:text-red-700 bg-transparent">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Create Rule Form */}
      <Card>
        <CardHeader>
          <CardTitle>สร้างกฎใหม่</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="rule-name">ชื่อกฎ</Label>
            <Input id="rule-name" placeholder="เช่น แจ้งเตือนคำสั่งซื้อใหม่" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="rule-trigger">ทริกเกอร์</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="เลือกทริกเกอร์" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="order_created">คำสั่งซื้อใหม่</SelectItem>
                  <SelectItem value="order_paid">ชำระเงินแล้ว</SelectItem>
                  <SelectItem value="order_shipped">จัดส่งแล้ว</SelectItem>
                  <SelectItem value="stock_low">สต็อกต่ำ</SelectItem>
                  <SelectItem value="user_registered">สมาชิกใหม่</SelectItem>
                  <SelectItem value="user_inactive">ผู้ใช้ไม่ใช้งาน</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="rule-conditions">เงื่อนไข</Label>
              <Input id="rule-conditions" placeholder="เช่น amount > 1000" />
            </div>
          </div>
          <div>
            <Label>การดำเนินการ</Label>
            <div className="grid grid-cols-2 gap-4 mt-2">
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="action-email" />
                <Label htmlFor="action-email">ส่งอีเมล</Label>
              </div>
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="action-push" />
                <Label htmlFor="action-push">ส่ง Push Notification</Label>
              </div>
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="action-sms" />
                <Label htmlFor="action-sms">ส่ง SMS</Label>
              </div>
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="action-line" />
                <Label htmlFor="action-line">ส่ง LINE Notify</Label>
              </div>
            </div>
          </div>
          <div>
            <Label htmlFor="rule-description">คำอธิบาย</Label>
            <Textarea id="rule-description" placeholder="อธิบายการทำงานของกฎนี้..." rows={3} />
          </div>
          <div className="flex space-x-2">
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              สร้างกฎ
            </Button>
            <Button variant="outline" className="bg-transparent">
              <Eye className="h-4 w-4 mr-2" />
              ทดสอบ
            </Button>
            <Button variant="outline" className="bg-transparent">
              บันทึกร่าง
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  // Notification History
  const NotificationHistory = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-bold">ประวัติการแจ้งเตือน</h3>
          <p className="text-gray-600">ติดตามการส่งการแจ้งเตือนทั้งหมด</p>
        </div>
        <div className="flex space-x-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="ค้นหาการแจ้งเตือน..."
              className="pl-10 w-64"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Select defaultValue="all">
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">ทั้งหมด</SelectItem>
              <SelectItem value="delivered">ส่งสำเร็จ</SelectItem>
              <SelectItem value="failed">ส่งไม่สำเร็จ</SelectItem>
              <SelectItem value="pending">รอส่ง</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm">
            <Filter className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* History Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left p-4 font-medium">การแจ้งเตือน</th>
                  <th className="text-left p-4 font-medium">ผู้รับ</th>
                  <th className="text-left p-4 font-medium">ช่องทาง</th>
                  <th className="text-left p-4 font-medium">สถานะ</th>
                  <th className="text-left p-4 font-medium">เวลาส่ง</th>
                  <th className="text-left p-4 font-medium">เวลาส่งสำเร็จ</th>
                  <th className="text-left p-4 font-medium">เวลาเปิด</th>
                  <th className="text-left p-4 font-medium">จัดการ</th>
                </tr>
              </thead>
              <tbody>
                {mockNotificationHistory.map((notification) => (
                  <tr key={notification.id} className="border-t hover:bg-gray-50">
                    <td className="p-4">
                      <p className="font-medium">{notification.title}</p>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-2">
                        <User className="h-4 w-4 text-gray-400" />
                        <span className="text-sm">{notification.recipient}</span>
                      </div>
                    </td>
                    <td className="p-4">
                      <Badge variant="outline">
                        {notification.channel === "email" && "📧 Email"}
                        {notification.channel === "sms" && "💬 SMS"}
                        {notification.channel === "push" && "📱 Push"}
                        {notification.channel === "line" && "💚 LINE"}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-2">
                        <div
                          className={`w-2 h-2 rounded-full ${
                            notification.status === "delivered"
                              ? "bg-green-500"
                              : notification.status === "failed"
                                ? "bg-red-500"
                                : "bg-yellow-500"
                          }`}
                        />
                        <Badge
                          variant={
                            notification.status === "delivered"
                              ? "default"
                              : notification.status === "failed"
                                ? "destructive"
                                : "secondary"
                          }
                        >
                          {notification.status === "delivered" && "ส่งสำเร็จ"}
                          {notification.status === "failed" && "ส่งไม่สำเร็จ"}
                          {notification.status === "pending" && "รอส่ง"}
                        </Badge>
                      </div>
                      {notification.error && <p className="text-xs text-red-600 mt-1">{notification.error}</p>}
                    </td>
                    <td className="p-4">
                      <p className="text-sm">{notification.sentAt}</p>
                    </td>
                    <td className="p-4">
                      <p className="text-sm">{notification.deliveredAt || "-"}</p>
                    </td>
                    <td className="p-4">
                      <p className="text-sm">{notification.openedAt || "-"}</p>
                      {notification.clickedAt && <p className="text-xs text-blue-600">คลิก: {notification.clickedAt}</p>}
                    </td>
                    <td className="p-4">
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline">
                          <Eye className="h-4 w-4" />
                        </Button>
                        {notification.status === "failed" && (
                          <Button size="sm" variant="outline">
                            <Send className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center">
                <Bell className="h-8 w-8 mr-3 text-blue-600" />
                Advanced Notifications
              </h1>
              <p className="text-gray-600 mt-2">ระบบการแจ้งเตือนขั้นสูงแบบครบครัน</p>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline">
                <BarChart3 className="h-4 w-4 mr-2" />
                รายงาน
              </Button>
              <Button variant="outline">
                <Settings className="h-4 w-4 mr-2" />
                ตั้งค่า
              </Button>
              <Button>
                <Send className="h-4 w-4 mr-2" />
                ส่งการแจ้งเตือน
              </Button>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="overview" className="flex items-center space-x-2">
              <BarChart3 className="h-4 w-4" />
              <span>ภาพรวม</span>
            </TabsTrigger>
            <TabsTrigger value="templates" className="flex items-center space-x-2">
              <FileText className="h-4 w-4" />
              <span>เทมเพลต</span>
            </TabsTrigger>
            <TabsTrigger value="automation" className="flex items-center space-x-2">
              <Zap className="h-4 w-4" />
              <span>อัตโนมัติ</span>
            </TabsTrigger>
            <TabsTrigger value="history" className="flex items-center space-x-2">
              <Clock className="h-4 w-4" />
              <span>ประวัติ</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <NotificationsOverview />
          </TabsContent>

          <TabsContent value="templates">
            <TemplateManagement />
          </TabsContent>

          <TabsContent value="automation">
            <AutomationRules />
          </TabsContent>

          <TabsContent value="history">
            <NotificationHistory />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
