"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Brain,
  TrendingUp,
  TrendingDown,
  Users,
  Package,
  Target,
  Lightbulb,
  AlertCircle,
  CheckCircle,
  BarChart3,
  LineChart,
  Zap,
  BotIcon as Robot,
  Eye,
  RefreshCw,
} from "lucide-react"

// Mock AI Analytics data
const mockAIInsights = {
  salesPrediction: {
    nextMonth: 156780,
    confidence: 87,
    trend: "up",
    factors: ["Seasonal demand increase", "New product launches", "Marketing campaigns"],
  },
  customerBehavior: {
    segments: [
      { name: "High Value", count: 234, revenue: 125000, growth: 15.2 },
      { name: "Regular", count: 1456, revenue: 89000, growth: 8.7 },
      { name: "New", count: 567, revenue: 23000, growth: 45.3 },
      { name: "At Risk", count: 89, revenue: 12000, growth: -12.5 },
    ],
    churnRisk: 12.3,
    lifetimeValue: 2450,
  },
  productInsights: {
    topPerformers: [
      { name: "PVC Conduit 20mm", score: 95, trend: "up", reason: "High demand, good margins" },
      { name: "Metal Junction Box", score: 89, trend: "stable", reason: "Consistent sales" },
      { name: "Flexible Conduit 32mm", score: 82, trend: "up", reason: "Growing market" },
    ],
    underperformers: [
      { name: "Cable Tray 300mm", score: 34, trend: "down", reason: "Low demand, high inventory" },
      { name: "Conduit Elbow 45°", score: 28, trend: "down", reason: "Seasonal decline" },
    ],
  },
  marketTrends: {
    emergingCategories: ["Smart Conduits", "Eco-friendly Materials", "Modular Systems"],
    decliningCategories: ["Traditional Metal", "Basic PVC"],
    opportunities: [
      { category: "Smart Home Integration", potential: "High", timeline: "6 months" },
      { category: "Industrial IoT", potential: "Medium", timeline: "12 months" },
    ],
  },
}

const mockRecommendations = [
  {
    id: 1,
    type: "inventory",
    priority: "high",
    title: "Increase PVC Conduit 20mm Stock",
    description: "AI predicts 40% increase in demand next month",
    impact: "฿45,000 potential revenue",
    confidence: 92,
    action: "Order 500 more units",
  },
  {
    id: 2,
    type: "pricing",
    priority: "medium",
    title: "Optimize Metal Conduit Pricing",
    description: "Price elasticity analysis suggests 5% increase possible",
    impact: "฿12,000 additional revenue",
    confidence: 78,
    action: "Increase price by 5%",
  },
  {
    id: 3,
    type: "marketing",
    priority: "high",
    title: "Target High-Value Customer Segment",
    description: "Personalized campaigns can increase conversion by 25%",
    impact: "฿28,000 potential revenue",
    confidence: 85,
    action: "Launch targeted campaign",
  },
  {
    id: 4,
    type: "product",
    priority: "low",
    title: "Discontinue Slow-Moving Items",
    description: "5 products showing consistent decline",
    impact: "฿8,000 cost savings",
    confidence: 71,
    action: "Review product portfolio",
  },
]

const mockPredictiveModels = [
  {
    name: "Sales Forecasting",
    accuracy: 87.5,
    status: "active",
    lastTrained: "2024-01-10",
    predictions: "Next 3 months sales volume",
  },
  {
    name: "Customer Churn",
    accuracy: 82.3,
    status: "active",
    lastTrained: "2024-01-08",
    predictions: "Customer retention probability",
  },
  {
    name: "Inventory Optimization",
    accuracy: 91.2,
    status: "active",
    lastTrained: "2024-01-12",
    predictions: "Optimal stock levels",
  },
  {
    name: "Price Optimization",
    accuracy: 76.8,
    status: "training",
    lastTrained: "2024-01-05",
    predictions: "Optimal pricing strategies",
  },
]

export default function AIAnalytics() {
  const [activeTab, setActiveTab] = useState("insights")
  const [selectedTimeframe, setSelectedTimeframe] = useState("30d")
  const [isRefreshing, setIsRefreshing] = useState(false)

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      // Update some dynamic values
    }, 10000)

    return () => clearInterval(interval)
  }, [])

  const handleRefresh = async () => {
    setIsRefreshing(true)
    await new Promise((resolve) => setTimeout(resolve, 2000))
    setIsRefreshing(false)
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "text-red-600 bg-red-100"
      case "medium":
        return "text-yellow-600 bg-yellow-100"
      case "low":
        return "text-green-600 bg-green-100"
      default:
        return "text-gray-600 bg-gray-100"
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "inventory":
        return <Package className="h-4 w-4" />
      case "pricing":
        return <TrendingUp className="h-4 w-4" />
      case "marketing":
        return <Target className="h-4 w-4" />
      case "product":
        return <Lightbulb className="h-4 w-4" />
      default:
        return <Brain className="h-4 w-4" />
    }
  }

  // AI Insights Dashboard
  const AIInsights = () => (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Sales Prediction</p>
                <p className="text-2xl font-bold mt-1">฿{mockAIInsights.salesPrediction.nextMonth.toLocaleString()}</p>
                <div className="flex items-center mt-2">
                  <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                  <span className="text-sm text-green-600">
                    {mockAIInsights.salesPrediction.confidence}% confidence
                  </span>
                </div>
              </div>
              <Brain className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Customer LTV</p>
                <p className="text-2xl font-bold mt-1">
                  ฿{mockAIInsights.customerBehavior.lifetimeValue.toLocaleString()}
                </p>
                <p className="text-sm text-gray-600 mt-1">Average lifetime value</p>
              </div>
              <Users className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Churn Risk</p>
                <p className="text-2xl font-bold mt-1">{mockAIInsights.customerBehavior.churnRisk}%</p>
                <p className="text-sm text-yellow-600 mt-1">Customers at risk</p>
              </div>
              <AlertCircle className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">AI Accuracy</p>
                <p className="text-2xl font-bold mt-1">87.5%</p>
                <p className="text-sm text-green-600 mt-1">Model performance</p>
              </div>
              <Robot className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Customer Segments */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Users className="h-5 w-5 mr-2" />
            AI Customer Segmentation
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {mockAIInsights.customerBehavior.segments.map((segment, index) => (
              <div key={index} className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold">{segment.name}</h3>
                  <Badge variant={segment.growth > 0 ? "default" : "destructive"}>
                    {segment.growth > 0 ? "+" : ""}
                    {segment.growth}%
                  </Badge>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Customers:</span>
                    <span className="font-medium">{segment.count}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Revenue:</span>
                    <span className="font-medium">฿{segment.revenue.toLocaleString()}</span>
                  </div>
                  <Progress value={(segment.revenue / 125000) * 100} className="h-2" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Product Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-green-600">
              <TrendingUp className="h-5 w-5 mr-2" />
              Top Performers
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {mockAIInsights.productInsights.topPerformers.map((product, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                      <span className="text-sm font-bold text-green-600">#{index + 1}</span>
                    </div>
                    <div>
                      <h4 className="font-medium">{product.name}</h4>
                      <p className="text-sm text-gray-600">{product.reason}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center space-x-2">
                      <span className="text-lg font-bold text-green-600">{product.score}</span>
                      <TrendingUp className="h-4 w-4 text-green-500" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-red-600">
              <TrendingDown className="h-5 w-5 mr-2" />
              Needs Attention
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {mockAIInsights.productInsights.underperformers.map((product, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
                      <AlertCircle className="h-4 w-4 text-red-600" />
                    </div>
                    <div>
                      <h4 className="font-medium">{product.name}</h4>
                      <p className="text-sm text-gray-600">{product.reason}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center space-x-2">
                      <span className="text-lg font-bold text-red-600">{product.score}</span>
                      <TrendingDown className="h-4 w-4 text-red-500" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Market Trends */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <BarChart3 className="h-5 w-5 mr-2" />
            Market Trends & Opportunities
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold mb-3 text-green-600">Emerging Categories</h4>
              <div className="space-y-2">
                {mockAIInsights.marketTrends.emergingCategories.map((category, index) => (
                  <div key={index} className="flex items-center space-x-2 p-2 bg-green-50 rounded">
                    <TrendingUp className="h-4 w-4 text-green-500" />
                    <span>{category}</span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h4 className="font-semibold mb-3 text-red-600">Declining Categories</h4>
              <div className="space-y-2">
                {mockAIInsights.marketTrends.decliningCategories.map((category, index) => (
                  <div key={index} className="flex items-center space-x-2 p-2 bg-red-50 rounded">
                    <TrendingDown className="h-4 w-4 text-red-500" />
                    <span>{category}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-6 pt-6 border-t">
            <h4 className="font-semibold mb-3">Business Opportunities</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {mockAIInsights.marketTrends.opportunities.map((opportunity, index) => (
                <div key={index} className="p-4 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h5 className="font-medium">{opportunity.category}</h5>
                    <Badge
                      className={
                        opportunity.potential === "High"
                          ? "bg-green-100 text-green-600"
                          : "bg-yellow-100 text-yellow-600"
                      }
                    >
                      {opportunity.potential} Potential
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600">Timeline: {opportunity.timeline}</p>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  // AI Recommendations
  const AIRecommendations = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-bold">AI Recommendations</h3>
          <p className="text-gray-600">คำแนะนำจาก AI เพื่อเพิ่มประสิทธิภาพธุรกิจ</p>
        </div>
        <Button onClick={handleRefresh} disabled={isRefreshing}>
          <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? "animate-spin" : ""}`} />
          {isRefreshing ? "กำลังวิเคราะห์..." : "รีเฟรชคำแนะนำ"}
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {mockRecommendations.map((rec) => (
          <Card key={rec.id} className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    {getTypeIcon(rec.type)}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <h3 className="text-lg font-semibold">{rec.title}</h3>
                      <Badge className={getPriorityColor(rec.priority)}>{rec.priority} priority</Badge>
                    </div>
                    <p className="text-gray-600 mb-3">{rec.description}</p>
                    <div className="flex items-center space-x-4 text-sm">
                      <div className="flex items-center space-x-1">
                        <TrendingUp className="h-4 w-4 text-green-500" />
                        <span className="font-medium text-green-600">{rec.impact}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Brain className="h-4 w-4 text-blue-500" />
                        <span>{rec.confidence}% confidence</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex space-x-2">
                  <Button size="sm" variant="outline">
                    <Eye className="h-4 w-4 mr-2" />
                    View Details
                  </Button>
                  <Button size="sm">
                    <CheckCircle className="h-4 w-4 mr-2" />
                    {rec.action}
                  </Button>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Confidence Level</span>
                  <span className="text-sm text-gray-600">{rec.confidence}%</span>
                </div>
                <Progress value={rec.confidence} className="h-2 mt-2" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )

  // Predictive Models
  const PredictiveModels = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-bold">Predictive Models</h3>
        <p className="text-gray-600">โมเดล AI ที่ใช้ในการทำนายและวิเคราะห์</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {mockPredictiveModels.map((model, index) => (
          <Card key={index}>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>{model.name}</span>
                <Badge
                  className={
                    model.status === "active" ? "bg-green-100 text-green-600" : "bg-yellow-100 text-yellow-600"
                  }
                >
                  {model.status}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Accuracy</span>
                  <span className="text-sm text-gray-600">{model.accuracy}%</span>
                </div>
                <Progress value={model.accuracy} className="h-2" />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Last Trained:</span>
                  <span className="font-medium">{new Date(model.lastTrained).toLocaleDateString()}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Predictions:</span>
                  <span className="font-medium">{model.predictions}</span>
                </div>
              </div>

              <div className="flex space-x-2 pt-4">
                <Button size="sm" variant="outline" className="flex-1 bg-transparent">
                  <Eye className="h-4 w-4 mr-2" />
                  View Results
                </Button>
                <Button size="sm" variant="outline" className="flex-1 bg-transparent">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Retrain
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Model Performance Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Model Performance Over Time</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64 flex items-center justify-center bg-gray-50 rounded-lg">
            <div className="text-center">
              <LineChart className="h-12 w-12 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-600">Performance chart would be displayed here</p>
              <p className="text-sm text-gray-500">Showing accuracy trends over the last 6 months</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center">
                <Brain className="h-8 w-8 mr-3 text-blue-600" />
                AI Analytics & Intelligence
              </h1>
              <p className="text-gray-600 mt-2">การวิเคราะห์ข้อมูลและคำแนะนำจาก AI</p>
            </div>
            <div className="flex space-x-2">
              <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7d">7 days</SelectItem>
                  <SelectItem value="30d">30 days</SelectItem>
                  <SelectItem value="90d">90 days</SelectItem>
                  <SelectItem value="1y">1 year</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline">
                <Zap className="h-4 w-4 mr-2" />
                Auto-Insights
              </Button>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="insights">AI Insights</TabsTrigger>
            <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
            <TabsTrigger value="models">Predictive Models</TabsTrigger>
          </TabsList>

          <TabsContent value="insights">
            <AIInsights />
          </TabsContent>

          <TabsContent value="recommendations">
            <AIRecommendations />
          </TabsContent>

          <TabsContent value="models">
            <PredictiveModels />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
