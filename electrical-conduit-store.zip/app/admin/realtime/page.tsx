"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Activity,
  Users,
  ShoppingCart,
  DollarSign,
  TrendingUp,
  Eye,
  Server,
  Database,
  Wifi,
  Zap,
  Clock,
  Monitor,
  Smartphone,
  Tablet,
  MapPin,
  RefreshCw,
} from "lucide-react"

// Mock real-time data
const mockRealTimeData = {
  activeUsers: 1247,
  onlineVisitors: 892,
  currentOrders: 23,
  todayRevenue: 125450,
  serverLoad: 45,
  databaseConnections: 156,
  apiRequests: 2340,
  errorRate: 0.08,
}

const mockLiveActivities = [
  {
    id: 1,
    type: "order",
    message: "คำสั่งซื้อใหม่ #ORD-2024-789 จาก บริษัท DEF",
    amount: 15750,
    timestamp: new Date(),
    location: "กรุงเทพฯ",
    device: "desktop",
  },
  {
    id: 2,
    type: "user",
    message: "ผู้ใช้ใหม่ลงทะเบียน: john.doe@email.com",
    timestamp: new Date(Date.now() - 30000),
    location: "เชียงใหม่",
    device: "mobile",
  },
  {
    id: 3,
    type: "payment",
    message: "ได้รับชำระเงิน ORD-2024-788 จำนวน ฿8,950",
    amount: 8950,
    timestamp: new Date(Date.now() - 60000),
    location: "ภูเก็ต",
    device: "tablet",
  },
  {
    id: 4,
    type: "view",
    message: "สินค้า T-100G ถูกดู 15 ครั้งในชั่วโมงที่ผ่านมา",
    timestamp: new Date(Date.now() - 120000),
    location: "ขอนแก่น",
    device: "mobile",
  },
]

const mockSystemMetrics = {
  cpu: 45,
  memory: 62,
  disk: 78,
  network: 23,
  uptime: "15 วัน 8 ชั่วโมง",
  responseTime: 245,
  throughput: 1250,
  errorCount: 12,
}

const mockTrafficSources = [
  { source: "Google", visitors: 456, percentage: 35.2 },
  { source: "Direct", visitors: 298, percentage: 23.1 },
  { source: "Facebook", visitors: 234, percentage: 18.1 },
  { source: "LINE", visitors: 156, percentage: 12.1 },
  { source: "Others", visitors: 146, percentage: 11.5 },
]

const mockDeviceStats = [
  { device: "Mobile", count: 567, percentage: 45.5 },
  { device: "Desktop", count: 423, percentage: 34.0 },
  { device: "Tablet", count: 257, percentage: 20.5 },
]

export default function RealTimeDashboard() {
  const [realTimeData, setRealTimeData] = useState(mockRealTimeData)
  const [liveActivities, setLiveActivities] = useState(mockLiveActivities)
  const [isConnected, setIsConnected] = useState(true)
  const [lastUpdate, setLastUpdate] = useState(new Date())

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      // Update real-time data
      setRealTimeData((prev) => ({
        ...prev,
        activeUsers: prev.activeUsers + Math.floor(Math.random() * 10) - 5,
        onlineVisitors: prev.onlineVisitors + Math.floor(Math.random() * 8) - 4,
        currentOrders: prev.currentOrders + Math.floor(Math.random() * 3) - 1,
        todayRevenue: prev.todayRevenue + Math.floor(Math.random() * 1000),
        serverLoad: Math.max(0, Math.min(100, prev.serverLoad + Math.floor(Math.random() * 10) - 5)),
        apiRequests: prev.apiRequests + Math.floor(Math.random() * 50),
      }))

      // Add new activity occasionally
      if (Math.random() < 0.3) {
        const newActivity = {
          id: Date.now(),
          type: ["order", "user", "payment", "view"][Math.floor(Math.random() * 4)],
          message: "กิจกรรมใหม่เกิดขึ้น...",
          timestamp: new Date(),
          location: ["กรุงเทพฯ", "เชียงใหม่", "ภูเก็ต", "ขอนแก่น"][Math.floor(Math.random() * 4)],
          device: ["desktop", "mobile", "tablet"][Math.floor(Math.random() * 3)],
        }

        setLiveActivities((prev) => [newActivity, ...prev.slice(0, 9)])
      }

      setLastUpdate(new Date())
    }, 3000)

    return () => clearInterval(interval)
  }, [])

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "order":
        return <ShoppingCart className="h-4 w-4 text-blue-600" />
      case "user":
        return <Users className="h-4 w-4 text-green-600" />
      case "payment":
        return <DollarSign className="h-4 w-4 text-purple-600" />
      case "view":
        return <Eye className="h-4 w-4 text-orange-600" />
      default:
        return <Activity className="h-4 w-4 text-gray-600" />
    }
  }

  const getDeviceIcon = (device: string) => {
    switch (device) {
      case "desktop":
        return <Monitor className="h-3 w-3" />
      case "mobile":
        return <Smartphone className="h-3 w-3" />
      case "tablet":
        return <Tablet className="h-3 w-3" />
      default:
        return <Monitor className="h-3 w-3" />
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center">
                <Activity className="h-8 w-8 mr-3 text-blue-600" />
                Real-time Dashboard
              </h1>
              <p className="text-gray-600 mt-2">ติดตามข้อมูลแบบเรียลไทม์</p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${isConnected ? "bg-green-500 animate-pulse" : "bg-red-500"}`} />
                <span className="text-sm text-gray-600">{isConnected ? "เชื่อมต่อแล้ว" : "ไม่ได้เชื่อมต่อ"}</span>
              </div>
              <div className="text-sm text-gray-500">อัพเดทล่าสุด: {lastUpdate.toLocaleTimeString("th-TH")}</div>
              <Button variant="outline" size="sm">
                <RefreshCw className="h-4 w-4 mr-2" />
                รีเฟรช
              </Button>
            </div>
          </div>
        </div>

        {/* Real-time Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="relative overflow-hidden">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">ผู้ใช้ออนไลน์</p>
                  <p className="text-2xl font-bold">{realTimeData.activeUsers.toLocaleString()}</p>
                  <p className="text-xs text-green-600 flex items-center mt-1">
                    <TrendingUp className="h-3 w-3 mr-1" />
                    +5.2% จากเมื่อวาน
                  </p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <Users className="h-6 w-6 text-blue-600" />
                </div>
              </div>
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-400 to-blue-600"></div>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">คำสั่งซื้อปัจจุบัน</p>
                  <p className="text-2xl font-bold">{realTimeData.currentOrders}</p>
                  <p className="text-xs text-blue-600">รอดำเนินการ</p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <ShoppingCart className="h-6 w-6 text-green-600" />
                </div>
              </div>
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-green-400 to-green-600"></div>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">ยอดขายวันนี้</p>
                  <p className="text-2xl font-bold">฿{realTimeData.todayRevenue.toLocaleString()}</p>
                  <p className="text-xs text-purple-600 flex items-center mt-1">
                    <TrendingUp className="h-3 w-3 mr-1" />
                    +12.8% จากเป้าหมาย
                  </p>
                </div>
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                  <DollarSign className="h-6 w-6 text-purple-600" />
                </div>
              </div>
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-purple-400 to-purple-600"></div>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">API Requests</p>
                  <p className="text-2xl font-bold">{realTimeData.apiRequests.toLocaleString()}</p>
                  <p className="text-xs text-orange-600">ต่อชั่วโมง</p>
                </div>
                <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                  <Zap className="h-6 w-6 text-orange-600" />
                </div>
              </div>
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-orange-400 to-orange-600"></div>
            </CardContent>
          </Card>
        </div>

        {/* Live Activities and System Metrics */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>กิจกรรมแบบเรียลไทม์</span>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-sm text-gray-600">Live</span>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {liveActivities.map((activity) => (
                  <div
                    key={activity.id}
                    className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors"
                  >
                    <div className="flex-shrink-0 mt-1">{getActivityIcon(activity.type)}</div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900">{activity.message}</p>
                      <div className="flex items-center space-x-4 mt-1">
                        <div className="flex items-center space-x-1 text-xs text-gray-500">
                          <Clock className="h-3 w-3" />
                          <span>{activity.timestamp.toLocaleTimeString("th-TH")}</span>
                        </div>
                        <div className="flex items-center space-x-1 text-xs text-gray-500">
                          <MapPin className="h-3 w-3" />
                          <span>{activity.location}</span>
                        </div>
                        <div className="flex items-center space-x-1 text-xs text-gray-500">
                          {getDeviceIcon(activity.device)}
                          <span className="capitalize">{activity.device}</span>
                        </div>
                      </div>
                      {activity.amount && (
                        <p className="text-sm font-medium text-green-600 mt-1">฿{activity.amount.toLocaleString()}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>ประสิทธิภาพระบบ</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>CPU Usage</span>
                  <span>{mockSystemMetrics.cpu}%</span>
                </div>
                <Progress value={mockSystemMetrics.cpu} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Memory</span>
                  <span>{mockSystemMetrics.memory}%</span>
                </div>
                <Progress value={mockSystemMetrics.memory} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Disk Space</span>
                  <span>{mockSystemMetrics.disk}%</span>
                </div>
                <Progress value={mockSystemMetrics.disk} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Network</span>
                  <span>{mockSystemMetrics.network}%</span>
                </div>
                <Progress value={mockSystemMetrics.network} className="h-2" />
              </div>
              <div className="pt-4 border-t space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span>Uptime</span>
                  <Badge variant="outline" className="text-green-600 border-green-600">
                    {mockSystemMetrics.uptime}
                  </Badge>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>Response Time</span>
                  <span className="font-medium">{mockSystemMetrics.responseTime}ms</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>Throughput</span>
                  <span className="font-medium">{mockSystemMetrics.throughput}/min</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>Errors</span>
                  <span className="font-medium text-red-600">{mockSystemMetrics.errorCount}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Traffic Sources and Device Stats */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle>แหล่งที่มาของผู้เยี่ยมชม</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockTrafficSources.map((source, index) => (
                  <div key={source.source} className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <span className="text-sm font-bold text-blue-600">#{index + 1}</span>
                      </div>
                      <div>
                        <p className="font-medium">{source.source}</p>
                        <p className="text-sm text-gray-600">{source.visitors} ผู้เยี่ยมชม</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">{source.percentage}%</p>
                      <div className="w-20 h-2 bg-gray-200 rounded-full mt-1">
                        <div className="h-2 bg-blue-500 rounded-full" style={{ width: `${source.percentage}%` }}></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>อุปกรณ์ที่ใช้เข้าชม</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {mockDeviceStats.map((device) => (
                  <div key={device.device} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        {getDeviceIcon(device.device.toLowerCase())}
                        <span className="font-medium">{device.device}</span>
                      </div>
                      <div className="text-right">
                        <span className="font-medium">{device.count}</span>
                        <span className="text-sm text-gray-600 ml-2">({device.percentage}%)</span>
                      </div>
                    </div>
                    <Progress value={device.percentage} className="h-2" />
                  </div>
                ))}
              </div>
              <div className="mt-6 pt-4 border-t">
                <div className="text-center">
                  <p className="text-2xl font-bold">{mockDeviceStats.reduce((sum, d) => sum + d.count, 0)}</p>
                  <p className="text-sm text-gray-600">ผู้เยี่ยมชมทั้งหมด</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Real-time Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Server Load</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64 bg-gradient-to-br from-blue-50 to-indigo-100 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <Server className="h-16 w-16 text-blue-500 mx-auto mb-4" />
                  <p className="text-gray-600">กราฟ Server Load แบบเรียลไทม์</p>
                  <p className="text-sm text-gray-500">อัพเดททุก 5 วินาที</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Database Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64 bg-gradient-to-br from-green-50 to-teal-100 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <Database className="h-16 w-16 text-green-500 mx-auto mb-4" />
                  <p className="text-gray-600">ประสิทธิภาพฐานข้อมูล</p>
                  <p className="text-sm text-gray-500">Query time และ Connections</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Network Traffic</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64 bg-gradient-to-br from-purple-50 to-pink-100 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <Wifi className="h-16 w-16 text-purple-500 mx-auto mb-4" />
                  <p className="text-gray-600">การใช้งาน Network</p>
                  <p className="text-sm text-gray-500">Bandwidth และ Latency</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
