"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Wifi,
  WifiOff,
  Users,
  MessageSquare,
  Activity,
  Send,
  Settings,
  RefreshCw,
  AlertCircle,
  Zap,
} from "lucide-react"

// Mock WebSocket data
const mockConnections = [
  {
    id: "conn_1",
    userId: "admin@kdp.co.th",
    status: "connected",
    connectedAt: "2024-01-15T10:30:00Z",
    lastActivity: "2024-01-15T14:30:00Z",
    ip: "192.168.1.100",
    userAgent: "Chrome/120.0.0.0",
  },
  {
    id: "conn_2",
    userId: "sales@kdp.co.th",
    status: "connected",
    connectedAt: "2024-01-15T09:15:00Z",
    lastActivity: "2024-01-15T14:25:00Z",
    ip: "203.154.83.22",
    userAgent: "Safari/17.0",
  },
  {
    id: "conn_3",
    userId: "inventory@kdp.co.th",
    status: "disconnected",
    connectedAt: "2024-01-15T08:45:00Z",
    lastActivity: "2024-01-15T12:30:00Z",
    ip: "110.164.15.88",
    userAgent: "Firefox/121.0",
  },
]

const mockMessages = [
  {
    id: 1,
    type: "system",
    message: "WebSocket server started successfully",
    timestamp: "2024-01-15T14:30:00Z",
    level: "info",
  },
  {
    id: 2,
    type: "connection",
    message: "New client connected: admin@kdp.co.th",
    timestamp: "2024-01-15T14:29:45Z",
    level: "info",
  },
  {
    id: 3,
    type: "data",
    message: "Real-time inventory update sent to 5 clients",
    timestamp: "2024-01-15T14:29:30Z",
    level: "success",
  },
  {
    id: 4,
    type: "error",
    message: "Failed to send message to client conn_4: Connection closed",
    timestamp: "2024-01-15T14:29:15Z",
    level: "error",
  },
  {
    id: 5,
    type: "heartbeat",
    message: "Heartbeat sent to 12 active connections",
    timestamp: "2024-01-15T14:29:00Z",
    level: "info",
  },
]

const mockStats = {
  totalConnections: 156,
  activeConnections: 12,
  messagesSent: 2847,
  messagesReceived: 1923,
  uptime: "2 days, 14 hours",
  avgResponseTime: 45,
}

export default function WebSocketDashboard() {
  const [activeTab, setActiveTab] = useState("overview")
  const [isConnected, setIsConnected] = useState(true)
  const [messages, setMessages] = useState(mockMessages)
  const [newMessage, setNewMessage] = useState("")
  const [stats, setStats] = useState(mockStats)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      // Update stats
      setStats((prev) => ({
        ...prev,
        activeConnections: Math.max(5, Math.min(20, prev.activeConnections + Math.floor((Math.random() - 0.5) * 4))),
        messagesSent: prev.messagesSent + Math.floor(Math.random() * 10),
        messagesReceived: prev.messagesReceived + Math.floor(Math.random() * 8),
        avgResponseTime: Math.max(20, Math.min(100, prev.avgResponseTime + Math.floor((Math.random() - 0.5) * 10))),
      }))

      // Add random message
      if (Math.random() > 0.7) {
        const messageTypes = ["heartbeat", "data", "connection", "system"]
        const levels = ["info", "success", "warning", "error"]
        const sampleMessages = [
          "Heartbeat sent to active connections",
          "Real-time data update broadcasted",
          "New client connected",
          "Connection pool optimized",
          "Message queue processed",
        ]

        const newMsg = {
          id: Date.now(),
          type: messageTypes[Math.floor(Math.random() * messageTypes.length)],
          message: sampleMessages[Math.floor(Math.random() * sampleMessages.length)],
          timestamp: new Date().toISOString(),
          level: levels[Math.floor(Math.random() * levels.length)],
        }

        setMessages((prev) => [newMsg, ...prev.slice(0, 19)]) // Keep only last 20 messages
      }
    }, 3000)

    return () => clearInterval(interval)
  }, [])

  // Auto scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      const message = {
        id: Date.now(),
        type: "broadcast",
        message: `Broadcast: ${newMessage}`,
        timestamp: new Date().toISOString(),
        level: "info",
      }
      setMessages((prev) => [message, ...prev])
      setNewMessage("")
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "connected":
        return "text-green-600 bg-green-100"
      case "disconnected":
        return "text-red-600 bg-red-100"
      case "connecting":
        return "text-yellow-600 bg-yellow-100"
      default:
        return "text-gray-600 bg-gray-100"
    }
  }

  const getMessageIcon = (type: string) => {
    switch (type) {
      case "system":
        return <Settings className="h-4 w-4 text-blue-500" />
      case "connection":
        return <Users className="h-4 w-4 text-green-500" />
      case "data":
        return <Activity className="h-4 w-4 text-purple-500" />
      case "error":
        return <AlertCircle className="h-4 w-4 text-red-500" />
      case "heartbeat":
        return <Zap className="h-4 w-4 text-yellow-500" />
      default:
        return <MessageSquare className="h-4 w-4 text-gray-500" />
    }
  }

  const getLevelColor = (level: string) => {
    switch (level) {
      case "success":
        return "text-green-600"
      case "warning":
        return "text-yellow-600"
      case "error":
        return "text-red-600"
      default:
        return "text-gray-600"
    }
  }

  // WebSocket Overview
  const WebSocketOverview = () => (
    <div className="space-y-6">
      {/* Connection Status */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Server Status</p>
                <div className="flex items-center mt-2">
                  {isConnected ? (
                    <Wifi className="h-5 w-5 text-green-500 mr-2" />
                  ) : (
                    <WifiOff className="h-5 w-5 text-red-500 mr-2" />
                  )}
                  <span className={`text-lg font-semibold ${isConnected ? "text-green-600" : "text-red-600"}`}>
                    {isConnected ? "Online" : "Offline"}
                  </span>
                </div>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <Wifi className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Connections</p>
                <p className="text-2xl font-bold mt-1">{stats.activeConnections}</p>
              </div>
              <Users className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Messages Sent</p>
                <p className="text-2xl font-bold mt-1">{stats.messagesSent.toLocaleString()}</p>
              </div>
              <Send className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Avg Response</p>
                <p className="text-2xl font-bold mt-1">{stats.avgResponseTime}ms</p>
              </div>
              <Activity className="h-8 w-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Real-time Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Live Messages</span>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-sm text-gray-600">Live</span>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-96">
              <div className="space-y-3">
                {messages.map((message) => (
                  <div key={message.id} className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg">
                    {getMessageIcon(message.type)}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2 mb-1">
                        <Badge variant="outline">{message.type}</Badge>
                        <span className={`text-xs ${getLevelColor(message.level)}`}>{message.level.toUpperCase()}</span>
                      </div>
                      <p className="text-sm text-gray-900 mb-1">{message.message}</p>
                      <p className="text-xs text-gray-500">{new Date(message.timestamp).toLocaleTimeString()}</p>
                    </div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Connection Statistics</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <p className="text-2xl font-bold text-blue-600">{stats.totalConnections}</p>
                <p className="text-sm text-gray-600">Total Connections</p>
              </div>
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <p className="text-2xl font-bold text-green-600">{stats.activeConnections}</p>
                <p className="text-sm text-gray-600">Active Now</p>
              </div>
              <div className="text-center p-4 bg-purple-50 rounded-lg">
                <p className="text-2xl font-bold text-purple-600">{stats.messagesSent.toLocaleString()}</p>
                <p className="text-sm text-gray-600">Messages Sent</p>
              </div>
              <div className="text-center p-4 bg-orange-50 rounded-lg">
                <p className="text-2xl font-bold text-orange-600">{stats.messagesReceived.toLocaleString()}</p>
                <p className="text-sm text-gray-600">Messages Received</p>
              </div>
            </div>
            <div className="pt-4 border-t">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Server Uptime</span>
                <span className="text-sm text-gray-600">{stats.uptime}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Average Response Time</span>
                <span className="text-sm text-gray-600">{stats.avgResponseTime}ms</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )

  // Active Connections
  const ActiveConnections = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-bold">Active Connections</h3>
          <p className="text-gray-600">การเชื่อมต่อ WebSocket ที่ใช้งานอยู่</p>
        </div>
        <Button variant="outline">
          <RefreshCw className="h-4 w-4 mr-2" />
          รีเฟรช
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left p-4 font-medium">Connection ID</th>
                  <th className="text-left p-4 font-medium">User</th>
                  <th className="text-left p-4 font-medium">Status</th>
                  <th className="text-left p-4 font-medium">Connected At</th>
                  <th className="text-left p-4 font-medium">Last Activity</th>
                  <th className="text-left p-4 font-medium">IP Address</th>
                  <th className="text-left p-4 font-medium">User Agent</th>
                  <th className="text-left p-4 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {mockConnections.map((connection) => (
                  <tr key={connection.id} className="border-t hover:bg-gray-50">
                    <td className="p-4">
                      <code className="text-sm bg-gray-100 px-2 py-1 rounded">{connection.id}</code>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-2">
                        <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                          <Users className="h-4 w-4 text-blue-600" />
                        </div>
                        <span className="font-medium">{connection.userId}</span>
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-2">
                        <div
                          className={`w-2 h-2 rounded-full ${
                            connection.status === "connected" ? "bg-green-500" : "bg-red-500"
                          }`}
                        />
                        <Badge className={getStatusColor(connection.status)}>{connection.status}</Badge>
                      </div>
                    </td>
                    <td className="p-4">
                      <span className="text-sm">{new Date(connection.connectedAt).toLocaleString()}</span>
                    </td>
                    <td className="p-4">
                      <span className="text-sm">{new Date(connection.lastActivity).toLocaleString()}</span>
                    </td>
                    <td className="p-4">
                      <code className="text-sm bg-gray-100 px-2 py-1 rounded">{connection.ip}</code>
                    </td>
                    <td className="p-4">
                      <span className="text-sm text-gray-600">{connection.userAgent}</span>
                    </td>
                    <td className="p-4">
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline">
                          <MessageSquare className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline" className="text-red-600 bg-transparent">
                          <WifiOff className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  // Broadcast Messages
  const BroadcastMessages = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-bold">Broadcast Messages</h3>
        <p className="text-gray-600">ส่งข้อความไปยังผู้ใช้ทั้งหมดที่เชื่อมต่ออยู่</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Send Broadcast Message</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex space-x-2">
            <Input
              placeholder="พิมพ์ข้อความที่ต้องการส่ง..."
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
              className="flex-1"
            />
            <Button onClick={handleSendMessage} disabled={!newMessage.trim()}>
              <Send className="h-4 w-4 mr-2" />
              ส่ง
            </Button>
          </div>
          <p className="text-sm text-gray-600 mt-2">ข้อความจะถูกส่งไปยังผู้ใช้ที่เชื่อมต่ออยู่ทั้งหมด ({stats.activeConnections} คน)</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Message Templates</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Button
              variant="outline"
              className="h-auto p-4 text-left bg-transparent"
              onClick={() => setNewMessage("ระบบจะปิดปรับปรุงในอีก 5 นาที")}
            >
              <div>
                <p className="font-medium">Maintenance Alert</p>
                <p className="text-sm text-gray-600">แจ้งเตือนการปิดปรับปรุงระบบ</p>
              </div>
            </Button>
            <Button
              variant="outline"
              className="h-auto p-4 text-left bg-transparent"
              onClick={() => setNewMessage("มีสินค้าใหม่เข้ามาแล้ว! ตรวจสอบได้ที่หน้าสินค้า")}
            >
              <div>
                <p className="font-medium">New Product Alert</p>
                <p className="text-sm text-gray-600">แจ้งเตือนสินค้าใหม่</p>
              </div>
            </Button>
            <Button
              variant="outline"
              className="h-auto p-4 text-left bg-transparent"
              onClick={() => setNewMessage("โปรโมชั่นพิเศษ! ลดราคา 20% สำหรับสินค้าทุกชิ้น")}
            >
              <div>
                <p className="font-medium">Promotion Alert</p>
                <p className="text-sm text-gray-600">แจ้งเตือนโปรโมชั่น</p>
              </div>
            </Button>
            <Button
              variant="outline"
              className="h-auto p-4 text-left bg-transparent"
              onClick={() => setNewMessage("ข้อมูลสินค้าคงคลังได้รับการอัพเดทแล้ว")}
            >
              <div>
                <p className="font-medium">Inventory Update</p>
                <p className="text-sm text-gray-600">แจ้งเตือนอัพเดทสต็อก</p>
              </div>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center">
                <Wifi className="h-8 w-8 mr-3 text-blue-600" />
                WebSocket Dashboard
              </h1>
              <p className="text-gray-600 mt-2">จัดการการเชื่อมต่อแบบเรียลไทม์</p>
            </div>
            <div className="flex space-x-2">
              <Button
                variant="outline"
                onClick={() => setIsConnected(!isConnected)}
                className={isConnected ? "text-red-600" : "text-green-600"}
              >
                {isConnected ? <WifiOff className="h-4 w-4 mr-2" /> : <Wifi className="h-4 w-4 mr-2" />}
                {isConnected ? "Disconnect" : "Connect"}
              </Button>
              <Button variant="outline">
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </Button>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="connections">Connections</TabsTrigger>
            <TabsTrigger value="broadcast">Broadcast</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <WebSocketOverview />
          </TabsContent>

          <TabsContent value="connections">
            <ActiveConnections />
          </TabsContent>

          <TabsContent value="broadcast">
            <BroadcastMessages />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
