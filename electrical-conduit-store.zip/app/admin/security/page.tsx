"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Progress } from "@/components/ui/progress"
import {
  Shield,
  Lock,
  Key,
  Eye,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Clock,
  Users,
  Activity,
  FileText,
  Settings,
  Download,
  RefreshCw,
  Search,
  Filter,
  Smartphone,
  Globe,
} from "lucide-react"

// Mock security data
const mockSecurityMetrics = {
  threatLevel: "low",
  activeThreats: 2,
  blockedAttacks: 156,
  securityScore: 92,
  lastScan: "2024-01-15 14:30",
  vulnerabilities: 3,
  patchesAvailable: 5,
  sslStatus: "valid",
}

const mockSecurityEvents = [
  {
    id: 1,
    type: "login_attempt",
    severity: "medium",
    message: "Multiple failed login attempts from IP 192.168.1.100",
    timestamp: "2024-01-15 14:30:25",
    source: "192.168.1.100",
    user: "admin@kdp.co.th",
    status: "blocked",
    location: "Bangkok, Thailand",
  },
  {
    id: 2,
    type: "suspicious_activity",
    severity: "high",
    message: "Unusual API access pattern detected",
    timestamp: "2024-01-15 14:25:12",
    source: "203.154.83.45",
    user: "api_user",
    status: "investigating",
    location: "Unknown",
  },
  {
    id: 3,
    type: "malware_detected",
    severity: "critical",
    message: "Malware signature detected in uploaded file",
    timestamp: "2024-01-15 14:20:08",
    source: "10.0.0.15",
    user: "user@company.com",
    status: "quarantined",
    location: "Internal Network",
  },
  {
    id: 4,
    type: "access_granted",
    severity: "low",
    message: "Admin access granted to new user",
    timestamp: "2024-01-15 14:15:45",
    source: "192.168.1.50",
    user: "super_admin",
    status: "approved",
    location: "Bangkok, Thailand",
  },
]

const mockUserSessions = [
  {
    id: 1,
    user: "admin@kdp.co.th",
    device: "Chrome on Windows",
    location: "Bangkok, Thailand",
    ip: "192.168.1.100",
    loginTime: "2024-01-15 08:30",
    lastActivity: "2024-01-15 14:30",
    status: "active",
    mfaEnabled: true,
  },
  {
    id: 2,
    user: "sales@kdp.co.th",
    device: "Safari on iPhone",
    location: "Chiang Mai, Thailand",
    ip: "203.154.83.22",
    loginTime: "2024-01-15 09:15",
    lastActivity: "2024-01-15 14:25",
    status: "active",
    mfaEnabled: true,
  },
  {
    id: 3,
    user: "inventory@kdp.co.th",
    device: "Firefox on Linux",
    location: "Phuket, Thailand",
    ip: "110.164.15.88",
    loginTime: "2024-01-15 07:45",
    lastActivity: "2024-01-15 12:30",
    status: "idle",
    mfaEnabled: false,
  },
]

const mockAuditLogs = [
  {
    id: 1,
    user: "admin@kdp.co.th",
    action: "USER_CREATED",
    resource: "user:new_employee@kdp.co.th",
    details: "Created new user account with sales role",
    timestamp: "2024-01-15 14:30:25",
    ip: "192.168.1.100",
    success: true,
  },
  {
    id: 2,
    user: "sales@kdp.co.th",
    action: "PRODUCT_UPDATED",
    resource: "product:LB-75G",
    details: "Updated product price from ฿350 to ฿360",
    timestamp: "2024-01-15 14:25:12",
    ip: "203.154.83.22",
    success: true,
  },
  {
    id: 3,
    user: "inventory@kdp.co.th",
    action: "STOCK_ADJUSTED",
    resource: "product:T-100G",
    details: "Adjusted stock quantity from 150 to 200",
    timestamp: "2024-01-15 14:20:08",
    ip: "110.164.15.88",
    success: true,
  },
  {
    id: 4,
    user: "unknown",
    action: "LOGIN_FAILED",
    resource: "auth:admin@kdp.co.th",
    details: "Failed login attempt with incorrect password",
    timestamp: "2024-01-15 14:15:45",
    ip: "45.76.123.89",
    success: false,
  },
]

export default function SecurityDashboard() {
  const [activeTab, setActiveTab] = useState("overview")
  const [searchTerm, setSearchTerm] = useState("")

  // Security Overview
  const SecurityOverview = () => (
    <div className="space-y-6">
      {/* Security Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Security Score</p>
                <p className="text-2xl font-bold text-green-600">{mockSecurityMetrics.securityScore}%</p>
                <p className="text-xs text-green-600">Excellent</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <Shield className="h-6 w-6 text-green-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-green-400 to-green-600"></div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Threats</p>
                <p className="text-2xl font-bold text-orange-600">{mockSecurityMetrics.activeThreats}</p>
                <p className="text-xs text-orange-600">Monitoring</p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                <AlertTriangle className="h-6 w-6 text-orange-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-orange-400 to-orange-600"></div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Blocked Attacks</p>
                <p className="text-2xl font-bold text-blue-600">{mockSecurityMetrics.blockedAttacks}</p>
                <p className="text-xs text-blue-600">Last 24h</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <Lock className="h-6 w-6 text-blue-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-400 to-blue-600"></div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Vulnerabilities</p>
                <p className="text-2xl font-bold text-red-600">{mockSecurityMetrics.vulnerabilities}</p>
                <p className="text-xs text-red-600">Need attention</p>
              </div>
              <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                <XCircle className="h-6 w-6 text-red-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-red-400 to-red-600"></div>
          </CardContent>
        </Card>
      </div>

      {/* Security Status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Security Events</span>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-sm text-gray-600">Live</span>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {mockSecurityEvents.map((event) => (
                <div
                  key={event.id}
                  className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors"
                >
                  <div
                    className={`w-2 h-2 rounded-full mt-2 ${
                      event.severity === "critical"
                        ? "bg-red-500"
                        : event.severity === "high"
                          ? "bg-orange-500"
                          : event.severity === "medium"
                            ? "bg-yellow-500"
                            : "bg-green-500"
                    }`}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2 mb-1">
                      <Badge
                        variant={
                          event.severity === "critical"
                            ? "destructive"
                            : event.severity === "high"
                              ? "secondary"
                              : "outline"
                        }
                      >
                        {event.severity === "critical" && "Critical"}
                        {event.severity === "high" && "High"}
                        {event.severity === "medium" && "Medium"}
                        {event.severity === "low" && "Low"}
                      </Badge>
                      <Badge variant="outline">
                        {event.type === "login_attempt" && "Login Attempt"}
                        {event.type === "suspicious_activity" && "Suspicious Activity"}
                        {event.type === "malware_detected" && "Malware"}
                        {event.type === "access_granted" && "Access Granted"}
                      </Badge>
                    </div>
                    <p className="text-sm font-medium text-gray-900 mb-1">{event.message}</p>
                    <div className="flex items-center space-x-4 text-xs text-gray-500">
                      <span>{event.timestamp}</span>
                      <span>IP: {event.source}</span>
                      <span>User: {event.user}</span>
                      <span>{event.location}</span>
                    </div>
                  </div>
                  <Badge
                    variant={
                      event.status === "blocked"
                        ? "destructive"
                        : event.status === "investigating"
                          ? "secondary"
                          : event.status === "quarantined"
                            ? "outline"
                            : "default"
                    }
                  >
                    {event.status === "blocked" && "Blocked"}
                    {event.status === "investigating" && "Investigating"}
                    {event.status === "quarantined" && "Quarantined"}
                    {event.status === "approved" && "Approved"}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>System Health</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Firewall Status</span>
                <Badge variant="outline" className="text-green-600 border-green-600">
                  Active
                </Badge>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>SSL Certificate</span>
                <Badge variant="outline" className="text-green-600 border-green-600">
                  Valid
                </Badge>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Antivirus</span>
                <Badge variant="outline" className="text-green-600 border-green-600">
                  Updated
                </Badge>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Backup Status</span>
                <Badge variant="outline" className="text-green-600 border-green-600">
                  Completed
                </Badge>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Security Patches</span>
                <Badge variant="outline" className="text-orange-600 border-orange-600">
                  5 Available
                </Badge>
              </div>
            </div>
            <div className="pt-4 border-t">
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Overall Security</span>
                    <span className="font-medium text-green-600">{mockSecurityMetrics.securityScore}%</span>
                  </div>
                  <Progress value={mockSecurityMetrics.securityScore} className="h-2" />
                </div>
                <Button className="w-full" size="sm">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Run Security Scan
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Threat Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Threat Analysis</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80 bg-gradient-to-br from-red-50 to-orange-100 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <AlertTriangle className="h-16 w-16 text-red-500 mx-auto mb-4" />
                <p className="text-gray-600">Threat Detection Timeline</p>
                <p className="text-sm text-gray-500">แสดงการตรวจจับภัยคุกคามรายชั่วโมง</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Attack Sources</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80 bg-gradient-to-br from-blue-50 to-purple-100 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <Globe className="h-16 w-16 text-blue-500 mx-auto mb-4" />
                <p className="text-gray-600">Geographic Attack Map</p>
                <p className="text-sm text-gray-500">แสดงที่มาของการโจมตีทั่วโลก</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )

  // User Sessions Management
  const UserSessions = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-bold">Active User Sessions</h3>
          <p className="text-gray-600">จัดการเซสชั่นผู้ใช้ที่ใช้งานอยู่</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <RefreshCw className="h-4 w-4 mr-2" />
            รีเฟรช
          </Button>
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            ส่งออกรายงาน
          </Button>
        </div>
      </div>

      {/* Session Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Active Sessions</p>
                <p className="text-2xl font-bold text-green-600">12</p>
              </div>
              <Users className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">MFA Enabled</p>
                <p className="text-2xl font-bold text-blue-600">8</p>
              </div>
              <Key className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Suspicious</p>
                <p className="text-2xl font-bold text-orange-600">2</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Avg Duration</p>
                <p className="text-2xl font-bold text-purple-600">4.2h</p>
              </div>
              <Clock className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Sessions Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left p-4 font-medium">ผู้ใช้</th>
                  <th className="text-left p-4 font-medium">อุปกรณ์</th>
                  <th className="text-left p-4 font-medium">ตำแหน่ง</th>
                  <th className="text-left p-4 font-medium">IP Address</th>
                  <th className="text-left p-4 font-medium">เข้าสู่ระบบ</th>
                  <th className="text-left p-4 font-medium">กิจกรรมล่าสุด</th>
                  <th className="text-left p-4 font-medium">MFA</th>
                  <th className="text-left p-4 font-medium">สถานะ</th>
                  <th className="text-left p-4 font-medium">จัดการ</th>
                </tr>
              </thead>
              <tbody>
                {mockUserSessions.map((session) => (
                  <tr key={session.id} className="border-t hover:bg-gray-50">
                    <td className="p-4">
                      <div className="flex items-center space-x-2">
                        <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                          <Users className="h-4 w-4 text-blue-600" />
                        </div>
                        <span className="font-medium">{session.user}</span>
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-2">
                        <Smartphone className="h-4 w-4 text-gray-400" />
                        <span className="text-sm">{session.device}</span>
                      </div>
                    </td>
                    <td className="p-4">
                      <span className="text-sm">{session.location}</span>
                    </td>
                    <td className="p-4">
                      <code className="text-sm bg-gray-100 px-2 py-1 rounded">{session.ip}</code>
                    </td>
                    <td className="p-4">
                      <span className="text-sm">{session.loginTime}</span>
                    </td>
                    <td className="p-4">
                      <span className="text-sm">{session.lastActivity}</span>
                    </td>
                    <td className="p-4">
                      <Badge variant={session.mfaEnabled ? "default" : "destructive"}>
                        {session.mfaEnabled ? "Enabled" : "Disabled"}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-2">
                        <div
                          className={`w-2 h-2 rounded-full ${
                            session.status === "active" ? "bg-green-500" : "bg-yellow-500"
                          }`}
                        />
                        <Badge variant={session.status === "active" ? "default" : "secondary"}>
                          {session.status === "active" ? "Active" : "Idle"}
                        </Badge>
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline" className="text-red-600 hover:text-red-700 bg-transparent">
                          <XCircle className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  // Audit Logs
  const AuditLogs = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-bold">Audit Logs</h3>
          <p className="text-gray-600">บันทึกการใช้งานและการเปลี่ยนแปลงทั้งหมด</p>
        </div>
        <div className="flex space-x-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="ค้นหาบันทึก..."
              className="pl-10 w-64"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Select defaultValue="all">
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">ทั้งหมด</SelectItem>
              <SelectItem value="success">สำเร็จ</SelectItem>
              <SelectItem value="failed">ล้มเหลว</SelectItem>
              <SelectItem value="critical">สำคัญ</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm">
            <Filter className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            ส่งออก
          </Button>
        </div>
      </div>

      {/* Audit Logs Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left p-4 font-medium">เวลา</th>
                  <th className="text-left p-4 font-medium">ผู้ใช้</th>
                  <th className="text-left p-4 font-medium">การดำเนินการ</th>
                  <th className="text-left p-4 font-medium">ทรัพยากร</th>
                  <th className="text-left p-4 font-medium">รายละเอียด</th>
                  <th className="text-left p-4 font-medium">IP Address</th>
                  <th className="text-left p-4 font-medium">ผลลัพธ์</th>
                </tr>
              </thead>
              <tbody>
                {mockAuditLogs.map((log) => (
                  <tr key={log.id} className="border-t hover:bg-gray-50">
                    <td className="p-4">
                      <span className="text-sm font-mono">{log.timestamp}</span>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-2">
                        <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center">
                          <Users className="h-3 w-3 text-blue-600" />
                        </div>
                        <span className="text-sm">{log.user}</span>
                      </div>
                    </td>
                    <td className="p-4">
                      <Badge variant="outline">{log.action.replace("_", " ")}</Badge>
                    </td>
                    <td className="p-4">
                      <code className="text-sm bg-gray-100 px-2 py-1 rounded">{log.resource}</code>
                    </td>
                    <td className="p-4">
                      <span className="text-sm">{log.details}</span>
                    </td>
                    <td className="p-4">
                      <code className="text-sm bg-gray-100 px-2 py-1 rounded">{log.ip}</code>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-2">
                        {log.success ? (
                          <CheckCircle className="h-4 w-4 text-green-600" />
                        ) : (
                          <XCircle className="h-4 w-4 text-red-600" />
                        )}
                        <Badge variant={log.success ? "default" : "destructive"}>
                          {log.success ? "Success" : "Failed"}
                        </Badge>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  // Security Settings
  const SecuritySettings = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-bold">Security Settings</h3>
        <p className="text-gray-600">จัดการการตั้งค่าความปลอดภัยของระบบ</p>
      </div>

      <Tabs defaultValue="authentication" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="authentication">Authentication</TabsTrigger>
          <TabsTrigger value="access-control">Access Control</TabsTrigger>
          <TabsTrigger value="monitoring">Monitoring</TabsTrigger>
          <TabsTrigger value="backup">Backup & Recovery</TabsTrigger>
        </TabsList>

        <TabsContent value="authentication" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Authentication Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="require-mfa">Require Multi-Factor Authentication</Label>
                  <p className="text-sm text-gray-600">บังคับใช้ MFA สำหรับผู้ใช้ทั้งหมด</p>
                </div>
                <Switch id="require-mfa" defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="password-complexity">Strong Password Policy</Label>
                  <p className="text-sm text-gray-600">บังคับใช้รหัสผ่านที่ซับซ้อน</p>
                </div>
                <Switch id="password-complexity" defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="session-timeout">Auto Session Timeout</Label>
                  <p className="text-sm text-gray-600">ออกจากระบบอัตโนมัติเมื่อไม่ใช้งาน</p>
                </div>
                <Switch id="session-timeout" defaultChecked />
              </div>
              <div>
                <Label htmlFor="session-duration">Session Duration (minutes)</Label>
                <Input id="session-duration" type="number" defaultValue="30" />
              </div>
              <div>
                <Label htmlFor="max-login-attempts">Max Login Attempts</Label>
                <Input id="max-login-attempts" type="number" defaultValue="5" />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="access-control" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Access Control</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="ip-whitelist">IP Whitelist</Label>
                  <p className="text-sm text-gray-600">จำกัดการเข้าถึงจาก IP ที่กำหนด</p>
                </div>
                <Switch id="ip-whitelist" />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="geo-blocking">Geographic Blocking</Label>
                  <p className="text-sm text-gray-600">บล็อกการเข้าถึงจากประเทศที่เสี่ยง</p>
                </div>
                <Switch id="geo-blocking" />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="rate-limiting">Rate Limiting</Label>
                  <p className="text-sm text-gray-600">จำกัดจำนวน Request ต่อช่วงเวลา</p>
                </div>
                <Switch id="rate-limiting" defaultChecked />
              </div>
              <div>
                <Label htmlFor="allowed-ips">Allowed IP Addresses</Label>
                <textarea
                  id="allowed-ips"
                  className="w-full p-2 border rounded-md"
                  rows={4}
                  placeholder="192.168.1.0/24&#10;10.0.0.0/8"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="monitoring" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Security Monitoring</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="real-time-alerts">Real-time Security Alerts</Label>
                  <p className="text-sm text-gray-600">แจ้งเตือนภัยคุกคามแบบเรียลไทม์</p>
                </div>
                <Switch id="real-time-alerts" defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="failed-login-alerts">Failed Login Alerts</Label>
                  <p className="text-sm text-gray-600">แจ้งเตือนเมื่อมีการล็อกอินล้มเหลว</p>
                </div>
                <Switch id="failed-login-alerts" defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="suspicious-activity">Suspicious Activity Detection</Label>
                  <p className="text-sm text-gray-600">ตรวจจับกิจกรรมที่น่าสงสัย</p>
                </div>
                <Switch id="suspicious-activity" defaultChecked />
              </div>
              <div>
                <Label htmlFor="alert-email">Alert Email Address</Label>
                <Input id="alert-email" type="email" defaultValue="security@kdp.co.th" />
              </div>
              <div>
                <Label htmlFor="alert-threshold">Alert Threshold</Label>
                <Select defaultValue="medium">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="critical">Critical Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="backup" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Backup & Recovery</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="auto-backup">Automatic Backups</Label>
                  <p className="text-sm text-gray-600">สำรองข้อมูลอัตโนมัติ</p>
                </div>
                <Switch id="auto-backup" defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="encrypted-backup">Encrypted Backups</Label>
                  <p className="text-sm text-gray-600">เข้ารหัสไฟล์สำรองข้อมูล</p>
                </div>
                <Switch id="encrypted-backup" defaultChecked />
              </div>
              <div>
                <Label htmlFor="backup-frequency">Backup Frequency</Label>
                <Select defaultValue="daily">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hourly">ทุกชั่วโมง</SelectItem>
                    <SelectItem value="daily">ทุกวัน</SelectItem>
                    <SelectItem value="weekly">ทุกสัปดาห์</SelectItem>
                    <SelectItem value="monthly">ทุกเดือน</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="retention-period">Retention Period (days)</Label>
                <Input id="retention-period" type="number" defaultValue="30" />
              </div>
              <div>
                <Label htmlFor="backup-location">Backup Location</Label>
                <Select defaultValue="cloud">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="local">Local Storage</SelectItem>
                    <SelectItem value="cloud">Cloud Storage</SelectItem>
                    <SelectItem value="both">Both</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center">
                <Shield className="h-8 w-8 mr-3 text-blue-600" />
                Security Dashboard
              </h1>
              <p className="text-gray-600 mt-2">ระบบรักษาความปลอดภัยขั้นสูง</p>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline">
                <Activity className="h-4 w-4 mr-2" />
                System Status
              </Button>
              <Button variant="outline">
                <FileText className="h-4 w-4 mr-2" />
                Security Report
              </Button>
              <Button>
                <Settings className="h-4 w-4 mr-2" />
                Security Settings
              </Button>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="overview" className="flex items-center space-x-2">
              <Shield className="h-4 w-4" />
              <span>ภาพรวม</span>
            </TabsTrigger>
            <TabsTrigger value="sessions" className="flex items-center space-x-2">
              <Users className="h-4 w-4" />
              <span>User Sessions</span>
            </TabsTrigger>
            <TabsTrigger value="audit" className="flex items-center space-x-2">
              <FileText className="h-4 w-4" />
              <span>Audit Logs</span>
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center space-x-2">
              <Settings className="h-4 w-4" />
              <span>ตั้งค่า</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <SecurityOverview />
          </TabsContent>

          <TabsContent value="sessions">
            <UserSessions />
          </TabsContent>

          <TabsContent value="audit">
            <AuditLogs />
          </TabsContent>

          <TabsContent value="settings">
            <SecuritySettings />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
