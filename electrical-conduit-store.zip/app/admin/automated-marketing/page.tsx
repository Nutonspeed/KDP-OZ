"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Zap,
  Mail,
  MessageSquare,
  Bell,
  Users,
  Target,
  Play,
  Pause,
  Settings,
  Plus,
  Edit,
  Eye,
  Copy,
  RefreshCw,
  Download,
  Activity,
  TrendingUp,
  ShoppingCart,
  Gift,
  AlertTriangle,
  CheckCircle,
  Star,
  DollarSign,
} from "lucide-react"

// Mock automated marketing data
const mockAutomatedMarketingData = {
  workflows: [
    {
      id: 1,
      name: "Welcome Series",
      description: "ต้อนรับลูกค้าใหม่ด้วยอีเมล 3 ฉบับ",
      type: "email",
      trigger: "user_registration",
      status: "active",
      subscribers: 156,
      openRate: 68.5,
      clickRate: 24.3,
      conversionRate: 12.8,
      revenue: 125000,
      steps: 3,
      lastRun: "2024-01-15 14:30",
      nextRun: "2024-01-15 15:00",
    },
    {
      id: 2,
      name: "Abandoned Cart Recovery",
      description: "กู้คืนตะกร้าสินค้าที่ถูกทิ้ง",
      type: "email",
      trigger: "cart_abandonment",
      status: "active",
      subscribers: 89,
      openRate: 45.2,
      clickRate: 18.7,
      conversionRate: 8.9,
      revenue: 89000,
      steps: 2,
      lastRun: "2024-01-15 13:45",
      nextRun: "2024-01-15 16:00",
    },
    {
      id: 3,
      name: "Win-back Campaign",
      description: "ดึงลูกค้าเก่ากลับมา",
      type: "sms",
      trigger: "inactive_customer",
      status: "active",
      subscribers: 45,
      openRate: 92.1,
      clickRate: 34.5,
      conversionRate: 15.6,
      revenue: 67500,
      steps: 4,
      lastRun: "2024-01-15 12:00",
      nextRun: "2024-01-16 12:00",
    },
    {
      id: 4,
      name: "Birthday Special",
      description: "ส่งคูปองวันเกิด",
      type: "email",
      trigger: "birthday",
      status: "paused",
      subscribers: 234,
      openRate: 78.9,
      clickRate: 45.2,
      conversionRate: 28.7,
      revenue: 156000,
      steps: 1,
      lastRun: "2024-01-14 09:00",
      nextRun: null,
    },
    {
      id: 5,
      name: "Product Recommendation",
      description: "แนะนำสินค้าตามพฤติกรรม",
      type: "push",
      trigger: "browsing_behavior",
      status: "active",
      subscribers: 312,
      openRate: 34.7,
      clickRate: 12.8,
      conversionRate: 6.4,
      revenue: 98000,
      steps: 1,
      lastRun: "2024-01-15 14:00",
      nextRun: "2024-01-15 15:30",
    },
  ],
  triggers: [
    {
      id: "user_registration",
      name: "User Registration",
      description: "เมื่อมีผู้ใช้ลงทะเบียนใหม่",
      icon: Users,
      count: 156,
    },
    {
      id: "cart_abandonment",
      name: "Cart Abandonment",
      description: "เมื่อทิ้งตะกร้าสินค้า >30 นาที",
      icon: ShoppingCart,
      count: 89,
    },
    {
      id: "purchase_complete",
      name: "Purchase Complete",
      description: "เมื่อซื้อสินค้าสำเร็จ",
      icon: CheckCircle,
      count: 234,
    },
    {
      id: "inactive_customer",
      name: "Inactive Customer",
      description: "ไม่ซื้อสินค้า >60 วัน",
      icon: AlertTriangle,
      count: 45,
    },
    {
      id: "birthday",
      name: "Birthday",
      description: "วันเกิดของลูกค้า",
      icon: Gift,
      count: 12,
    },
    {
      id: "browsing_behavior",
      name: "Browsing Behavior",
      description: "ดูสินค้าแต่ไม่ซื้อ",
      icon: Eye,
      count: 312,
    },
  ],
  campaigns: [
    {
      id: 1,
      name: "Flash Sale Alert",
      type: "email",
      segment: "all",
      status: "completed",
      sent: 1247,
      opened: 856,
      clicked: 234,
      converted: 89,
      revenue: 234000,
      roi: 340,
      sentDate: "2024-01-10",
    },
    {
      id: 2,
      name: "VIP Exclusive Offer",
      type: "sms",
      segment: "vip",
      status: "active",
      sent: 45,
      opened: 42,
      clicked: 28,
      converted: 18,
      revenue: 156000,
      roi: 520,
      sentDate: "2024-01-15",
    },
    {
      id: 3,
      name: "New Product Launch",
      type: "push",
      segment: "loyal",
      status: "scheduled",
      sent: 0,
      opened: 0,
      clicked: 0,
      converted: 0,
      revenue: 0,
      roi: 0,
      sentDate: "2024-01-20",
    },
  ],
  abTests: [
    {
      id: 1,
      name: "Welcome Email Subject Line",
      type: "subject_line",
      status: "running",
      variantA: {
        name: "ยินดีต้อนรับสู่ KDP!",
        sent: 78,
        opened: 52,
        clicked: 18,
        converted: 8,
      },
      variantB: {
        name: "เริ่มต้นช้อปปิ้งกับเรา",
        sent: 78,
        opened: 61,
        clicked: 24,
        converted: 12,
      },
      winner: "B",
      confidence: 87.5,
      startDate: "2024-01-10",
      endDate: "2024-01-17",
    },
    {
      id: 2,
      name: "Cart Recovery CTA Button",
      type: "cta_button",
      status: "completed",
      variantA: {
        name: "กลับไปชำระเงิน",
        sent: 45,
        opened: 32,
        clicked: 12,
        converted: 4,
      },
      variantB: {
        name: "ซื้อเลย!",
        sent: 44,
        opened: 31,
        clicked: 18,
        converted: 8,
      },
      winner: "B",
      confidence: 92.3,
      startDate: "2024-01-05",
      endDate: "2024-01-12",
    },
  ],
  performance: {
    totalRevenue: 1245000,
    totalSent: 2456,
    avgOpenRate: 58.7,
    avgClickRate: 23.4,
    avgConversionRate: 12.8,
    avgROI: 285,
    activeWorkflows: 4,
    scheduledCampaigns: 3,
  },
}

export default function AutomatedMarketing() {
  const [selectedWorkflow, setSelectedWorkflow] = useState(null)
  const [isCreateWorkflowOpen, setIsCreateWorkflowOpen] = useState(false)

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "text-green-600 bg-green-100"
      case "paused":
        return "text-yellow-600 bg-yellow-100"
      case "completed":
        return "text-blue-600 bg-blue-100"
      case "scheduled":
        return "text-purple-600 bg-purple-100"
      default:
        return "text-gray-600 bg-gray-100"
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "email":
        return <Mail className="h-4 w-4" />
      case "sms":
        return <MessageSquare className="h-4 w-4" />
      case "push":
        return <Bell className="h-4 w-4" />
      default:
        return <Activity className="h-4 w-4" />
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center">
                <Zap className="h-8 w-8 mr-3 text-orange-600" />
                Automated Marketing
              </h1>
              <p className="text-gray-600 mt-2">ระบบการตลาดอัตโนมัติขั้นสูง</p>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline">
                <RefreshCw className="h-4 w-4 mr-2" />
                Sync Data
              </Button>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Export Report
              </Button>
              <Button onClick={() => setIsCreateWorkflowOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Create Workflow
              </Button>
            </div>
          </div>
        </div>

        {/* Performance Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="relative overflow-hidden">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Revenue</p>
                  <p className="text-2xl font-bold">
                    ฿{mockAutomatedMarketingData.performance.totalRevenue.toLocaleString()}
                  </p>
                  <p className="text-xs text-green-600 flex items-center mt-1">
                    <TrendingUp className="h-3 w-3 mr-1" />
                    +18.5% จากเดือนที่แล้ว
                  </p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <DollarSign className="h-6 w-6 text-green-600" />
                </div>
              </div>
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-green-400 to-green-600"></div>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Avg Open Rate</p>
                  <p className="text-2xl font-bold">{mockAutomatedMarketingData.performance.avgOpenRate}%</p>
                  <p className="text-xs text-blue-600">Industry avg: 45%</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <Mail className="h-6 w-6 text-blue-600" />
                </div>
              </div>
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-400 to-blue-600"></div>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Avg ROI</p>
                  <p className="text-2xl font-bold">{mockAutomatedMarketingData.performance.avgROI}%</p>
                  <p className="text-xs text-purple-600">Excellent performance</p>
                </div>
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                  <Target className="h-6 w-6 text-purple-600" />
                </div>
              </div>
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-purple-400 to-purple-600"></div>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Active Workflows</p>
                  <p className="text-2xl font-bold">{mockAutomatedMarketingData.performance.activeWorkflows}</p>
                  <p className="text-xs text-orange-600">
                    {mockAutomatedMarketingData.performance.scheduledCampaigns} scheduled
                  </p>
                </div>
                <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                  <Zap className="h-6 w-6 text-orange-600" />
                </div>
              </div>
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-orange-400 to-orange-600"></div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="workflows" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="workflows">Workflows</TabsTrigger>
            <TabsTrigger value="campaigns">Campaigns</TabsTrigger>
            <TabsTrigger value="triggers">Triggers</TabsTrigger>
            <TabsTrigger value="testing">A/B Testing</TabsTrigger>
          </TabsList>

          <TabsContent value="workflows" className="space-y-6">
            {/* Workflows Table */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Marketing Workflows</span>
                  <div className="flex space-x-2">
                    <Select>
                      <SelectTrigger className="w-32">
                        <SelectValue placeholder="Filter" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All</SelectItem>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="paused">Paused</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="text-left p-4 font-medium">Workflow</th>
                        <th className="text-left p-4 font-medium">Type</th>
                        <th className="text-left p-4 font-medium">Trigger</th>
                        <th className="text-left p-4 font-medium">Performance</th>
                        <th className="text-left p-4 font-medium">Revenue</th>
                        <th className="text-left p-4 font-medium">Status</th>
                        <th className="text-left p-4 font-medium">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {mockAutomatedMarketingData.workflows.map((workflow) => (
                        <tr key={workflow.id} className="border-t hover:bg-gray-50">
                          <td className="p-4">
                            <div>
                              <p className="font-medium">{workflow.name}</p>
                              <p className="text-sm text-gray-600">{workflow.description}</p>
                              <p className="text-xs text-gray-500">
                                {workflow.steps} steps • {workflow.subscribers} subscribers
                              </p>
                            </div>
                          </td>
                          <td className="p-4">
                            <div className="flex items-center space-x-2">
                              {getTypeIcon(workflow.type)}
                              <span className="text-sm capitalize">{workflow.type}</span>
                            </div>
                          </td>
                          <td className="p-4">
                            <Badge variant="outline" className="text-xs">
                              {workflow.trigger.replace("_", " ")}
                            </Badge>
                          </td>
                          <td className="p-4">
                            <div className="space-y-1">
                              <div className="flex justify-between text-xs">
                                <span>Open: {workflow.openRate}%</span>
                                <span>Click: {workflow.clickRate}%</span>
                              </div>
                              <div className="flex justify-between text-xs">
                                <span>Convert: {workflow.conversionRate}%</span>
                              </div>
                              <Progress value={workflow.conversionRate} className="h-1" />
                            </div>
                          </td>
                          <td className="p-4">
                            <p className="font-medium text-green-600">฿{workflow.revenue.toLocaleString()}</p>
                          </td>
                          <td className="p-4">
                            <Badge className={getStatusColor(workflow.status)}>{workflow.status}</Badge>
                          </td>
                          <td className="p-4">
                            <div className="flex space-x-2">
                              <Button size="sm" variant="outline">
                                <Eye className="h-4 w-4" />
                              </Button>
                              <Button size="sm" variant="outline">
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button size="sm" variant="outline">
                                {workflow.status === "active" ? (
                                  <Pause className="h-4 w-4" />
                                ) : (
                                  <Play className="h-4 w-4" />
                                )}
                              </Button>
                              <Button size="sm" variant="outline">
                                <Copy className="h-4 w-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="campaigns" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Marketing Campaigns</span>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    New Campaign
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="text-left p-4 font-medium">Campaign</th>
                        <th className="text-left p-4 font-medium">Type</th>
                        <th className="text-left p-4 font-medium">Segment</th>
                        <th className="text-left p-4 font-medium">Performance</th>
                        <th className="text-left p-4 font-medium">Revenue</th>
                        <th className="text-left p-4 font-medium">ROI</th>
                        <th className="text-left p-4 font-medium">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {mockAutomatedMarketingData.campaigns.map((campaign) => (
                        <tr key={campaign.id} className="border-t hover:bg-gray-50">
                          <td className="p-4">
                            <div>
                              <p className="font-medium">{campaign.name}</p>
                              <p className="text-xs text-gray-500">Sent: {campaign.sentDate}</p>
                            </div>
                          </td>
                          <td className="p-4">
                            <div className="flex items-center space-x-2">
                              {getTypeIcon(campaign.type)}
                              <span className="text-sm capitalize">{campaign.type}</span>
                            </div>
                          </td>
                          <td className="p-4">
                            <Badge variant="outline">{campaign.segment}</Badge>
                          </td>
                          <td className="p-4">
                            <div className="space-y-1">
                              <div className="flex justify-between text-xs">
                                <span>Sent: {campaign.sent}</span>
                                <span>Opened: {campaign.opened}</span>
                              </div>
                              <div className="flex justify-between text-xs">
                                <span>Clicked: {campaign.clicked}</span>
                                <span>Converted: {campaign.converted}</span>
                              </div>
                              {campaign.sent > 0 && (
                                <Progress value={(campaign.converted / campaign.sent) * 100} className="h-1" />
                              )}
                            </div>
                          </td>
                          <td className="p-4">
                            <p className="font-medium text-green-600">฿{campaign.revenue.toLocaleString()}</p>
                          </td>
                          <td className="p-4">
                            {campaign.roi > 0 && <Badge className="text-green-600 bg-green-100">{campaign.roi}%</Badge>}
                          </td>
                          <td className="p-4">
                            <Badge className={getStatusColor(campaign.status)}>{campaign.status}</Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="triggers" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {mockAutomatedMarketingData.triggers.map((trigger) => (
                <Card key={trigger.id} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                        <trigger.icon className="h-6 w-6 text-blue-600" />
                      </div>
                      <Badge variant="outline">{trigger.count} events</Badge>
                    </div>
                    <div className="space-y-2">
                      <h3 className="text-lg font-semibold">{trigger.name}</h3>
                      <p className="text-sm text-gray-600">{trigger.description}</p>
                      <div className="flex space-x-2 mt-4">
                        <Button size="sm" variant="outline" className="flex-1 bg-transparent">
                          <Settings className="h-4 w-4 mr-2" />
                          Configure
                        </Button>
                        <Button size="sm" className="flex-1">
                          <Plus className="h-4 w-4 mr-2" />
                          Create Workflow
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="testing" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>A/B Testing</span>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    New Test
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {mockAutomatedMarketingData.abTests.map((test) => (
                    <div key={test.id} className="border rounded-lg p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <h3 className="text-lg font-semibold">{test.name}</h3>
                          <p className="text-sm text-gray-600">
                            {test.startDate} - {test.endDate}
                          </p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge className={getStatusColor(test.status)}>{test.status}</Badge>
                          {test.winner && (
                            <Badge className="text-green-600 bg-green-100">
                              Winner: {test.winner} ({test.confidence}% confidence)
                            </Badge>
                          )}
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="p-4 border rounded-lg">
                          <div className="flex items-center justify-between mb-3">
                            <h4 className="font-medium">Variant A</h4>
                            {test.winner === "A" && <Star className="h-4 w-4 text-yellow-500" />}
                          </div>
                          <p className="text-sm text-gray-600 mb-3">"{test.variantA.name}"</p>
                          <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span>Sent:</span>
                              <span>{test.variantA.sent}</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span>Opened:</span>
                              <span>
                                {test.variantA.opened} ({((test.variantA.opened / test.variantA.sent) * 100).toFixed(1)}
                                %)
                              </span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span>Clicked:</span>
                              <span>
                                {test.variantA.clicked} (
                                {((test.variantA.clicked / test.variantA.sent) * 100).toFixed(1)}%)
                              </span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span>Converted:</span>
                              <span>
                                {test.variantA.converted} (
                                {((test.variantA.converted / test.variantA.sent) * 100).toFixed(1)}%)
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="p-4 border rounded-lg">
                          <div className="flex items-center justify-between mb-3">
                            <h4 className="font-medium">Variant B</h4>
                            {test.winner === "B" && <Star className="h-4 w-4 text-yellow-500" />}
                          </div>
                          <p className="text-sm text-gray-600 mb-3">"{test.variantB.name}"</p>
                          <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span>Sent:</span>
                              <span>{test.variantB.sent}</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span>Opened:</span>
                              <span>
                                {test.variantB.opened} ({((test.variantB.opened / test.variantB.sent) * 100).toFixed(1)}
                                %)
                              </span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span>Clicked:</span>
                              <span>
                                {test.variantB.clicked} (
                                {((test.variantB.clicked / test.variantB.sent) * 100).toFixed(1)}%)
                              </span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span>Converted:</span>
                              <span>
                                {test.variantB.converted} (
                                {((test.variantB.converted / test.variantB.sent) * 100).toFixed(1)}%)
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
