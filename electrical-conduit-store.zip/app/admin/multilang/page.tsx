"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Progress } from "@/components/ui/progress"
import {
  Globe,
  Languages,
  FileText,
  Users,
  BarChart3,
  Settings,
  Plus,
  Edit,
  Trash2,
  Eye,
  Download,
  Upload,
  Target,
  TrendingUp,
  Search,
  Filter,
  Copy,
  RefreshCw,
} from "lucide-react"

// Mock data for multi-language support
const mockLanguages = [
  {
    id: 1,
    code: "th",
    name: "ไทย",
    nativeName: "ไทย",
    flag: "🇹🇭",
    status: "active",
    progress: 100,
    totalStrings: 1245,
    translatedStrings: 1245,
    lastUpdated: "2024-01-15",
    translator: "Admin User",
    isDefault: true,
  },
  {
    id: 2,
    code: "en",
    name: "English",
    nativeName: "English",
    flag: "🇺🇸",
    status: "active",
    progress: 98,
    totalStrings: 1245,
    translatedStrings: 1220,
    lastUpdated: "2024-01-14",
    translator: "John Smith",
    isDefault: false,
  },
  {
    id: 3,
    code: "zh",
    name: "Chinese",
    nativeName: "中文",
    flag: "🇨🇳",
    status: "active",
    progress: 85,
    totalStrings: 1245,
    translatedStrings: 1058,
    lastUpdated: "2024-01-12",
    translator: "Li Wei",
    isDefault: false,
  },
  {
    id: 4,
    code: "ja",
    name: "Japanese",
    nativeName: "日本語",
    flag: "🇯🇵",
    status: "draft",
    progress: 45,
    totalStrings: 1245,
    translatedStrings: 560,
    lastUpdated: "2024-01-10",
    translator: "Tanaka San",
    isDefault: false,
  },
]

const mockTranslationStrings = [
  {
    id: 1,
    key: "common.welcome",
    category: "common",
    th: "ยินดีต้อนรับ",
    en: "Welcome",
    zh: "欢迎",
    ja: "いらっしゃいませ",
    description: "Welcome message for users",
    lastUpdated: "2024-01-15",
  },
  {
    id: 2,
    key: "product.name",
    category: "product",
    th: "ชื่อสินค้า",
    en: "Product Name",
    zh: "产品名称",
    ja: "商品名",
    description: "Label for product name field",
    lastUpdated: "2024-01-14",
  },
  {
    id: 3,
    key: "order.total",
    category: "order",
    th: "ยอดรวม",
    en: "Total Amount",
    zh: "总金额",
    ja: "合計金額",
    description: "Total amount in order summary",
    lastUpdated: "2024-01-13",
  },
  {
    id: 4,
    key: "button.add_to_cart",
    category: "button",
    th: "เพิ่มลงตะกร้า",
    en: "Add to Cart",
    zh: "加入购物车",
    ja: "カートに追加",
    description: "Add to cart button text",
    lastUpdated: "2024-01-12",
  },
]

const mockTranslationStats = [
  { language: "th", visitors: 2450, orders: 145, revenue: 125000, conversionRate: 5.9 },
  { language: "en", visitors: 1890, orders: 98, revenue: 89000, conversionRate: 5.2 },
  { language: "zh", visitors: 1234, orders: 67, revenue: 67000, conversionRate: 5.4 },
  { language: "ja", visitors: 567, orders: 23, revenue: 34000, conversionRate: 4.1 },
]

export default function MultiLanguageManagement() {
  const [activeTab, setActiveTab] = useState("overview")
  const [selectedLanguage, setSelectedLanguage] = useState("th")
  const [searchTerm, setSearchTerm] = useState("")

  // Multi-language Overview
  const LanguageOverview = () => (
    <div className="space-y-6">
      {/* Language Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">ภาษาที่รองรับ</p>
                <p className="text-2xl font-bold">4</p>
                <p className="text-xs text-green-600 flex items-center mt-1">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  +1 ภาษาใหม่เดือนนี้
                </p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <Languages className="h-6 w-6 text-blue-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-400 to-blue-600"></div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">ข้อความทั้งหมด</p>
                <p className="text-2xl font-bold">1,245</p>
                <p className="text-xs text-purple-600">+25 ข้อความใหม่</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                <FileText className="h-6 w-6 text-purple-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-purple-400 to-purple-600"></div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">ความสมบูรณ์เฉลี่ย</p>
                <p className="text-2xl font-bold">82%</p>
                <p className="text-xs text-green-600">+5% จากเดือนที่แล้ว</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <Target className="h-6 w-6 text-green-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-green-400 to-green-600"></div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">ผู้ใช้หลายภาษา</p>
                <p className="text-2xl font-bold">6,141</p>
                <p className="text-xs text-orange-600">35% ของผู้ใช้ทั้งหมด</p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                <Users className="h-6 w-6 text-orange-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-orange-400 to-orange-600"></div>
          </CardContent>
        </Card>
      </div>

      {/* Language Progress */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>ความคืบหน้าการแปล</span>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              เพิ่มภาษาใหม่
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {mockLanguages.map((language) => (
              <Card key={language.id} className="border-2">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <span className="text-2xl">{language.flag}</span>
                      <div>
                        <p className="font-medium">{language.nativeName}</p>
                        <p className="text-sm text-gray-600">{language.name}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {language.isDefault && <Badge variant="default">ภาษาหลัก</Badge>}
                      <Badge variant={language.status === "active" ? "default" : "secondary"}>
                        {language.status === "active" ? "ใช้งาน" : "ร่าง"}
                      </Badge>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>ความสมบูรณ์</span>
                      <span className="font-medium">{language.progress}%</span>
                    </div>
                    <Progress value={language.progress} className="h-2" />
                    <p className="text-xs text-gray-500 mt-1">
                      {language.translatedStrings} / {language.totalStrings} ข้อความ
                    </p>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-gray-600">อัพเดทล่าสุด</p>
                      <p className="font-medium">{language.lastUpdated}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">ผู้แปล</p>
                      <p className="font-medium">{language.translator}</p>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline" className="flex-1 bg-transparent">
                      <Edit className="h-4 w-4 mr-2" />
                      แก้ไข
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1 bg-transparent">
                      <Eye className="h-4 w-4 mr-2" />
                      ดูตัวอย่าง
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Language Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>ประสิทธิภาพตามภาษา</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {mockTranslationStats.map((stat, index) => {
                const language = mockLanguages.find((l) => l.code === stat.language)
                return (
                  <div key={stat.language} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <span className="text-xl">{language?.flag}</span>
                      <div>
                        <p className="font-medium">{language?.nativeName}</p>
                        <p className="text-sm text-gray-600">{stat.visitors.toLocaleString()} ผู้เยี่ยมชม</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">฿{stat.revenue.toLocaleString()}</p>
                      <p className="text-sm text-gray-600">{stat.orders} คำสั่งซื้อ</p>
                      <p className="text-xs text-green-600">{stat.conversionRate}% conversion</p>
                    </div>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>การใช้งานภาษา</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80 bg-gradient-to-br from-blue-50 to-purple-100 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <BarChart3 className="h-16 w-16 text-blue-500 mx-auto mb-4" />
                <p className="text-gray-600">กราฟการใช้งานภาษา</p>
                <p className="text-sm text-gray-500">แสดงสัดส่วนผู้ใช้แต่ละภาษา</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )

  // Translation Management
  const TranslationManagement = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-bold">จัดการการแปล</h3>
          <p className="text-gray-600">แก้ไขและจัดการข้อความในแต่ละภาษา</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            ส่งออก CSV
          </Button>
          <Button variant="outline">
            <Upload className="h-4 w-4 mr-2" />
            นำเข้า CSV
          </Button>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            เพิ่มข้อความใหม่
          </Button>
        </div>
      </div>

      {/* Translation Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center space-x-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="ค้นหาข้อความ..."
                  className="pl-10"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <Select defaultValue="all">
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">หมวดหมู่ทั้งหมด</SelectItem>
                <SelectItem value="common">ทั่วไป</SelectItem>
                <SelectItem value="product">สินค้า</SelectItem>
                <SelectItem value="order">คำสั่งซื้อ</SelectItem>
                <SelectItem value="button">ปุ่ม</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {mockLanguages.map((lang) => (
                  <SelectItem key={lang.code} value={lang.code}>
                    {lang.flag} {lang.nativeName}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm">
              <Filter className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Translation Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left p-4 font-medium">Key</th>
                  <th className="text-left p-4 font-medium">หมวดหมู่</th>
                  <th className="text-left p-4 font-medium">ไทย</th>
                  <th className="text-left p-4 font-medium">English</th>
                  <th className="text-left p-4 font-medium">中文</th>
                  <th className="text-left p-4 font-medium">日本語</th>
                  <th className="text-left p-4 font-medium">อัพเดทล่าสุด</th>
                  <th className="text-left p-4 font-medium">จัดการ</th>
                </tr>
              </thead>
              <tbody>
                {mockTranslationStrings.map((string) => (
                  <tr key={string.id} className="border-t hover:bg-gray-50">
                    <td className="p-4">
                      <div>
                        <code className="text-sm font-mono bg-gray-100 px-2 py-1 rounded">{string.key}</code>
                        <p className="text-xs text-gray-500 mt-1">{string.description}</p>
                      </div>
                    </td>
                    <td className="p-4">
                      <Badge variant="outline">{string.category}</Badge>
                    </td>
                    <td className="p-4">
                      <p className="text-sm">{string.th}</p>
                    </td>
                    <td className="p-4">
                      <p className="text-sm">{string.en}</p>
                    </td>
                    <td className="p-4">
                      <p className="text-sm">{string.zh}</p>
                    </td>
                    <td className="p-4">
                      <p className="text-sm">{string.ja}</p>
                    </td>
                    <td className="p-4">
                      <p className="text-sm">{string.lastUpdated}</p>
                    </td>
                    <td className="p-4">
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline" className="text-red-600 hover:text-red-700 bg-transparent">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Add New Translation */}
      <Card>
        <CardHeader>
          <CardTitle>เพิ่มข้อความใหม่</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="translation-key">Key</Label>
              <Input id="translation-key" placeholder="เช่น common.hello" />
            </div>
            <div>
              <Label htmlFor="translation-category">หมวดหมู่</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="เลือกหมวดหมู่" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="common">ทั่วไป</SelectItem>
                  <SelectItem value="product">สินค้า</SelectItem>
                  <SelectItem value="order">คำสั่งซื้อ</SelectItem>
                  <SelectItem value="button">ปุ่ม</SelectItem>
                  <SelectItem value="error">ข้อผิดพลาด</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <Label htmlFor="translation-description">คำอธิบาย</Label>
            <Input id="translation-description" placeholder="อธิบายการใช้งานข้อความนี้" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="translation-th">ไทย</Label>
              <Input id="translation-th" placeholder="ข้อความภาษาไทย" />
            </div>
            <div>
              <Label htmlFor="translation-en">English</Label>
              <Input id="translation-en" placeholder="English text" />
            </div>
            <div>
              <Label htmlFor="translation-zh">中文</Label>
              <Input id="translation-zh" placeholder="中文文本" />
            </div>
            <div>
              <Label htmlFor="translation-ja">日本語</Label>
              <Input id="translation-ja" placeholder="日本語のテキスト" />
            </div>
          </div>
          <div className="flex space-x-2">
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              เพิ่มข้อความ
            </Button>
            <Button variant="outline" className="bg-transparent">
              ยกเลิก
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  // Language Settings
  const LanguageSettings = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-bold">ตั้งค่าภาษา</h3>
        <p className="text-gray-600">จัดการการตั้งค่าภาษาและการแสดงผล</p>
      </div>

      <Tabs defaultValue="general" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="general">ทั่วไป</TabsTrigger>
          <TabsTrigger value="detection">ตรวจจับภาษา</TabsTrigger>
          <TabsTrigger value="fallback">ภาษาสำรอง</TabsTrigger>
          <TabsTrigger value="seo">SEO</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>การตั้งค่าทั่วไป</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="default-language">ภาษาเริ่มต้น</Label>
                <Select defaultValue="th">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {mockLanguages.map((lang) => (
                      <SelectItem key={lang.code} value={lang.code}>
                        {lang.flag} {lang.nativeName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="auto-detect" defaultChecked />
                <Label htmlFor="auto-detect">ตรวจจับภาษาอัตโนมัติ</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="remember-choice" defaultChecked />
                <Label htmlFor="remember-choice">จำการเลือกภาษาของผู้ใช้</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="show-language-switcher" defaultChecked />
                <Label htmlFor="show-language-switcher">แสดงปุ่มเปลี่ยนภาษา</Label>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="detection" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>การตรวจจับภาษา</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Switch id="browser-language" defaultChecked />
                <Label htmlFor="browser-language">ใช้ภาษาจากเบราว์เซอร์</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="ip-location" />
                <Label htmlFor="ip-location">ตรวจจับจากตำแหน่ง IP</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="subdomain-detection" />
                <Label htmlFor="subdomain-detection">ใช้ Subdomain สำหรับแต่ละภาษา</Label>
              </div>
              <div>
                <Label htmlFor="detection-priority">ลำดับความสำคัญ</Label>
                <div className="space-y-2 mt-2">
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="text-sm">1. URL Parameter (?lang=th)</span>
                    <Button size="sm" variant="outline">
                      <Edit className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="text-sm">2. Cookie</span>
                    <Button size="sm" variant="outline">
                      <Edit className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="text-sm">3. Browser Language</span>
                    <Button size="sm" variant="outline">
                      <Edit className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="fallback" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>ภาษาสำรอง</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="fallback-language">ภาษาสำรองหลัก</Label>
                <Select defaultValue="en">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {mockLanguages.map((lang) => (
                      <SelectItem key={lang.code} value={lang.code}>
                        {lang.flag} {lang.nativeName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="fallback-secondary">ภาษาสำรองรอง</Label>
                <Select defaultValue="th">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {mockLanguages.map((lang) => (
                      <SelectItem key={lang.code} value={lang.code}>
                        {lang.flag} {lang.nativeName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="show-missing-keys" />
                <Label htmlFor="show-missing-keys">แสดง Key ที่ขาดหายไป</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="log-missing-translations" defaultChecked />
                <Label htmlFor="log-missing-translations">บันทึกการแปลที่ขาดหายไป</Label>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="seo" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>การตั้งค่า SEO</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Switch id="hreflang-tags" defaultChecked />
                <Label htmlFor="hreflang-tags">สร้าง hreflang tags อัตโนมัติ</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="language-sitemap" defaultChecked />
                <Label htmlFor="language-sitemap">สร้าง sitemap แยกตามภาษา</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="canonical-urls" defaultChecked />
                <Label htmlFor="canonical-urls">ใช้ canonical URLs</Label>
              </div>
              <div>
                <Label htmlFor="url-structure">โครงสร้าง URL</Label>
                <Select defaultValue="path">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="path">Path (/th/, /en/)</SelectItem>
                    <SelectItem value="subdomain">Subdomain (th.site.com)</SelectItem>
                    <SelectItem value="domain">Domain (.co.th, .com)</SelectItem>
                    <SelectItem value="parameter">Parameter (?lang=th)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center">
                <Globe className="h-8 w-8 mr-3 text-blue-600" />
                Multi-Language Management
              </h1>
              <p className="text-gray-600 mt-2">จัดการภาษาและการแปลแบบครบครัน</p>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline">
                <RefreshCw className="h-4 w-4 mr-2" />
                ซิงค์การแปล
              </Button>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                ส่งออกทั้งหมด
              </Button>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                เพิ่มภาษาใหม่
              </Button>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="overview" className="flex items-center space-x-2">
              <BarChart3 className="h-4 w-4" />
              <span>ภาพรวม</span>
            </TabsTrigger>
            <TabsTrigger value="translations" className="flex items-center space-x-2">
              <Languages className="h-4 w-4" />
              <span>จัดการการแปล</span>
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center space-x-2">
              <Settings className="h-4 w-4" />
              <span>ตั้งค่า</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <LanguageOverview />
          </TabsContent>

          <TabsContent value="translations">
            <TranslationManagement />
          </TabsContent>

          <TabsContent value="settings">
            <LanguageSettings />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
