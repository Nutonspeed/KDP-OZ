"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import {
  Building2,
  Users,
  Plus,
  Edit,
  Trash2,
  Eye,
  Globe,
  Database,
  Shield,
  BarChart3,
  Package,
  ShoppingCart,
} from "lucide-react"

// Mock tenant data
const mockTenants = [
  {
    id: 1,
    name: "KDP Main Store",
    domain: "kdp-main.com",
    subdomain: "main",
    status: "active",
    plan: "enterprise",
    users: 45,
    products: 1250,
    orders: 2847,
    revenue: 485000,
    createdAt: "2023-01-15",
    settings: {
      customBranding: true,
      multiLanguage: true,
      advancedAnalytics: true,
      apiAccess: true,
    },
  },
  {
    id: 2,
    name: "KDP Branch Bangkok",
    domain: "kdp-bangkok.com",
    subdomain: "bangkok",
    status: "active",
    plan: "professional",
    users: 28,
    products: 850,
    orders: 1923,
    revenue: 325000,
    createdAt: "2023-03-20",
    settings: {
      customBranding: true,
      multiLanguage: false,
      advancedAnalytics: true,
      apiAccess: false,
    },
  },
  {
    id: 3,
    name: "KDP Branch Chiang Mai",
    domain: "kdp-chiangmai.com",
    subdomain: "chiangmai",
    status: "active",
    plan: "standard",
    users: 15,
    products: 450,
    orders: 1156,
    revenue: 185000,
    createdAt: "2023-06-10",
    settings: {
      customBranding: false,
      multiLanguage: false,
      advancedAnalytics: false,
      apiAccess: false,
    },
  },
  {
    id: 4,
    name: "KDP Wholesale",
    domain: "kdp-wholesale.com",
    subdomain: "wholesale",
    status: "suspended",
    plan: "enterprise",
    users: 12,
    products: 2100,
    orders: 856,
    revenue: 125000,
    createdAt: "2023-08-05",
    settings: {
      customBranding: true,
      multiLanguage: true,
      advancedAnalytics: true,
      apiAccess: true,
    },
  },
]

const mockPlans = [
  {
    name: "standard",
    displayName: "Standard",
    price: 2900,
    features: ["Up to 500 products", "Basic analytics", "Email support", "5 users"],
    limits: { users: 5, products: 500, storage: "10GB" },
  },
  {
    name: "professional",
    displayName: "Professional",
    price: 5900,
    features: ["Up to 2000 products", "Advanced analytics", "Priority support", "25 users", "Custom branding"],
    limits: { users: 25, products: 2000, storage: "50GB" },
  },
  {
    name: "enterprise",
    displayName: "Enterprise",
    price: 12900,
    features: [
      "Unlimited products",
      "Full analytics suite",
      "24/7 support",
      "Unlimited users",
      "API access",
      "Multi-language",
    ],
    limits: { users: "unlimited", products: "unlimited", storage: "500GB" },
  },
]

export default function MultiTenantManagement() {
  const [activeTab, setActiveTab] = useState("tenants")
  const [selectedTenant, setSelectedTenant] = useState<(typeof mockTenants)[0] | null>(null)
  const [isCreating, setIsCreating] = useState(false)

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "text-green-600 bg-green-100"
      case "suspended":
        return "text-red-600 bg-red-100"
      case "pending":
        return "text-yellow-600 bg-yellow-100"
      default:
        return "text-gray-600 bg-gray-100"
    }
  }

  const getPlanColor = (plan: string) => {
    switch (plan) {
      case "enterprise":
        return "text-purple-600 bg-purple-100"
      case "professional":
        return "text-blue-600 bg-blue-100"
      case "standard":
        return "text-green-600 bg-green-100"
      default:
        return "text-gray-600 bg-gray-100"
    }
  }

  // Tenant List View
  const TenantList = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-bold">Tenant Management</h3>
          <p className="text-gray-600">จัดการร้านค้าและสาขาทั้งหมด</p>
        </div>
        <Button onClick={() => setIsCreating(true)}>
          <Plus className="h-4 w-4 mr-2" />
          เพิ่ม Tenant ใหม่
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {mockTenants.map((tenant) => (
          <Card key={tenant.id} className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Building2 className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold">{tenant.name}</h3>
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      <span>{tenant.domain}</span>
                      <span>•</span>
                      <span>{tenant.subdomain}.kdp-system.com</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="text-right">
                    <div className="flex items-center space-x-2 mb-1">
                      <Badge className={getStatusColor(tenant.status)}>{tenant.status}</Badge>
                      <Badge className={getPlanColor(tenant.plan)}>{tenant.plan}</Badge>
                    </div>
                    <p className="text-sm text-gray-600">Created: {new Date(tenant.createdAt).toLocaleDateString()}</p>
                  </div>

                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline" onClick={() => setSelectedTenant(tenant)}>
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline">
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline" className="text-red-600 bg-transparent">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-4 gap-4 mt-6 pt-6 border-t">
                <div className="text-center">
                  <div className="flex items-center justify-center mb-2">
                    <Users className="h-5 w-5 text-blue-500" />
                  </div>
                  <p className="text-2xl font-bold">{tenant.users}</p>
                  <p className="text-sm text-gray-600">Users</p>
                </div>
                <div className="text-center">
                  <div className="flex items-center justify-center mb-2">
                    <Package className="h-5 w-5 text-green-500" />
                  </div>
                  <p className="text-2xl font-bold">{tenant.products.toLocaleString()}</p>
                  <p className="text-sm text-gray-600">Products</p>
                </div>
                <div className="text-center">
                  <div className="flex items-center justify-center mb-2">
                    <ShoppingCart className="h-5 w-5 text-purple-500" />
                  </div>
                  <p className="text-2xl font-bold">{tenant.orders.toLocaleString()}</p>
                  <p className="text-sm text-gray-600">Orders</p>
                </div>
                <div className="text-center">
                  <div className="flex items-center justify-center mb-2">
                    <BarChart3 className="h-5 w-5 text-orange-500" />
                  </div>
                  <p className="text-2xl font-bold">฿{(tenant.revenue / 1000).toFixed(0)}K</p>
                  <p className="text-sm text-gray-600">Revenue</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )

  // Tenant Details View
  const TenantDetails = () => {
    if (!selectedTenant) return null

    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button variant="outline" onClick={() => setSelectedTenant(null)}>
              ← Back
            </Button>
            <div>
              <h3 className="text-xl font-bold">{selectedTenant.name}</h3>
              <p className="text-gray-600">{selectedTenant.domain}</p>
            </div>
          </div>
          <div className="flex space-x-2">
            <Button variant="outline">
              <Edit className="h-4 w-4 mr-2" />
              Edit
            </Button>
            <Button variant="outline">
              <Globe className="h-4 w-4 mr-2" />
              Visit Site
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Basic Info */}
          <Card>
            <CardHeader>
              <CardTitle>Basic Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Tenant Name</Label>
                <Input value={selectedTenant.name} readOnly />
              </div>
              <div>
                <Label>Domain</Label>
                <Input value={selectedTenant.domain} readOnly />
              </div>
              <div>
                <Label>Subdomain</Label>
                <Input value={`${selectedTenant.subdomain}.kdp-system.com`} readOnly />
              </div>
              <div>
                <Label>Status</Label>
                <Select value={selectedTenant.status}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="suspended">Suspended</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Plan</Label>
                <Select value={selectedTenant.plan}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="standard">Standard</SelectItem>
                    <SelectItem value="professional">Professional</SelectItem>
                    <SelectItem value="enterprise">Enterprise</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Settings */}
          <Card>
            <CardHeader>
              <CardTitle>Features & Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Custom Branding</Label>
                  <p className="text-sm text-gray-600">Allow custom logo and colors</p>
                </div>
                <Switch checked={selectedTenant.settings.customBranding} />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label>Multi-Language</Label>
                  <p className="text-sm text-gray-600">Enable multiple languages</p>
                </div>
                <Switch checked={selectedTenant.settings.multiLanguage} />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label>Advanced Analytics</Label>
                  <p className="text-sm text-gray-600">Access to detailed reports</p>
                </div>
                <Switch checked={selectedTenant.settings.advancedAnalytics} />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label>API Access</Label>
                  <p className="text-sm text-gray-600">REST API integration</p>
                </div>
                <Switch checked={selectedTenant.settings.apiAccess} />
              </div>
            </CardContent>
          </Card>

          {/* Statistics */}
          <Card>
            <CardHeader>
              <CardTitle>Statistics</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <Users className="h-6 w-6 text-blue-600 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-blue-600">{selectedTenant.users}</p>
                  <p className="text-sm text-gray-600">Active Users</p>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <Package className="h-6 w-6 text-green-600 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-green-600">{selectedTenant.products.toLocaleString()}</p>
                  <p className="text-sm text-gray-600">Products</p>
                </div>
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <ShoppingCart className="h-6 w-6 text-purple-600 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-purple-600">{selectedTenant.orders.toLocaleString()}</p>
                  <p className="text-sm text-gray-600">Total Orders</p>
                </div>
                <div className="text-center p-4 bg-orange-50 rounded-lg">
                  <BarChart3 className="h-6 w-6 text-orange-600 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-orange-600">฿{(selectedTenant.revenue / 1000).toFixed(0)}K</p>
                  <p className="text-sm text-gray-600">Revenue</p>
                </div>
              </div>

              <div className="pt-4 border-t">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Storage Usage</span>
                  <span className="text-sm text-gray-600">65%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-blue-600 h-2 rounded-full" style={{ width: "65%" }}></div>
                </div>
                <p className="text-xs text-gray-500 mt-1">325GB / 500GB used</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  // Plans Management
  const PlansManagement = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-bold">Subscription Plans</h3>
          <p className="text-gray-600">จัดการแพ็คเกจและราคา</p>
        </div>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          เพิ่มแพ็คเกจใหม่
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {mockPlans.map((plan) => (
          <Card key={plan.name} className="relative">
            {plan.name === "professional" && (
              <Badge className="absolute -top-2 left-1/2 transform -translate-x-1/2 bg-blue-600 text-white">
                Most Popular
              </Badge>
            )}
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>{plan.displayName}</span>
                <div className="text-right">
                  <p className="text-2xl font-bold">฿{plan.price.toLocaleString()}</p>
                  <p className="text-sm text-gray-600">/month</p>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                {plan.features.map((feature, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-sm">{feature}</span>
                  </div>
                ))}
              </div>

              <div className="pt-4 border-t">
                <h4 className="font-medium mb-2">Limits</h4>
                <div className="space-y-1 text-sm text-gray-600">
                  <p>Users: {plan.limits.users}</p>
                  <p>Products: {plan.limits.products}</p>
                  <p>Storage: {plan.limits.storage}</p>
                </div>
              </div>

              <Button className="w-full" variant={plan.name === "professional" ? "default" : "outline"}>
                {plan.name === "professional" ? "Recommended" : "Select Plan"}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )

  // Create New Tenant Form
  const CreateTenantForm = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xl font-bold">Create New Tenant</h3>
          <p className="text-gray-600">เพิ่มร้านค้าหรือสาขาใหม่</p>
        </div>
        <Button variant="outline" onClick={() => setIsCreating(false)}>
          Cancel
        </Button>
      </div>

      <Card>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="tenant-name">Tenant Name *</Label>
                <Input id="tenant-name" placeholder="Enter tenant name" />
              </div>
              <div>
                <Label htmlFor="domain">Custom Domain</Label>
                <Input id="domain" placeholder="example.com" />
              </div>
              <div>
                <Label htmlFor="subdomain">Subdomain *</Label>
                <div className="flex">
                  <Input id="subdomain" placeholder="subdomain" />
                  <span className="flex items-center px-3 bg-gray-100 border border-l-0 rounded-r-md text-sm text-gray-600">
                    .kdp-system.com
                  </span>
                </div>
              </div>
              <div>
                <Label htmlFor="plan">Subscription Plan *</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a plan" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="standard">Standard - ฿2,900/month</SelectItem>
                    <SelectItem value="professional">Professional - ฿5,900/month</SelectItem>
                    <SelectItem value="enterprise">Enterprise - ฿12,900/month</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="admin-email">Admin Email *</Label>
                <Input id="admin-email" type="email" placeholder="admin@example.com" />
              </div>
              <div>
                <Label htmlFor="admin-name">Admin Name *</Label>
                <Input id="admin-name" placeholder="Administrator Name" />
              </div>
              <div>
                <Label htmlFor="phone">Phone Number</Label>
                <Input id="phone" placeholder="+66 XX XXX XXXX" />
              </div>
              <div>
                <Label htmlFor="company">Company/Organization</Label>
                <Input id="company" placeholder="Company Name" />
              </div>
            </div>
          </div>

          <div className="mt-6 pt-6 border-t">
            <h4 className="font-medium mb-4">Initial Features</h4>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Custom Branding</Label>
                  <p className="text-sm text-gray-600">Allow custom logo and colors</p>
                </div>
                <Switch />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label>Multi-Language</Label>
                  <p className="text-sm text-gray-600">Enable multiple languages</p>
                </div>
                <Switch />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label>Advanced Analytics</Label>
                  <p className="text-sm text-gray-600">Access to detailed reports</p>
                </div>
                <Switch />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label>API Access</Label>
                  <p className="text-sm text-gray-600">REST API integration</p>
                </div>
                <Switch />
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-2 mt-6">
            <Button variant="outline" onClick={() => setIsCreating(false)}>
              Cancel
            </Button>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Create Tenant
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center">
                <Building2 className="h-8 w-8 mr-3 text-blue-600" />
                Multi-Tenant Management
              </h1>
              <p className="text-gray-600 mt-2">จัดการร้านค้าและสาขาหลายแห่งในระบบเดียว</p>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline">
                <Database className="h-4 w-4 mr-2" />
                Database Status
              </Button>
              <Button variant="outline">
                <Shield className="h-4 w-4 mr-2" />
                Security Settings
              </Button>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        {!selectedTenant && !isCreating && (
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-8">
              <TabsTrigger value="tenants">Tenants</TabsTrigger>
              <TabsTrigger value="plans">Plans</TabsTrigger>
            </TabsList>

            <TabsContent value="tenants">
              <TenantList />
            </TabsContent>

            <TabsContent value="plans">
              <PlansManagement />
            </TabsContent>
          </Tabs>
        )}

        {/* Conditional Views */}
        {selectedTenant && <TenantDetails />}
        {isCreating && <CreateTenantForm />}
      </div>
    </div>
  )
}
