"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import {
  Brain,
  TrendingUp,
  Target,
  BarChart3,
  Lightbulb,
  Zap,
  Eye,
  Settings,
  Play,
  Pause,
  RefreshCw,
  Download,
  Upload,
  CheckCircle,
  Clock,
  ThumbsUp,
  ThumbsDown,
  Filter,
  Search,
} from "lucide-react"

// Mock AI Analytics data
const mockAIInsights = [
  {
    id: 1,
    type: "sales_prediction",
    title: "การคาดการณ์ยอดขาย",
    description: "ยอดขายเดือนหน้าคาดว่าจะเพิ่มขึ้น 15.2% จากเดือนนี้ โดยเฉพาะสินค้า LB Series",
    confidence: 87,
    impact: "high",
    recommendation: "เพิ่มสต็อกสินค้า LB Series และเตรียมแคมเปญการตลาด",
    createdAt: "2024-01-15 14:30",
    status: "active",
  },
  {
    id: 2,
    type: "customer_behavior",
    title: "พฤติกรรมลูกค้า",
    description: "ลูกค้าที่ซื้อ T-75G มักจะซื้อ BC-75G ร่วมด้วย 68% ของเวลา",
    confidence: 92,
    impact: "medium",
    recommendation: "สร้างแพ็คเกจขายคู่ T-75G + BC-75G เพื่อเพิ่มยอดขาย",
    createdAt: "2024-01-15 13:45",
    status: "active",
  },
  {
    id: 3,
    type: "inventory_optimization",
    title: "การจัดการสต็อก",
    description: "สินค้า LB-100G มีแนวโน้มขายช้าลง 23% ในช่วง 2 สัปดาห์ที่ผ่านมา",
    confidence: 78,
    impact: "medium",
    recommendation: "ลดการสั่งซื้อ LB-100G และเพิ่มโปรโมชั่นเพื่อขายสต็อกที่มี",
    createdAt: "2024-01-15 12:20",
    status: "active",
  },
  {
    id: 4,
    type: "price_optimization",
    title: "การปรับราคา",
    description: "การลดราคา T-Series 5% จะเพิ่มยอดขาย 28% โดยไม่กระทบกำไรมาก",
    confidence: 85,
    impact: "high",
    recommendation: "ทดลองลดราคา T-Series 5% เป็นเวลา 1 เดือน",
    createdAt: "2024-01-15 11:15",
    status: "pending",
  },
]

const mockAIModels = [
  {
    id: 1,
    name: "Sales Forecasting Model",
    type: "regression",
    accuracy: 87.5,
    status: "active",
    lastTrained: "2024-01-10",
    dataPoints: 15420,
    features: ["historical_sales", "seasonality", "promotions", "inventory"],
    performance: {
      mae: 1250,
      rmse: 1890,
      r2: 0.875,
    },
  },
  {
    id: 2,
    name: "Customer Segmentation Model",
    type: "clustering",
    accuracy: 92.3,
    status: "active",
    lastTrained: "2024-01-08",
    dataPoints: 8950,
    features: ["purchase_history", "frequency", "monetary_value", "recency"],
    performance: {
      silhouette: 0.78,
      clusters: 5,
      cohesion: 0.85,
    },
  },
  {
    id: 3,
    name: "Demand Prediction Model",
    type: "time_series",
    accuracy: 83.7,
    status: "training",
    lastTrained: "2024-01-12",
    dataPoints: 12340,
    features: ["seasonal_trends", "external_factors", "promotions", "stock_levels"],
    performance: {
      mape: 12.3,
      forecast_horizon: 30,
      trend_accuracy: 0.84,
    },
  },
  {
    id: 4,
    name: "Price Optimization Model",
    type: "reinforcement",
    accuracy: 79.2,
    status: "inactive",
    lastTrained: "2024-01-05",
    dataPoints: 6780,
    features: ["competitor_prices", "demand_elasticity", "cost_structure", "market_conditions"],
    performance: {
      profit_improvement: 15.2,
      price_sensitivity: 0.72,
      market_share: 0.68,
    },
  },
]

const mockAIRecommendations = [
  {
    id: 1,
    title: "เพิ่มสต็อก LB-75G",
    description: "AI คาดการณ์ว่าความต้องการ LB-75G จะเพิ่มขึ้น 35% ในเดือนหน้า",
    priority: "high",
    impact: "revenue_increase",
    estimatedValue: 45000,
    confidence: 89,
    category: "inventory",
    dueDate: "2024-01-20",
    status: "pending",
  },
  {
    id: 2,
    title: "ปรับราคา T-100G",
    description: "ลดราคา T-100G 8% จะเพิ่มยอดขาย 42% โดยกำไรรวมเพิ่มขึ้น 12%",
    priority: "high",
    impact: "profit_optimization",
    estimatedValue: 28000,
    confidence: 85,
    category: "pricing",
    dueDate: "2024-01-18",
    status: "approved",
  },
  {
    id: 3,
    title: "แคมเปญการตลาดสำหรับ BC Series",
    description: "ลูกค้าที่ซื้อ BC Series มีแนวโน้มซื้อซ้ำสูง ควรทำแคมเปญเพื่อดึงลูกค้าใหม่",
    priority: "medium",
    impact: "customer_acquisition",
    estimatedValue: 32000,
    confidence: 76,
    category: "marketing",
    dueDate: "2024-01-25",
    status: "in_progress",
  },
  {
    id: 4,
    title: "ปรับปรุงหน้าสินค้า T-75G",
    description: "การเพิ่มรูปภาพและคำอธิบายจะเพิ่มอัตราการแปลง 23%",
    priority: "low",
    impact: "conversion_rate",
    estimatedValue: 15000,
    confidence: 72,
    category: "website",
    dueDate: "2024-01-30",
    status: "pending",
  },
]

export default function AIAnalytics() {
  const [activeTab, setActiveTab] = useState("insights")
  const [selectedModel, setSelectedModel] = useState(1)
  const [searchTerm, setSearchTerm] = useState("")

  // AI Insights Overview
  const AIInsights = () => (
    <div className="space-y-6">
      {/* AI Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">AI Insights</p>
                <p className="text-2xl font-bold">24</p>
                <p className="text-xs text-green-600 flex items-center mt-1">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  +6 ใหม่วันนี้
                </p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <Brain className="h-6 w-6 text-blue-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-400 to-blue-600"></div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">ความแม่นยำเฉลี่ย</p>
                <p className="text-2xl font-bold">85.7%</p>
                <p className="text-xs text-green-600">+2.3% จากเดือนที่แล้ว</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <Target className="h-6 w-6 text-green-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-green-400 to-green-600"></div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">คำแนะนำที่ใช้</p>
                <p className="text-2xl font-bold">18</p>
                <p className="text-xs text-purple-600">จาก 24 คำแนะนำ</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                <Lightbulb className="h-6 w-6 text-purple-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-purple-400 to-purple-600"></div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">ผลกระทบทางการเงิน</p>
                <p className="text-2xl font-bold">฿156K</p>
                <p className="text-xs text-orange-600">เพิ่มขึ้นเดือนนี้</p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                <TrendingUp className="h-6 w-6 text-orange-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-orange-400 to-orange-600"></div>
          </CardContent>
        </Card>
      </div>

      {/* AI Insights List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>AI Insights ล่าสุด</span>
            <Button variant="outline" size="sm">
              <RefreshCw className="h-4 w-4 mr-2" />
              รีเฟรช
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {mockAIInsights.map((insight) => (
              <Card key={insight.id} className="border-l-4 border-l-blue-500">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <Badge variant="outline">
                          {insight.type === "sales_prediction" && "การคาดการณ์ยอดขาย"}
                          {insight.type === "customer_behavior" && "พฤติกรรมลูกค้า"}
                          {insight.type === "inventory_optimization" && "การจัดการสต็อก"}
                          {insight.type === "price_optimization" && "การปรับราคา"}
                        </Badge>
                        <Badge
                          variant={
                            insight.impact === "high"
                              ? "destructive"
                              : insight.impact === "medium"
                                ? "secondary"
                                : "outline"
                          }
                        >
                          {insight.impact === "high" && "ผลกระทบสูง"}
                          {insight.impact === "medium" && "ผลกระทบปานกลาง"}
                          {insight.impact === "low" && "ผลกระทบต่ำ"}
                        </Badge>
                      </div>
                      <h4 className="font-medium text-lg mb-2">{insight.title}</h4>
                      <p className="text-gray-600 mb-3">{insight.description}</p>
                      <div className="bg-blue-50 p-3 rounded-lg mb-3">
                        <p className="text-sm font-medium text-blue-800">💡 คำแนะนำ:</p>
                        <p className="text-sm text-blue-700">{insight.recommendation}</p>
                      </div>
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <span>ความมั่นใจ: {insight.confidence}%</span>
                        <span>•</span>
                        <span>{insight.createdAt}</span>
                      </div>
                    </div>
                    <div className="flex flex-col items-end space-y-2">
                      <div className="flex items-center space-x-1">
                        <div className="w-16 h-2 bg-gray-200 rounded-full">
                          <div
                            className="h-2 bg-green-500 rounded-full"
                            style={{ width: `${insight.confidence}%` }}
                          ></div>
                        </div>
                        <span className="text-sm font-medium">{insight.confidence}%</span>
                      </div>
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <ThumbsUp className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <ThumbsDown className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Performance Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>ประสิทธิภาพ AI Models</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80 bg-gradient-to-br from-blue-50 to-indigo-100 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <BarChart3 className="h-16 w-16 text-blue-500 mx-auto mb-4" />
                <p className="text-gray-600">กราฟประสิทธิภาพ AI Models</p>
                <p className="text-sm text-gray-500">แสดงความแม่นยำและการปรับปรุง</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>ผลกระทบทางธุรกิจ</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80 bg-gradient-to-br from-green-50 to-teal-100 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <TrendingUp className="h-16 w-16 text-green-500 mx-auto mb-4" />
                <p className="text-gray-600">ผลกระทบจาก AI Recommendations</p>
                <p className="text-sm text-gray-500">รายได้และกำไรที่เพิ่มขึ้น</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )

  // AI Models Management
  const AIModels = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-bold">จัดการ AI Models</h3>
          <p className="text-gray-600">ติดตามและจัดการโมเดล AI ทั้งหมด</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <Upload className="h-4 w-4 mr-2" />
            อัพโหลดโมเดล
          </Button>
          <Button>
            <Play className="h-4 w-4 mr-2" />
            เทรนโมเดลใหม่
          </Button>
        </div>
      </div>

      {/* Models Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">โมเดลทั้งหมด</p>
                <p className="text-2xl font-bold text-blue-600">12</p>
              </div>
              <Brain className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">ใช้งานอยู่</p>
                <p className="text-2xl font-bold text-green-600">8</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">กำลังเทรน</p>
                <p className="text-2xl font-bold text-orange-600">2</p>
              </div>
              <Clock className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">ความแม่นยำเฉลี่ย</p>
                <p className="text-2xl font-bold text-purple-600">85.7%</p>
              </div>
              <Target className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Models Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left p-4 font-medium">โมเดล</th>
                  <th className="text-left p-4 font-medium">ประเภท</th>
                  <th className="text-left p-4 font-medium">ความแม่นยำ</th>
                  <th className="text-left p-4 font-medium">สถานะ</th>
                  <th className="text-left p-4 font-medium">เทรนล่าสุด</th>
                  <th className="text-left p-4 font-medium">ข้อมูล</th>
                  <th className="text-left p-4 font-medium">จัดการ</th>
                </tr>
              </thead>
              <tbody>
                {mockAIModels.map((model) => (
                  <tr key={model.id} className="border-t hover:bg-gray-50">
                    <td className="p-4">
                      <div>
                        <p className="font-medium">{model.name}</p>
                        <p className="text-sm text-gray-600">
                          Features: {model.features.slice(0, 2).join(", ")}
                          {model.features.length > 2 && ` +${model.features.length - 2}`}
                        </p>
                      </div>
                    </td>
                    <td className="p-4">
                      <Badge variant="outline">
                        {model.type === "regression" && "Regression"}
                        {model.type === "clustering" && "Clustering"}
                        {model.type === "time_series" && "Time Series"}
                        {model.type === "reinforcement" && "Reinforcement"}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-2">
                        <div className="w-16 h-2 bg-gray-200 rounded-full">
                          <div
                            className={`h-2 rounded-full ${
                              model.accuracy >= 90
                                ? "bg-green-500"
                                : model.accuracy >= 80
                                  ? "bg-yellow-500"
                                  : "bg-red-500"
                            }`}
                            style={{ width: `${model.accuracy}%` }}
                          ></div>
                        </div>
                        <span className="text-sm font-medium">{model.accuracy}%</span>
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-2">
                        <div
                          className={`w-2 h-2 rounded-full ${
                            model.status === "active"
                              ? "bg-green-500"
                              : model.status === "training"
                                ? "bg-yellow-500 animate-pulse"
                                : "bg-gray-400"
                          }`}
                        />
                        <Badge
                          variant={
                            model.status === "active"
                              ? "default"
                              : model.status === "training"
                                ? "secondary"
                                : "outline"
                          }
                        >
                          {model.status === "active" && "ใช้งาน"}
                          {model.status === "training" && "กำลังเทรน"}
                          {model.status === "inactive" && "ไม่ใช้งาน"}
                        </Badge>
                      </div>
                    </td>
                    <td className="p-4">
                      <p className="text-sm">{model.lastTrained}</p>
                    </td>
                    <td className="p-4">
                      <p className="text-sm font-medium">{model.dataPoints.toLocaleString()}</p>
                      <p className="text-xs text-gray-600">data points</p>
                    </td>
                    <td className="p-4">
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Settings className="h-4 w-4" />
                        </Button>
                        {model.status === "active" ? (
                          <Button size="sm" variant="outline">
                            <Pause className="h-4 w-4" />
                          </Button>
                        ) : (
                          <Button size="sm" variant="outline">
                            <Play className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Model Details */}
      <Card>
        <CardHeader>
          <CardTitle>รายละเอียดโมเดล: {mockAIModels.find((m) => m.id === selectedModel)?.name}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium mb-4">ข้อมูลโมเดล</h4>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">ประเภท:</span>
                  <span className="font-medium">{mockAIModels.find((m) => m.id === selectedModel)?.type}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">ความแม่นยำ:</span>
                  <span className="font-medium">{mockAIModels.find((m) => m.id === selectedModel)?.accuracy}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">ข้อมูลที่ใช้:</span>
                  <span className="font-medium">
                    {mockAIModels.find((m) => m.id === selectedModel)?.dataPoints.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">เทรนล่าสุด:</span>
                  <span className="font-medium">{mockAIModels.find((m) => m.id === selectedModel)?.lastTrained}</span>
                </div>
              </div>
            </div>
            <div>
              <h4 className="font-medium mb-4">Features ที่ใช้</h4>
              <div className="flex flex-wrap gap-2">
                {mockAIModels
                  .find((m) => m.id === selectedModel)
                  ?.features.map((feature) => (
                    <Badge key={feature} variant="outline">
                      {feature}
                    </Badge>
                  ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  // AI Recommendations
  const AIRecommendations = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-bold">คำแนะนำจาก AI</h3>
          <p className="text-gray-600">คำแนะนำที่ AI สร้างขึ้นเพื่อปรับปรุงธุรกิจ</p>
        </div>
        <div className="flex space-x-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="ค้นหาคำแนะนำ..."
              className="pl-10 w-64"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Select defaultValue="all">
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">ทั้งหมด</SelectItem>
              <SelectItem value="high">ความสำคัญสูง</SelectItem>
              <SelectItem value="pending">รอดำเนินการ</SelectItem>
              <SelectItem value="approved">อนุมัติแล้ว</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm">
            <Filter className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Recommendations Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">คำแนะนำทั้งหมด</p>
                <p className="text-2xl font-bold text-blue-600">24</p>
              </div>
              <Lightbulb className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">รอดำเนินการ</p>
                <p className="text-2xl font-bold text-orange-600">8</p>
              </div>
              <Clock className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">ดำเนินการแล้ว</p>
                <p className="text-2xl font-bold text-green-600">16</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">มูลค่าคาดการณ์</p>
                <p className="text-2xl font-bold text-purple-600">฿245K</p>
              </div>
              <TrendingUp className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recommendations List */}
      <div className="space-y-4">
        {mockAIRecommendations.map((recommendation) => (
          <Card key={recommendation.id} className="border-l-4 border-l-green-500">
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-3">
                    <Badge
                      variant={
                        recommendation.priority === "high"
                          ? "destructive"
                          : recommendation.priority === "medium"
                            ? "secondary"
                            : "outline"
                      }
                    >
                      {recommendation.priority === "high" && "ความสำคัญสูง"}
                      {recommendation.priority === "medium" && "ความสำคัญปานกลาง"}
                      {recommendation.priority === "low" && "ความสำคัญต่ำ"}
                    </Badge>
                    <Badge variant="outline">
                      {recommendation.category === "inventory" && "สต็อก"}
                      {recommendation.category === "pricing" && "ราคา"}
                      {recommendation.category === "marketing" && "การตลาด"}
                      {recommendation.category === "website" && "เว็บไซต์"}
                    </Badge>
                    <Badge
                      variant={
                        recommendation.status === "approved"
                          ? "default"
                          : recommendation.status === "in_progress"
                            ? "secondary"
                            : "outline"
                      }
                    >
                      {recommendation.status === "pending" && "รอดำเนินการ"}
                      {recommendation.status === "approved" && "อนุมัติแล้ว"}
                      {recommendation.status === "in_progress" && "กำลังดำเนินการ"}
                      {recommendation.status === "completed" && "เสร็จสิ้น"}
                    </Badge>
                  </div>
                  <h4 className="font-medium text-lg mb-2">{recommendation.title}</h4>
                  <p className="text-gray-600 mb-4">{recommendation.description}</p>
                  <div className="grid grid-cols-3 gap-4 mb-4">
                    <div>
                      <p className="text-sm text-gray-600">มูลค่าคาดการณ์</p>
                      <p className="font-medium text-green-600">฿{recommendation.estimatedValue.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">ความมั่นใจ</p>
                      <p className="font-medium">{recommendation.confidence}%</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">กำหนดเสร็จ</p>
                      <p className="font-medium">{recommendation.dueDate}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-32 h-2 bg-gray-200 rounded-full">
                      <div
                        className="h-2 bg-blue-500 rounded-full"
                        style={{ width: `${recommendation.confidence}%` }}
                      ></div>
                    </div>
                    <span className="text-sm text-gray-600">{recommendation.confidence}% confidence</span>
                  </div>
                </div>
                <div className="flex flex-col space-y-2">
                  <Button size="sm" variant="outline">
                    <Eye className="h-4 w-4 mr-2" />
                    ดูรายละเอียด
                  </Button>
                  {recommendation.status === "pending" && (
                    <Button size="sm">
                      <CheckCircle className="h-4 w-4 mr-2" />
                      อนุมัติ
                    </Button>
                  )}
                  <div className="flex space-x-1">
                    <Button size="sm" variant="outline" className="p-2 bg-transparent">
                      <ThumbsUp className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline" className="p-2 bg-transparent">
                      <ThumbsDown className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )

  // AI Settings
  const AISettings = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-bold">ตั้งค่า AI</h3>
        <p className="text-gray-600">จัดการการตั้งค่า AI และ Machine Learning</p>
      </div>

      <Tabs defaultValue="general" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="general">ทั่วไป</TabsTrigger>
          <TabsTrigger value="models">โมเดล</TabsTrigger>
          <TabsTrigger value="data">ข้อมูล</TabsTrigger>
          <TabsTrigger value="notifications">การแจ้งเตือน</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>การตั้งค่าทั่วไป</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="ai-enabled">เปิดใช้งาน AI</Label>
                  <p className="text-sm text-gray-600">เปิด/ปิดระบบ AI ทั้งหมด</p>
                </div>
                <input type="checkbox" id="ai-enabled" defaultChecked className="toggle" />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="auto-insights">สร้าง Insights อัตโนมัติ</Label>
                  <p className="text-sm text-gray-600">สร้าง AI Insights ทุกวันอัตโนมัติ</p>
                </div>
                <input type="checkbox" id="auto-insights" defaultChecked className="toggle" />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="auto-recommendations">คำแนะนำอัตโนมัติ</Label>
                  <p className="text-sm text-gray-600">สร้างคำแนะนำจาก AI อัตโนมัติ</p>
                </div>
                <input type="checkbox" id="auto-recommendations" defaultChecked className="toggle" />
              </div>
              <div>
                <Label htmlFor="confidence-threshold">เกณฑ์ความมั่นใจขั้นต่ำ</Label>
                <Input id="confidence-threshold" type="number" defaultValue="75" min="0" max="100" />
                <p className="text-sm text-gray-600 mt-1">แสดงเฉพาะ Insights ที่มีความมั่นใจมากกว่า %</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="models" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>การตั้งค่าโมเดล</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="retrain-frequency">ความถี่ในการเทรนใหม่</Label>
                <Select defaultValue="weekly">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="daily">ทุกวัน</SelectItem>
                    <SelectItem value="weekly">ทุกสัปดาห์</SelectItem>
                    <SelectItem value="monthly">ทุกเดือน</SelectItem>
                    <SelectItem value="manual">ด้วยตนเอง</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="data-retention">เก็บข้อมูลเทรนนิ่ง (วัน)</Label>
                <Input id="data-retention" type="number" defaultValue="365" />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="auto-deploy">Deploy โมเดลอัตโนมัติ</Label>
                  <p className="text-sm text-gray-600">Deploy โมเดลใหม่อัตโนมัติเมื่อผ่านเกณฑ์</p>
                </div>
                <input type="checkbox" id="auto-deploy" className="toggle" />
              </div>
              <div>
                <Label htmlFor="accuracy-threshold">เกณฑ์ความแม่นยำสำหรับ Deploy</Label>
                <Input id="accuracy-threshold" type="number" defaultValue="85" min="0" max="100" />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="data" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>การจัดการข้อมูล</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="data-collection">เก็บข้อมูลอัตโนมัติ</Label>
                  <p className="text-sm text-gray-600">เก็บข้อมูลพฤติกรรมผู้ใช้สำหรับ AI</p>
                </div>
                <input type="checkbox" id="data-collection" defaultChecked className="toggle" />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="data-anonymization">ทำให้ข้อมูลไม่ระบุตัวตน</Label>
                  <p className="text-sm text-gray-600">ลบข้อมูลส่วนตัวออกจากชุดข้อมูลเทรนนิ่ง</p>
                </div>
                <input type="checkbox" id="data-anonymization" defaultChecked className="toggle" />
              </div>
              <div>
                <Label htmlFor="data-sources">แหล่งข้อมูล</Label>
                <div className="space-y-2 mt-2">
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="sales-data" defaultChecked />
                    <Label htmlFor="sales-data">ข้อมูลการขาย</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="customer-data" defaultChecked />
                    <Label htmlFor="customer-data">ข้อมูลลูกค้า</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="inventory-data" defaultChecked />
                    <Label htmlFor="inventory-data">ข้อมูลสต็อก</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="web-analytics" />
                    <Label htmlFor="web-analytics">Web Analytics</Label>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>การแจ้งเตือน AI</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="insight-notifications">แจ้งเตือน Insights ใหม่</Label>
                  <p className="text-sm text-gray-600">แจ้งเตือนเมื่อมี AI Insights ใหม่</p>
                </div>
                <input type="checkbox" id="insight-notifications" defaultChecked className="toggle" />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="recommendation-notifications">แจ้งเตือนคำแนะนำ</Label>
                  <p className="text-sm text-gray-600">แจ้งเตือนเมื่อมีคำแนะนำใหม่จาก AI</p>
                </div>
                <input type="checkbox" id="recommendation-notifications" defaultChecked className="toggle" />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="model-notifications">แจ้งเตือนสถานะโมเดล</Label>
                  <p className="text-sm text-gray-600">แจ้งเตือนเมื่อโมเดลเทรนเสร็จหรือมีปัญหา</p>
                </div>
                <input type="checkbox" id="model-notifications" defaultChecked className="toggle" />
              </div>
              <div>
                <Label htmlFor="notification-email">อีเมลสำหรับการแจ้งเตือน</Label>
                <Input id="notification-email" type="email" defaultValue="admin@kdp.co.th" />
              </div>
              <div>
                <Label htmlFor="notification-frequency">ความถี่การแจ้งเตือน</Label>
                <Select defaultValue="immediate">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="immediate">ทันที</SelectItem>
                    <SelectItem value="hourly">ทุกชั่วโมง</SelectItem>
                    <SelectItem value="daily">ทุกวัน</SelectItem>
                    <SelectItem value="weekly">ทุกสัปดาห์</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center">
                <Brain className="h-8 w-8 mr-3 text-blue-600" />
                AI Analytics & Intelligence
              </h1>
              <p className="text-gray-600 mt-2">ระบบวิเคราะห์และปัญญาประดิษฐ์ขั้นสูง</p>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                ส่งออกรายงาน
              </Button>
              <Button variant="outline">
                <Settings className="h-4 w-4 mr-2" />
                ตั้งค่า AI
              </Button>
              <Button>
                <Zap className="h-4 w-4 mr-2" />
                เทรนโมเดลใหม่
              </Button>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="insights" className="flex items-center space-x-2">
              <Lightbulb className="h-4 w-4" />
              <span>AI Insights</span>
            </TabsTrigger>
            <TabsTrigger value="models" className="flex items-center space-x-2">
              <Brain className="h-4 w-4" />
              <span>AI Models</span>
            </TabsTrigger>
            <TabsTrigger value="recommendations" className="flex items-center space-x-2">
              <Target className="h-4 w-4" />
              <span>คำแนะนำ</span>
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center space-x-2">
              <Settings className="h-4 w-4" />
              <span>ตั้งค่า</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="insights">
            <AIInsights />
          </TabsContent>

          <TabsContent value="models">
            <AIModels />
          </TabsContent>

          <TabsContent value="recommendations">
            <AIRecommendations />
          </TabsContent>

          <TabsContent value="settings">
            <AISettings />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
