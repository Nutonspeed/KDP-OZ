"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Users,
  Crown,
  Heart,
  TrendingUp,
  DollarSign,
  AlertTriangle,
  UserX,
  Target,
  BarChart3,
  PieChart,
  Activity,
  Mail,
  MessageSquare,
  Gift,
  RefreshCw,
  Download,
  Settings,
  Plus,
} from "lucide-react"

// Mock customer segmentation data
const mockSegmentationData = {
  segments: [
    {
      id: "vip",
      name: "VIP Customers",
      description: "ลูกค้าระดับพรีเมียม ซื้อบ่อย มูลค่าสูง",
      count: 45,
      percentage: 12.5,
      avgOrderValue: 25000,
      frequency: 8.5,
      totalRevenue: 1125000,
      churnRisk: 5,
      icon: Crown,
      color: "text-yellow-600 bg-yellow-100",
      characteristics: ["ซื้อสินค้าราคาสูง", "ความถี่สูง", "ไม่ไวต่อราคา", "ซื้อหลายหมวดหมู่"],
      recommendations: ["Personal Account Manager", "Exclusive Offers", "Priority Support"],
    },
    {
      id: "loyal",
      name: "Loyal Customers",
      description: "ลูกค้าซื่อสัตย์ ซื้อสม่ำเสมอ",
      count: 89,
      percentage: 24.7,
      avgOrderValue: 15000,
      frequency: 5.2,
      totalRevenue: 1335000,
      churnRisk: 15,
      icon: Heart,
      color: "text-red-600 bg-red-100",
      characteristics: ["ซื้อสม่ำเสมอ", "ติดแบรนด์", "แนะนำเพื่อน", "รีวิวดี"],
      recommendations: ["Loyalty Program", "Referral Rewards", "Early Access"],
    },
    {
      id: "potential",
      name: "Potential Customers",
      description: "ลูกค้าที่มีศักยภาพ เพิ่งเริ่มซื้อ",
      count: 156,
      percentage: 43.3,
      avgOrderValue: 8500,
      frequency: 2.1,
      totalRevenue: 1326000,
      churnRisk: 35,
      icon: TrendingUp,
      color: "text-green-600 bg-green-100",
      characteristics: ["ลูกค้าใหม่", "ซื้อน้อย", "ทดลองซื้อ", "ศึกษาข้อมูล"],
      recommendations: ["Welcome Series", "Product Education", "Special Discounts"],
    },
    {
      id: "price_sensitive",
      name: "Price Sensitive",
      description: "ลูกค้าที่ไวต่อราคา มองหาดีล",
      count: 67,
      percentage: 18.6,
      avgOrderValue: 5500,
      frequency: 3.8,
      totalRevenue: 368500,
      churnRisk: 45,
      icon: DollarSign,
      color: "text-blue-600 bg-blue-100",
      characteristics: ["เปรียบเทียบราคา", "รอโปรโมชั่น", "ซื้อเมื่อลดราคา", "มูลค่าต่ำ"],
      recommendations: ["Price Alerts", "Bundle Offers", "Seasonal Sales"],
    },
    {
      id: "at_risk",
      name: "At Risk",
      description: "ลูกค้าเสี่ยงหยุดซื้อ ไม่ซื้อนาน",
      count: 34,
      percentage: 9.4,
      avgOrderValue: 12000,
      frequency: 1.2,
      totalRevenue: 408000,
      churnRisk: 75,
      icon: AlertTriangle,
      color: "text-orange-600 bg-orange-100",
      characteristics: ["ไม่ซื้อนาน", "ลดความถี่", "ไม่ตอบสนอง", "ใช้คู่แข่ง"],
      recommendations: ["Win-back Campaign", "Personal Outreach", "Special Offers"],
    },
    {
      id: "lost",
      name: "Lost Customers",
      description: "ลูกค้าที่หยุดซื้อแล้ว",
      count: 23,
      percentage: 6.4,
      avgOrderValue: 9500,
      frequency: 0.1,
      totalRevenue: 218500,
      churnRisk: 95,
      icon: UserX,
      color: "text-gray-600 bg-gray-100",
      characteristics: ["ไม่ซื้อ >6 เดือน", "ไม่ตอบสนอง", "ยกเลิกสมาชิก", "ร้องเรียน"],
      recommendations: ["Reactivation Campaign", "Survey Feedback", "Apology Offers"],
    },
  ],
  behaviorPatterns: [
    {
      name: "Seasonal Buyers",
      description: "ซื้อตามฤดูกาล",
      count: 89,
      pattern: "Q1, Q4 สูง",
      recommendation: "เตรียมสต็อกล่วงหน้า",
    },
    {
      name: "Bulk Purchasers",
      description: "ซื้อจำนวนมาก",
      count: 45,
      pattern: "สั่งซื้อ >100 ชิ้น",
      recommendation: "Volume Discounts",
    },
    {
      name: "Brand Loyalists",
      description: "ติดแบรนด์เฉพาะ",
      count: 67,
      pattern: "ซื้อแบรนด์เดียว",
      recommendation: "Brand Partnerships",
    },
    {
      name: "Price Hunters",
      description: "หาราคาดีที่สุด",
      count: 123,
      pattern: "ซื้อเมื่อลดราคา",
      recommendation: "Flash Sales",
    },
  ],
  churnPrediction: [
    {
      customerId: "CUST-001",
      customerName: "บริษัท ABC จำกัด",
      segment: "loyal",
      churnProbability: 85,
      daysInactive: 45,
      lastOrderValue: 15000,
      predictedChurnDate: "2024-02-15",
      riskFactors: ["ลดความถี่การสั่งซื้อ", "ไม่เปิดอีเมล", "ไม่ตอบสนองโปรโมชั่น"],
      recommendations: ["โทรติดตาม", "ส่วนลดพิเศษ", "เยี่ยมลูกค้า"],
    },
    {
      customerId: "CUST-002",
      customerName: "คุณสมชาย ใจดี",
      segment: "potential",
      churnProbability: 72,
      daysInactive: 30,
      lastOrderValue: 8500,
      predictedChurnDate: "2024-02-10",
      riskFactors: ["ลูกค้าใหม่", "ซื้อครั้งเดียว", "ไม่มีการติดต่อ"],
      recommendations: ["Welcome Call", "Product Tutorial", "First Purchase Discount"],
    },
  ],
  campaigns: [
    {
      id: 1,
      name: "VIP Exclusive Access",
      segment: "vip",
      type: "email",
      status: "active",
      sent: 45,
      opened: 42,
      clicked: 38,
      converted: 28,
      revenue: 420000,
      roi: 340,
    },
    {
      id: 2,
      name: "Win-back Special",
      segment: "at_risk",
      type: "sms",
      status: "completed",
      sent: 34,
      opened: 28,
      clicked: 15,
      converted: 8,
      revenue: 96000,
      roi: 180,
    },
    {
      id: 3,
      name: "New Customer Welcome",
      segment: "potential",
      type: "email",
      status: "active",
      sent: 156,
      opened: 124,
      clicked: 89,
      converted: 45,
      revenue: 382500,
      roi: 255,
    },
  ],
}

export default function CustomerSegmentationAI() {
  const [selectedSegment, setSelectedSegment] = useState("all")
  const [selectedTimeframe, setSelectedTimeframe] = useState("30")

  const getSegmentIcon = (IconComponent: any, color: string) => (
    <div className={`w-12 h-12 rounded-full flex items-center justify-center ${color}`}>
      <IconComponent className="h-6 w-6" />
    </div>
  )

  const getChurnRiskColor = (risk: number) => {
    if (risk >= 70) return "text-red-600 bg-red-100"
    if (risk >= 40) return "text-yellow-600 bg-yellow-100"
    return "text-green-600 bg-green-100"
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center">
                <Users className="h-8 w-8 mr-3 text-blue-600" />
                AI Customer Segmentation
              </h1>
              <p className="text-gray-600 mt-2">การแบ่งกลุ่มลูกค้าด้วย Machine Learning</p>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline">
                <RefreshCw className="h-4 w-4 mr-2" />
                Update Segments
              </Button>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Export Data
              </Button>
              <Button variant="outline">
                <Settings className="h-4 w-4 mr-2" />
                ML Settings
              </Button>
            </div>
          </div>
        </div>

        {/* Segment Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {mockSegmentationData.segments.map((segment) => (
            <Card key={segment.id} className="relative overflow-hidden hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  {getSegmentIcon(segment.icon, segment.color)}
                  <Badge variant="outline" className="text-xs">
                    {segment.percentage}% of total
                  </Badge>
                </div>
                <div className="space-y-2">
                  <h3 className="text-lg font-semibold">{segment.name}</h3>
                  <p className="text-sm text-gray-600">{segment.description}</p>
                  <div className="grid grid-cols-2 gap-4 mt-4">
                    <div>
                      <p className="text-xs text-gray-500">Customers</p>
                      <p className="text-lg font-bold">{segment.count}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">Avg Order</p>
                      <p className="text-lg font-bold">฿{segment.avgOrderValue.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">Frequency</p>
                      <p className="text-lg font-bold">{segment.frequency}/month</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">Churn Risk</p>
                      <p className="text-lg font-bold text-red-600">{segment.churnRisk}%</p>
                    </div>
                  </div>
                  <div className="mt-4">
                    <p className="text-sm font-medium text-green-600">
                      Total Revenue: ฿{segment.totalRevenue.toLocaleString()}
                    </p>
                  </div>
                </div>
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-400 to-purple-600"></div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="segments" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="segments">Segment Details</TabsTrigger>
            <TabsTrigger value="behavior">Behavior Patterns</TabsTrigger>
            <TabsTrigger value="churn">Churn Prediction</TabsTrigger>
            <TabsTrigger value="campaigns">Targeted Campaigns</TabsTrigger>
          </TabsList>

          <TabsContent value="segments" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <PieChart className="h-5 w-5 mr-2" />
                    Segment Distribution
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 bg-gradient-to-br from-blue-50 to-purple-100 rounded-lg flex items-center justify-center">
                    <div className="text-center">
                      <PieChart className="h-16 w-16 text-blue-500 mx-auto mb-4" />
                      <p className="text-gray-600">Customer Segment Distribution</p>
                      <p className="text-sm text-gray-500">แสดงสัดส่วนลูกค้าแต่ละกลุ่ม</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BarChart3 className="h-5 w-5 mr-2" />
                    Revenue by Segment
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {mockSegmentationData.segments.map((segment) => (
                      <div key={segment.id} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">{segment.name}</span>
                          <span className="text-sm font-bold">฿{segment.totalRevenue.toLocaleString()}</span>
                        </div>
                        <Progress value={(segment.totalRevenue / 4000000) * 100} className="h-2" />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Segment Characteristics */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {mockSegmentationData.segments.slice(0, 2).map((segment) => (
                <Card key={segment.id}>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <segment.icon className="h-5 w-5 mr-2" />
                      {segment.name}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-medium mb-2">Characteristics</h4>
                        <div className="flex flex-wrap gap-2">
                          {segment.characteristics.map((char, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {char}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <div>
                        <h4 className="font-medium mb-2">Recommendations</h4>
                        <div className="space-y-2">
                          {segment.recommendations.map((rec, index) => (
                            <div key={index} className="flex items-center space-x-2">
                              <Target className="h-4 w-4 text-blue-500" />
                              <span className="text-sm">{rec}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="behavior" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Activity className="h-5 w-5 mr-2" />
                  Behavior Patterns
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {mockSegmentationData.behaviorPatterns.map((pattern, index) => (
                    <div key={index} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-medium">{pattern.name}</h4>
                        <Badge variant="outline">{pattern.count} customers</Badge>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{pattern.description}</p>
                      <div className="bg-blue-50 p-3 rounded-lg">
                        <p className="text-xs text-blue-800">
                          <strong>Pattern:</strong> {pattern.pattern}
                        </p>
                        <p className="text-xs text-blue-800 mt-1">
                          <strong>Action:</strong> {pattern.recommendation}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="churn" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <AlertTriangle className="h-5 w-5 mr-2 text-red-500" />
                  Churn Risk Prediction
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="text-left p-4 font-medium">Customer</th>
                        <th className="text-left p-4 font-medium">Segment</th>
                        <th className="text-left p-4 font-medium">Churn Risk</th>
                        <th className="text-left p-4 font-medium">Days Inactive</th>
                        <th className="text-left p-4 font-medium">Last Order</th>
                        <th className="text-left p-4 font-medium">Predicted Date</th>
                        <th className="text-left p-4 font-medium">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {mockSegmentationData.churnPrediction.map((prediction) => (
                        <tr key={prediction.customerId} className="border-t hover:bg-gray-50">
                          <td className="p-4">
                            <div>
                              <p className="font-medium">{prediction.customerName}</p>
                              <p className="text-sm text-gray-600">{prediction.customerId}</p>
                            </div>
                          </td>
                          <td className="p-4">
                            <Badge variant="outline">{prediction.segment}</Badge>
                          </td>
                          <td className="p-4">
                            <div>
                              <Badge className={getChurnRiskColor(prediction.churnProbability)}>
                                {prediction.churnProbability}%
                              </Badge>
                              <Progress value={prediction.churnProbability} className="h-2 mt-1" />
                            </div>
                          </td>
                          <td className="p-4">
                            <p className="font-medium">{prediction.daysInactive} วัน</p>
                          </td>
                          <td className="p-4">
                            <p className="font-medium">฿{prediction.lastOrderValue.toLocaleString()}</p>
                          </td>
                          <td className="p-4">
                            <p className="text-sm text-red-600">{prediction.predictedChurnDate}</p>
                          </td>
                          <td className="p-4">
                            <div className="flex space-x-2">
                              <Button size="sm" variant="outline">
                                <Mail className="h-4 w-4" />
                              </Button>
                              <Button size="sm" variant="outline">
                                <MessageSquare className="h-4 w-4" />
                              </Button>
                              <Button size="sm">
                                <Gift className="h-4 w-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>

            {/* Risk Factors */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {mockSegmentationData.churnPrediction.map((prediction) => (
                <Card key={prediction.customerId}>
                  <CardHeader>
                    <CardTitle className="text-lg">{prediction.customerName}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-medium mb-2 text-red-600">Risk Factors</h4>
                        <div className="space-y-2">
                          {prediction.riskFactors.map((factor, index) => (
                            <div key={index} className="flex items-center space-x-2">
                              <AlertTriangle className="h-4 w-4 text-red-500" />
                              <span className="text-sm">{factor}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                      <div>
                        <h4 className="font-medium mb-2 text-green-600">Recommendations</h4>
                        <div className="space-y-2">
                          {prediction.recommendations.map((rec, index) => (
                            <div key={index} className="flex items-center space-x-2">
                              <Target className="h-4 w-4 text-green-500" />
                              <span className="text-sm">{rec}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="campaigns" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center">
                    <Target className="h-5 w-5 mr-2" />
                    Targeted Campaigns
                  </span>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Create Campaign
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="text-left p-4 font-medium">Campaign</th>
                        <th className="text-left p-4 font-medium">Segment</th>
                        <th className="text-left p-4 font-medium">Type</th>
                        <th className="text-left p-4 font-medium">Performance</th>
                        <th className="text-left p-4 font-medium">Revenue</th>
                        <th className="text-left p-4 font-medium">ROI</th>
                        <th className="text-left p-4 font-medium">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {mockSegmentationData.campaigns.map((campaign) => (
                        <tr key={campaign.id} className="border-t hover:bg-gray-50">
                          <td className="p-4">
                            <p className="font-medium">{campaign.name}</p>
                          </td>
                          <td className="p-4">
                            <Badge variant="outline">{campaign.segment}</Badge>
                          </td>
                          <td className="p-4">
                            <div className="flex items-center space-x-2">
                              {campaign.type === "email" ? (
                                <Mail className="h-4 w-4" />
                              ) : (
                                <MessageSquare className="h-4 w-4" />
                              )}
                              <span className="text-sm capitalize">{campaign.type}</span>
                            </div>
                          </td>
                          <td className="p-4">
                            <div className="space-y-1">
                              <div className="flex justify-between text-xs">
                                <span>Sent: {campaign.sent}</span>
                                <span>Opened: {campaign.opened}</span>
                              </div>
                              <div className="flex justify-between text-xs">
                                <span>Clicked: {campaign.clicked}</span>
                                <span>Converted: {campaign.converted}</span>
                              </div>
                              <Progress value={(campaign.converted / campaign.sent) * 100} className="h-1" />
                            </div>
                          </td>
                          <td className="p-4">
                            <p className="font-medium text-green-600">฿{campaign.revenue.toLocaleString()}</p>
                          </td>
                          <td className="p-4">
                            <Badge className="text-green-600 bg-green-100">{campaign.roi}%</Badge>
                          </td>
                          <td className="p-4">
                            <Badge variant={campaign.status === "active" ? "default" : "secondary"}>
                              {campaign.status}
                            </Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
