"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Progress } from "@/components/ui/progress"
import {
  Workflow,
  Play,
  Pause,
  Square,
  GitBranch,
  Clock,
  CheckCircle,
  XCircle,
  Settings,
  Plus,
  Edit,
  Eye,
  Copy,
  BarChart3,
  TrendingUp,
  Activity,
  ArrowDown,
  Filter,
  Search,
  FileText,
  Mail,
  MessageSquare,
  Database,
  Code,
} from "lucide-react"

// Mock data for workflow automation
const mockWorkflows = [
  {
    id: 1,
    name: "การประมวลผลคำสั่งซื้อ",
    description: "ประมวลผลคำสั่งซื้อตั้งแต่การยืนยันจนถึงการจัดส่ง",
    status: "active",
    trigger: "order_created",
    steps: 8,
    executions: 1245,
    successRate: 98.5,
    avgDuration: "2.5 นาที",
    lastRun: "2024-01-15 14:30",
    createdBy: "Admin User",
    createdAt: "2024-01-01",
  },
  {
    id: 2,
    name: "การจัดการสต็อกอัตโนมัติ",
    description: "ตรวจสอบและสั่งซื้อสินค้าเมื่อสต็อกต่ำ",
    status: "active",
    trigger: "stock_check",
    steps: 5,
    executions: 456,
    successRate: 95.2,
    avgDuration: "1.2 นาที",
    lastRun: "2024-01-15 12:00",
    createdBy: "Inventory Manager",
    createdAt: "2024-01-05",
  },
  {
    id: 3,
    name: "การต้อนรับลูกค้าใหม่",
    description: "ส่งอีเมลต้อนรับและตั้งค่าบัญชีลูกค้าใหม่",
    status: "active",
    trigger: "user_registered",
    steps: 6,
    executions: 234,
    successRate: 99.1,
    avgDuration: "30 วินาที",
    lastRun: "2024-01-15 16:20",
    createdBy: "Marketing Team",
    createdAt: "2024-01-10",
  },
  {
    id: 4,
    name: "การติดตามลูกค้าไม่ใช้งาน",
    description: "ส่งอีเมลและโปรโมชั่นให้ลูกค้าที่ไม่ใช้งาน",
    status: "paused",
    trigger: "user_inactive",
    steps: 4,
    executions: 89,
    successRate: 87.6,
    avgDuration: "45 วินาที",
    lastRun: "2024-01-10 10:00",
    createdBy: "CRM Team",
    createdAt: "2024-01-08",
  },
]

const mockWorkflowSteps = [
  {
    id: 1,
    workflowId: 1,
    name: "ตรวจสอบการชำระเงิน",
    type: "condition",
    status: "completed",
    duration: "0.5s",
    success: true,
    details: "ตรวจสอบสถานะการชำระเงิน",
  },
  {
    id: 2,
    workflowId: 1,
    name: "ส่งอีเมลยืนยัน",
    type: "action",
    status: "completed",
    duration: "1.2s",
    success: true,
    details: "ส่งอีเมลยืนยันคำสั่งซื้อให้ลูกค้า",
  },
  {
    id: 3,
    workflowId: 1,
    name: "อัพเดทสต็อก",
    type: "action",
    status: "completed",
    duration: "0.8s",
    success: true,
    details: "หักสต็อกสินค้าตามจำนวนที่สั่ง",
  },
  {
    id: 4,
    workflowId: 1,
    name: "สร้างใบจัดส่ง",
    type: "action",
    status: "running",
    duration: "2.1s",
    success: null,
    details: "สร้างใบจัดส่งและส่งไปยังคลังสินค้า",
  },
]

const mockWorkflowExecutions = [
  {
    id: 1,
    workflowId: 1,
    orderId: "ORD-2024-156",
    status: "completed",
    startTime: "2024-01-15 14:30:00",
    endTime: "2024-01-15 14:32:30",
    duration: "2.5 นาที",
    stepsCompleted: 8,
    stepsTotal: 8,
    success: true,
    error: null,
  },
  {
    id: 2,
    workflowId: 1,
    orderId: "ORD-2024-155",
    status: "failed",
    startTime: "2024-01-15 14:25:00",
    endTime: "2024-01-15 14:26:15",
    duration: "1.25 นาที",
    stepsCompleted: 3,
    stepsTotal: 8,
    success: false,
    error: "Payment verification failed",
  },
  {
    id: 3,
    workflowId: 2,
    orderId: "STOCK-CHECK-001",
    status: "running",
    startTime: "2024-01-15 15:00:00",
    endTime: null,
    duration: "30 วินาที",
    stepsCompleted: 2,
    stepsTotal: 5,
    success: null,
    error: null,
  },
]

export default function WorkflowAutomation() {
  const [activeTab, setActiveTab] = useState("overview")
  const [selectedWorkflow, setSelectedWorkflow] = useState(1)
  const [searchTerm, setSearchTerm] = useState("")

  // Workflow Overview
  const WorkflowOverview = () => (
    <div className="space-y-6">
      {/* Workflow Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Workflows ทั้งหมด</p>
                <p className="text-2xl font-bold">24</p>
                <p className="text-xs text-green-600 flex items-center mt-1">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  +3 ใหม่เดือนนี้
                </p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <Workflow className="h-6 w-6 text-blue-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-400 to-blue-600"></div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">ใช้งานอยู่</p>
                <p className="text-2xl font-bold">18</p>
                <p className="text-xs text-green-600">75% ของทั้งหมด</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <Play className="h-6 w-6 text-green-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-green-400 to-green-600"></div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">รันวันนี้</p>
                <p className="text-2xl font-bold">1,456</p>
                <p className="text-xs text-purple-600">+245 จากเมื่อวาน</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                <Activity className="h-6 w-6 text-purple-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-purple-400 to-purple-600"></div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">อัตราสำเร็จ</p>
                <p className="text-2xl font-bold">96.8%</p>
                <p className="text-xs text-green-600">+1.2% จากเดือนที่แล้ว</p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                <CheckCircle className="h-6 w-6 text-orange-600" />
              </div>
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-orange-400 to-orange-600"></div>
          </CardContent>
        </Card>
      </div>

      {/* Active Workflows */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Workflows ที่ใช้งานอยู่</span>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              สร้าง Workflow ใหม่
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left p-4 font-medium">Workflow</th>
                  <th className="text-left p-4 font-medium">ทริกเกอร์</th>
                  <th className="text-left p-4 font-medium">ขั้นตอน</th>
                  <th className="text-left p-4 font-medium">การรัน</th>
                  <th className="text-left p-4 font-medium">อัตราสำเร็จ</th>
                  <th className="text-left p-4 font-medium">เวลาเฉลี่ย</th>
                  <th className="text-left p-4 font-medium">สถานะ</th>
                  <th className="text-left p-4 font-medium">จัดการ</th>
                </tr>
              </thead>
              <tbody>
                {mockWorkflows.map((workflow) => (
                  <tr key={workflow.id} className="border-t hover:bg-gray-50">
                    <td className="p-4">
                      <div>
                        <p className="font-medium">{workflow.name}</p>
                        <p className="text-sm text-gray-600">{workflow.description}</p>
                        <p className="text-xs text-gray-500 mt-1">
                          สร้างโดย {workflow.createdBy} • {workflow.createdAt}
                        </p>
                      </div>
                    </td>
                    <td className="p-4">
                      <Badge variant="outline">
                        {workflow.trigger === "order_created" && "คำสั่งซื้อใหม่"}
                        {workflow.trigger === "stock_check" && "ตรวจสอบสต็อก"}
                        {workflow.trigger === "user_registered" && "สมาชิกใหม่"}
                        {workflow.trigger === "user_inactive" && "ผู้ใช้ไม่ใช้งาน"}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <p className="font-medium">{workflow.steps}</p>
                      <p className="text-sm text-gray-600">ขั้นตอน</p>
                    </td>
                    <td className="p-4">
                      <p className="font-medium">{workflow.executions.toLocaleString()}</p>
                      <p className="text-sm text-gray-600">ครั้ง</p>
                    </td>
                    <td className="p-4">
                      <p
                        className={`font-medium ${workflow.successRate >= 95 ? "text-green-600" : workflow.successRate >= 90 ? "text-yellow-600" : "text-red-600"}`}
                      >
                        {workflow.successRate}%
                      </p>
                    </td>
                    <td className="p-4">
                      <p className="text-sm">{workflow.avgDuration}</p>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-2">
                        <div
                          className={`w-2 h-2 rounded-full ${
                            workflow.status === "active"
                              ? "bg-green-500"
                              : workflow.status === "paused"
                                ? "bg-yellow-500"
                                : "bg-gray-400"
                          }`}
                        />
                        <Badge
                          variant={
                            workflow.status === "active"
                              ? "default"
                              : workflow.status === "paused"
                                ? "secondary"
                                : "outline"
                          }
                        >
                          {workflow.status === "active" && "ใช้งาน"}
                          {workflow.status === "paused" && "หยุดชั่วคราว"}
                          {workflow.status === "inactive" && "ไม่ใช้งาน"}
                        </Badge>
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Edit className="h-4 w-4" />
                        </Button>
                        {workflow.status === "active" ? (
                          <Button size="sm" variant="outline">
                            <Pause className="h-4 w-4" />
                          </Button>
                        ) : (
                          <Button size="sm" variant="outline">
                            <Play className="h-4 w-4" />
                          </Button>
                        )}
                        <Button size="sm" variant="outline">
                          <Copy className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Performance Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>การรัน Workflow รายวัน</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80 bg-gradient-to-br from-blue-50 to-indigo-100 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <BarChart3 className="h-16 w-16 text-blue-500 mx-auto mb-4" />
                <p className="text-gray-600">กราฟการรัน Workflow รายวัน</p>
                <p className="text-sm text-gray-500">แสดงจำนวนการรันและอัตราสำเร็จ</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>เวลาการประมวลผลเฉลี่ย</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80 bg-gradient-to-br from-green-50 to-teal-100 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <Clock className="h-16 w-16 text-green-500 mx-auto mb-4" />
                <p className="text-gray-600">เวลาการประมวลผลเฉลี่ย</p>
                <p className="text-sm text-gray-500">แสดงเวลาที่ใช้ในแต่ละ Workflow</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )

  // Workflow Builder
  const WorkflowBuilder = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-bold">Workflow Builder</h3>
          <p className="text-gray-600">สร้างและแก้ไข Workflow แบบ Visual</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <FileText className="h-4 w-4 mr-2" />
            เทมเพลต
          </Button>
          <Button variant="outline">
            <Code className="h-4 w-4 mr-2" />
            JSON Editor
          </Button>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Workflow ใหม่
          </Button>
        </div>
      </div>

      {/* Workflow Canvas */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>การประมวลผลคำสั่งซื้อ</span>
            <div className="flex space-x-2">
              <Button size="sm" variant="outline">
                <Play className="h-4 w-4 mr-2" />
                ทดสอบ
              </Button>
              <Button size="sm" variant="outline">
                <Eye className="h-4 w-4 mr-2" />
                ดูตัวอย่าง
              </Button>
              <Button size="sm">บันทึก</Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="min-h-96 bg-gray-50 rounded-lg p-6">
            {/* Workflow Steps Visualization */}
            <div className="space-y-6">
              {/* Start Node */}
              <div className="flex items-center">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <Play className="h-6 w-6 text-green-600" />
                </div>
                <div className="ml-4">
                  <p className="font-medium">เริ่มต้น: คำสั่งซื้อใหม่</p>
                  <p className="text-sm text-gray-600">ทริกเกอร์เมื่อมีคำสั่งซื้อใหม่</p>
                </div>
              </div>

              <div className="flex justify-center">
                <ArrowDown className="h-6 w-6 text-gray-400" />
              </div>

              {/* Condition Node */}
              <div className="flex items-center">
                <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center">
                  <GitBranch className="h-6 w-6 text-yellow-600" />
                </div>
                <div className="ml-4">
                  <p className="font-medium">เงื่อนไข: ตรวจสอบการชำระเงิน</p>
                  <p className="text-sm text-gray-600">ตรวจสอบว่าชำระเงินแล้วหรือไม่</p>
                </div>
              </div>

              <div className="flex justify-center">
                <ArrowDown className="h-6 w-6 text-gray-400" />
              </div>

              {/* Action Node */}
              <div className="flex items-center">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <Mail className="h-6 w-6 text-blue-600" />
                </div>
                <div className="ml-4">
                  <p className="font-medium">การดำเนินการ: ส่งอีเมลยืนยัน</p>
                  <p className="text-sm text-gray-600">ส่งอีเมลยืนยันคำสั่งซื้อให้ลูกค้า</p>
                </div>
              </div>

              <div className="flex justify-center">
                <ArrowDown className="h-6 w-6 text-gray-400" />
              </div>

              {/* Database Action */}
              <div className="flex items-center">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                  <Database className="h-6 w-6 text-purple-600" />
                </div>
                <div className="ml-4">
                  <p className="font-medium">การดำเนินการ: อัพเดทสต็อก</p>
                  <p className="text-sm text-gray-600">หักสต็อกสินค้าตามจำนวนที่สั่ง</p>
                </div>
              </div>

              <div className="flex justify-center">
                <ArrowDown className="h-6 w-6 text-gray-400" />
              </div>

              {/* End Node */}
              <div className="flex items-center">
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                  <Square className="h-6 w-6 text-red-600" />
                </div>
                <div className="ml-4">
                  <p className="font-medium">สิ้นสุด: เสร็จสิ้น</p>
                  <p className="text-sm text-gray-600">Workflow เสร็จสิ้นสมบูรณ์</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Step Configuration */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>ขั้นตอนที่มีอยู่</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {[
                { icon: Play, name: "เริ่มต้น", type: "trigger", color: "green" },
                { icon: GitBranch, name: "เงื่อนไข", type: "condition", color: "yellow" },
                { icon: Mail, name: "ส่งอีเมล", type: "action", color: "blue" },
                { icon: MessageSquare, name: "ส่ง SMS", type: "action", color: "blue" },
                { icon: Database, name: "อัพเดทฐานข้อมูล", type: "action", color: "purple" },
                { icon: Clock, name: "รอ", type: "delay", color: "orange" },
                { icon: Square, name: "สิ้นสุด", type: "end", color: "red" },
              ].map((step, index) => (
                <div key={index} className="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                  <div className={`w-8 h-8 bg-${step.color}-100 rounded-full flex items-center justify-center mr-3`}>
                    <step.icon className={`h-4 w-4 text-${step.color}-600`} />
                  </div>
                  <div>
                    <p className="font-medium">{step.name}</p>
                    <p className="text-xs text-gray-600">{step.type}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>การตั้งค่าขั้นตอน</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="step-name">ชื่อขั้นตอน</Label>
              <Input id="step-name" defaultValue="ส่งอีเมลยืนยัน" />
            </div>
            <div>
              <Label htmlFor="step-type">ประเภท</Label>
              <Select defaultValue="action">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="trigger">ทริกเกอร์</SelectItem>
                  <SelectItem value="condition">เงื่อนไข</SelectItem>
                  <SelectItem value="action">การดำเนินการ</SelectItem>
                  <SelectItem value="delay">รอ</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="step-config">การตั้งค่า</Label>
              <Textarea
                id="step-config"
                placeholder="การตั้งค่าเพิ่มเติม (JSON)"
                rows={4}
                defaultValue={`{
  "template": "order_confirmation",
  "recipient": "{{customer.email}}",
  "subject": "ยืนยันคำสั่งซื้อ #{{order.id}}"
}`}
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch id="step-enabled" defaultChecked />
              <Label htmlFor="step-enabled">เปิดใช้งานขั้นตอนนี้</Label>
            </div>
            <div className="flex space-x-2">
              <Button size="sm">บันทึก</Button>
              <Button size="sm" variant="outline" className="bg-transparent">
                ยกเลิก
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )

  // Execution History
  const ExecutionHistory = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-bold">ประวัติการรัน</h3>
          <p className="text-gray-600">ติดตามการรัน Workflow ทั้งหมด</p>
        </div>
        <div className="flex space-x-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="ค้นหาการรัน..."
              className="pl-10 w-64"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Select defaultValue="all">
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">ทั้งหมด</SelectItem>
              <SelectItem value="completed">สำเร็จ</SelectItem>
              <SelectItem value="failed">ล้มเหลว</SelectItem>
              <SelectItem value="running">กำลังรัน</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm">
            <Filter className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Execution Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">รันวันนี้</p>
                <p className="text-2xl font-bold text-blue-600">1,456</p>
              </div>
              <Activity className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">สำเร็จ</p>
                <p className="text-2xl font-bold text-green-600">1,409</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">ล้มเหลว</p>
                <p className="text-2xl font-bold text-red-600">47</p>
              </div>
              <XCircle className="h-8 w-8 text-red-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">กำลังรัน</p>
                <p className="text-2xl font-bold text-orange-600">12</p>
              </div>
              <Clock className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Execution Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left p-4 font-medium">การรัน</th>
                  <th className="text-left p-4 font-medium">Workflow</th>
                  <th className="text-left p-4 font-medium">สถานะ</th>
                  <th className="text-left p-4 font-medium">เวลาเริ่ม</th>
                  <th className="text-left p-4 font-medium">ระยะเวลา</th>
                  <th className="text-left p-4 font-medium">ความคืบหน้า</th>
                  <th className="text-left p-4 font-medium">ผลลัพธ์</th>
                  <th className="text-left p-4 font-medium">จัดการ</th>
                </tr>
              </thead>
              <tbody>
                {mockWorkflowExecutions.map((execution) => (
                  <tr key={execution.id} className="border-t hover:bg-gray-50">
                    <td className="p-4">
                      <div>
                        <p className="font-medium">#{execution.id}</p>
                        <p className="text-sm text-gray-600">{execution.orderId}</p>
                      </div>
                    </td>
                    <td className="p-4">
                      <p className="text-sm">{mockWorkflows.find((w) => w.id === execution.workflowId)?.name}</p>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-2">
                        <div
                          className={`w-2 h-2 rounded-full ${
                            execution.status === "completed"
                              ? "bg-green-500"
                              : execution.status === "failed"
                                ? "bg-red-500"
                                : execution.status === "running"
                                  ? "bg-blue-500 animate-pulse"
                                  : "bg-gray-400"
                          }`}
                        />
                        <Badge
                          variant={
                            execution.status === "completed"
                              ? "default"
                              : execution.status === "failed"
                                ? "destructive"
                                : execution.status === "running"
                                  ? "secondary"
                                  : "outline"
                          }
                        >
                          {execution.status === "completed" && "สำเร็จ"}
                          {execution.status === "failed" && "ล้มเหลว"}
                          {execution.status === "running" && "กำลังรัน"}
                          {execution.status === "pending" && "รอ"}
                        </Badge>
                      </div>
                    </td>
                    <td className="p-4">
                      <p className="text-sm">{execution.startTime}</p>
                    </td>
                    <td className="p-4">
                      <p className="text-sm">{execution.duration}</p>
                    </td>
                    <td className="p-4">
                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span>
                            {execution.stepsCompleted}/{execution.stepsTotal}
                          </span>
                          <span>{Math.round((execution.stepsCompleted / execution.stepsTotal) * 100)}%</span>
                        </div>
                        <Progress value={(execution.stepsCompleted / execution.stepsTotal) * 100} className="h-2" />
                      </div>
                    </td>
                    <td className="p-4">
                      {execution.success === true && (
                        <div className="flex items-center text-green-600">
                          <CheckCircle className="h-4 w-4 mr-1" />
                          <span className="text-sm">สำเร็จ</span>
                        </div>
                      )}
                      {execution.success === false && (
                        <div>
                          <div className="flex items-center text-red-600">
                            <XCircle className="h-4 w-4 mr-1" />
                            <span className="text-sm">ล้มเหลว</span>
                          </div>
                          <p className="text-xs text-red-600 mt-1">{execution.error}</p>
                        </div>
                      )}
                      {execution.success === null && (
                        <div className="flex items-center text-blue-600">
                          <Clock className="h-4 w-4 mr-1" />
                          <span className="text-sm">กำลังรัน</span>
                        </div>
                      )}
                    </td>
                    <td className="p-4">
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline">
                          <Eye className="h-4 w-4" />
                        </Button>
                        {execution.status === "running" && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-red-600 hover:text-red-700 bg-transparent"
                          >
                            <Square className="h-4 w-4" />
                          </Button>
                        )}
                        {execution.status === "failed" && (
                          <Button size="sm" variant="outline">
                            <Play className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Execution Details */}
      <Card>
        <CardHeader>
          <CardTitle>รายละเอียดการรัน #{selectedWorkflow}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {mockWorkflowSteps.map((step, index) => (
              <div key={step.id} className="flex items-center space-x-4 p-4 border rounded-lg">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                    <span className="text-sm font-bold">{index + 1}</span>
                  </div>
                  {step.status === "completed" && <CheckCircle className="h-5 w-5 text-green-600" />}
                  {step.status === "running" && <Clock className="h-5 w-5 text-blue-600 animate-pulse" />}
                  {step.status === "failed" && <XCircle className="h-5 w-5 text-red-600" />}
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">{step.name}</p>
                      <p className="text-sm text-gray-600">{step.details}</p>
                    </div>
                    <div className="text-right">
                      <Badge variant="outline">{step.type}</Badge>
                      <p className="text-sm text-gray-600 mt-1">{step.duration}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )

  // Workflow Settings
  const WorkflowSettings = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-bold">ตั้งค่า Workflow</h3>
        <p className="text-gray-600">จัดการการตั้งค่าทั่วไปของระบบ Workflow</p>
      </div>

      <Tabs defaultValue="general" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="general">ทั่วไป</TabsTrigger>
          <TabsTrigger value="triggers">ทริกเกอร์</TabsTrigger>
          <TabsTrigger value="notifications">การแจ้งเตือน</TabsTrigger>
          <TabsTrigger value="security">ความปลอดภัย</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>การตั้งค่าทั่วไป</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Switch id="auto-retry" defaultChecked />
                <Label htmlFor="auto-retry">ลองใหม่อัตโนมัติเมื่อล้มเหลว</Label>
              </div>
              <div>
                <Label htmlFor="max-retries">จำนวนครั้งที่ลองใหม่สูงสุด</Label>
                <Input id="max-retries" type="number" defaultValue="3" />
              </div>
              <div>
                <Label htmlFor="retry-delay">ระยะเวลารอก่อนลองใหม่ (วินาที)</Label>
                <Input id="retry-delay" type="number" defaultValue="30" />
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="parallel-execution" />
                <Label htmlFor="parallel-execution">อนุญาตการรันแบบขนาน</Label>
              </div>
              <div>
                <Label htmlFor="max-concurrent">จำนวนการรันพร้อมกันสูงสุด</Label>
                <Input id="max-concurrent" type="number" defaultValue="10" />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="triggers" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>การตั้งค่าทริกเกอร์</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Switch id="webhook-triggers" defaultChecked />
                <Label htmlFor="webhook-triggers">เปิดใช้งาน Webhook Triggers</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="scheduled-triggers" defaultChecked />
                <Label htmlFor="scheduled-triggers">เปิดใช้งาน Scheduled Triggers</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="database-triggers" defaultChecked />
                <Label htmlFor="database-triggers">เปิดใช้งาน Database Triggers</Label>
              </div>
              <div>
                <Label htmlFor="webhook-timeout">Webhook Timeout (วินาที)</Label>
                <Input id="webhook-timeout" type="number" defaultValue="30" />
              </div>
              <div>
                <Label htmlFor="trigger-queue-size">ขนาด Queue สำหรับ Triggers</Label>
                <Input id="trigger-queue-size" type="number" defaultValue="1000" />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>การแจ้งเตือน</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Switch id="success-notifications" />
                <Label htmlFor="success-notifications">แจ้งเตือนเมื่อ Workflow สำเร็จ</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="failure-notifications" defaultChecked />
                <Label htmlFor="failure-notifications">แจ้งเตือนเมื่อ Workflow ล้มเหลว</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="long-running-notifications" defaultChecked />
                <Label htmlFor="long-running-notifications">แจ้งเตือนเมื่อ Workflow รันนานเกินไป</Label>
              </div>
              <div>
                <Label htmlFor="long-running-threshold">เกณฑ์เวลารันนาน (นาที)</Label>
                <Input id="long-running-threshold" type="number" defaultValue="30" />
              </div>
              <div>
                <Label htmlFor="notification-email">อีเมลสำหรับการแจ้งเตือน</Label>
                <Input id="notification-email" type="email" defaultValue="admin@kdp.co.th" />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>ความปลอดภัย</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Switch id="audit-logging" defaultChecked />
                <Label htmlFor="audit-logging">บันทึก Audit Log</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="encryption" defaultChecked />
                <Label htmlFor="encryption">เข้ารหัสข้อมูลใน Workflow</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="ip-whitelist" />
                <Label htmlFor="ip-whitelist">จำกัด IP ที่เข้าถึงได้</Label>
              </div>
              <div>
                <Label htmlFor="allowed-ips">IP ที่อนุญาต</Label>
                <Textarea id="allowed-ips" placeholder="192.168.1.0/24&#10;10.0.0.0/8" rows={3} />
              </div>
              <div>
                <Label htmlFor="api-key-expiry">อายุ API Key (วัน)</Label>
                <Input id="api-key-expiry" type="number" defaultValue="365" />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center">
                <Workflow className="h-8 w-8 mr-3 text-blue-600" />
                Workflow Automation
              </h1>
              <p className="text-gray-600 mt-2">ระบบ Workflow อัตโนมัติขั้นสูง</p>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline">
                <BarChart3 className="h-4 w-4 mr-2" />
                รายงาน
              </Button>
              <Button variant="outline">
                <Settings className="h-4 w-4 mr-2" />
                ตั้งค่า
              </Button>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Workflow ใหม่
              </Button>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="overview" className="flex items-center space-x-2">
              <BarChart3 className="h-4 w-4" />
              <span>ภาพรวม</span>
            </TabsTrigger>
            <TabsTrigger value="builder" className="flex items-center space-x-2">
              <GitBranch className="h-4 w-4" />
              <span>สร้าง Workflow</span>
            </TabsTrigger>
            <TabsTrigger value="history" className="flex items-center space-x-2">
              <Clock className="h-4 w-4" />
              <span>ประวัติการรัน</span>
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center space-x-2">
              <Settings className="h-4 w-4" />
              <span>ตั้งค่า</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <WorkflowOverview />
          </TabsContent>

          <TabsContent value="builder">
            <WorkflowBuilder />
          </TabsContent>

          <TabsContent value="history">
            <ExecutionHistory />
          </TabsContent>

          <TabsContent value="settings">
            <WorkflowSettings />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
