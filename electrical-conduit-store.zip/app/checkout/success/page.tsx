"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import {
  CheckCircle,
  Package,
  Truck,
  Download,
  Share2,
  Star,
  MessageCircle,
  Phone,
  Mail,
  MapPin,
  Calendar,
  CreditCard,
  Gift,
  ArrowRight,
  Sparkles,
  Heart,
  ShoppingBag,
  Copy,
} from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import confetti from "canvas-confetti"

// Mock order data
const mockOrder = {
  id: "ORD-2024-001",
  date: "2024-01-15T10:30:00Z",
  total: 15750.0,
  items: 5,
  estimatedDelivery: "2024-01-18",
  customer: {
    name: "บริษัท ABC จำกัด",
    email: "abc@company.com",
    phone: "02-123-4567",
  },
  shipping: {
    address: "123 ถนนสุขุมวิท แขวงคลองเตย เขตคลองเตย กรุงเทพฯ 10110",
    method: "Standard Delivery",
    cost: 0,
    trackingNumber: "TH1234567890",
  },
  payment: {
    method: "Bank Transfer",
    reference: "TXN-ABC-001",
    paidAt: "2024-01-15T10:35:00Z",
  },
  products: [
    {
      id: 1,
      code: "LB-75G",
      name: "Malleable Iron Conduit Body LB-75G",
      size: '3/4"',
      quantity: 10,
      price: 360.0,
      image: "/placeholder.svg?height=60&width=60&text=LB-75G",
    },
    {
      id: 2,
      code: "T-75G",
      name: "Malleable Iron Conduit Body T-75G",
      size: '3/4"',
      quantity: 5,
      price: 450.0,
      image: "/placeholder.svg?height=60&width=60&text=T-75G",
    },
    {
      id: 3,
      code: "BC-75G",
      name: "Flat Top Cover BC-75G",
      size: '3/4"',
      quantity: 15,
      price: 215.0,
      image: "/placeholder.svg?height=60&width=60&text=BC-75G",
    },
  ],
}

const nextSteps = [
  {
    icon: Package,
    title: "เตรียมสินค้า",
    description: "เราจะเตรียมสินค้าของคุณภายใน 24 ชั่วโมง",
    status: "current",
  },
  {
    icon: Truck,
    title: "จัดส่งสินค้า",
    description: "สินค้าจะถูกจัดส่งภายใน 2-3 วันทำการ",
    status: "upcoming",
  },
  {
    icon: CheckCircle,
    title: "ได้รับสินค้า",
    description: "คาดว่าจะได้รับสินค้าในวันที่ 18 ม.ค. 2024",
    status: "upcoming",
  },
]

const specialOffers = [
  {
    title: "ส่วนลด 15% สำหรับคำสั่งซื้อถัดไป",
    description: "ใช้โค้ด NEXT15 ภายใน 30 วัน",
    code: "NEXT15",
    expiry: "28 ก.พ. 2024",
    icon: Gift,
  },
  {
    title: "จัดส่งฟรีสำหรับคำสั่งซื้อถัดไป",
    description: "สำหรับคำสั่งซื้อมากกว่า ฿3,000",
    code: "FREESHIP",
    expiry: "31 ม.ค. 2024",
    icon: Truck,
  },
]

const relatedCategories = [
  { name: "Malleable Iron LB", href: "/categories/malleable-iron-lb", count: 45 },
  { name: "Malleable Iron T", href: "/categories/malleable-iron-t", count: 32 },
  { name: "Covers & Gaskets", href: "/categories/covers", count: 28 },
  { name: "Junction Boxes", href: "/categories/junction-boxes", count: 56 },
]

export default function CheckoutSuccessPage() {
  const [showConfetti, setShowConfetti] = useState(true)
  const [copiedCode, setCopiedCode] = useState("")

  useEffect(() => {
    // Trigger confetti animation
    const duration = 3000
    const end = Date.now() + duration

    const colors = ["#10B981", "#3B82F6", "#8B5CF6", "#F59E0B"]

    const frame = () => {
      confetti({
        particleCount: 2,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors: colors,
      })
      confetti({
        particleCount: 2,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors: colors,
      })

      if (Date.now() < end) {
        requestAnimationFrame(frame)
      }
    }
    frame()

    // Stop confetti after 3 seconds
    setTimeout(() => setShowConfetti(false), duration)
  }, [])

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code)
    setCopiedCode(code)
    setTimeout(() => setCopiedCode(""), 2000)
  }

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: "สั่งซื้อสำเร็จ - KDP Engineering",
        text: `ฉันเพิ่งสั่งซื้อสินค้าจาก KDP Engineering เรียบร้อยแล้ว! คำสั่งซื้อ ${mockOrder.id}`,
        url: window.location.href,
      })
    } else {
      // Fallback for browsers that don't support Web Share API
      const url = window.location.href
      navigator.clipboard.writeText(url)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50">
      {/* Success Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <div className="relative inline-block">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 relative">
                <CheckCircle className="h-12 w-12 text-green-600" />
                {showConfetti && (
                  <div className="absolute -top-2 -right-2 animate-bounce">
                    <Sparkles className="h-8 w-8 text-yellow-500" />
                  </div>
                )}
              </div>
            </div>
            <h1 className="text-3xl font-bold text-green-600 mb-2">สั่งซื้อสำเร็จ!</h1>
            <p className="text-xl text-gray-600 mb-4">ขอบคุณสำหรับการสั่งซื้อ คำสั่งซื้อของคุณได้รับการยืนยันแล้ว</p>
            <div className="flex items-center justify-center space-x-4">
              <Badge className="bg-green-100 text-green-800 text-lg px-4 py-2">คำสั่งซื้อ: {mockOrder.id}</Badge>
              <Button variant="ghost" size="sm" onClick={() => handleCopyCode(mockOrder.id)} className="text-green-600">
                <Copy className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Order Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>สรุปคำสั่งซื้อ</span>
                  <Button variant="outline" size="sm">
                    <Download className="h-4 w-4 mr-2" />
                    ดาวน์โหลดใบเสร็จ
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {mockOrder.products.map((product) => (
                  <div key={product.id} className="flex items-center space-x-4 p-3 border rounded-lg">
                    <Image
                      src={product.image || "/placeholder.svg"}
                      alt={product.code}
                      width={60}
                      height={60}
                      className="rounded"
                    />
                    <div className="flex-1">
                      <h4 className="font-medium">{product.code}</h4>
                      <p className="text-sm text-gray-600">{product.name}</p>
                      <p className="text-xs text-gray-500">ขนาด: {product.size}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">฿{(product.price * product.quantity).toLocaleString()}</p>
                      <p className="text-sm text-gray-600">จำนวน: {product.quantity}</p>
                    </div>
                  </div>
                ))}

                <Separator />

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>ราคาสินค้า:</span>
                    <span>฿{(mockOrder.total - mockOrder.shipping.cost).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>ค่าจัดส่ง:</span>
                    <span>{mockOrder.shipping.cost ? `฿${mockOrder.shipping.cost.toLocaleString()}` : "ฟรี"}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between font-bold text-lg">
                    <span>ยอดรวม:</span>
                    <span>฿{mockOrder.total.toLocaleString()}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Shipping & Payment Info */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <MapPin className="h-5 w-5 mr-2" />
                    ที่อยู่จัดส่ง
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <p className="font-medium">{mockOrder.customer.name}</p>
                    <p className="text-sm text-gray-600">{mockOrder.shipping.address}</p>
                    <p className="text-sm text-gray-600">{mockOrder.customer.phone}</p>
                    <div className="pt-2 border-t">
                      <p className="text-sm">
                        <span className="font-medium">วิธีจัดส่ง:</span> {mockOrder.shipping.method}
                      </p>
                      <p className="text-sm">
                        <span className="font-medium">หมายเลขติดตาม:</span> {mockOrder.shipping.trackingNumber}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <CreditCard className="h-5 w-5 mr-2" />
                    การชำระเงิน
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span>วิธีการชำระ:</span>
                      <Badge variant="outline">{mockOrder.payment.method}</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>สถานะ:</span>
                      <Badge className="bg-green-100 text-green-800">ชำระแล้ว</Badge>
                    </div>
                    <div className="pt-2 border-t">
                      <p className="text-sm">
                        <span className="font-medium">หมายเลขอ้างอิง:</span> {mockOrder.payment.reference}
                      </p>
                      <p className="text-sm">
                        <span className="font-medium">ชำระเมื่อ:</span>{" "}
                        {new Date(mockOrder.payment.paidAt).toLocaleString("th-TH")}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Next Steps */}
            <Card>
              <CardHeader>
                <CardTitle>ขั้นตอนถัดไป</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {nextSteps.map((step, index) => (
                    <div key={index} className="flex items-start space-x-4">
                      <div
                        className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          step.status === "current" ? "bg-blue-100 text-blue-600" : "bg-gray-100 text-gray-400"
                        }`}
                      >
                        <step.icon className="h-5 w-5" />
                      </div>
                      <div className="flex-1">
                        <h4 className={`font-medium ${step.status === "current" ? "text-blue-600" : "text-gray-900"}`}>
                          {step.title}
                        </h4>
                        <p className="text-sm text-gray-600">{step.description}</p>
                      </div>
                      {step.status === "current" && <Badge className="bg-blue-100 text-blue-800">กำลังดำเนินการ</Badge>}
                    </div>
                  ))}
                </div>

                <Alert className="mt-4">
                  <Calendar className="h-4 w-4" />
                  <AlertDescription>
                    <strong>คาดว่าจะได้รับสินค้า:</strong>{" "}
                    {new Date(mockOrder.estimatedDelivery).toLocaleDateString("th-TH", {
                      weekday: "long",
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })}
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>การดำเนินการ</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Link href={`/orders`}>
                  <Button className="w-full justify-start">
                    <Package className="h-4 w-4 mr-2" />
                    ติดตามคำสั่งซื้อ
                  </Button>
                </Link>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  <Download className="h-4 w-4 mr-2" />
                  ดาวน์โหลดใบเสร็จ
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent" onClick={handleShare}>
                  <Share2 className="h-4 w-4 mr-2" />
                  แชร์
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  <Star className="h-4 w-4 mr-2" />
                  รีวิวสินค้า
                </Button>
              </CardContent>
            </Card>

            {/* Special Offers */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Gift className="h-5 w-5 mr-2 text-purple-600" />
                  ข้อเสนอพิเศษ
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {specialOffers.map((offer, index) => (
                  <div key={index} className="p-4 border rounded-lg bg-gradient-to-r from-purple-50 to-pink-50">
                    <div className="flex items-start space-x-3">
                      <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                        <offer.icon className="h-4 w-4 text-purple-600" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium text-purple-900">{offer.title}</h4>
                        <p className="text-sm text-purple-700 mb-2">{offer.description}</p>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <code className="bg-purple-200 text-purple-800 px-2 py-1 rounded text-sm font-mono">
                              {offer.code}
                            </code>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleCopyCode(offer.code)}
                              className="h-6 w-6 p-0"
                            >
                              <Copy className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                        <p className="text-xs text-purple-600 mt-1">หมดอายุ: {offer.expiry}</p>
                        {copiedCode === offer.code && <p className="text-xs text-green-600 mt-1">คัดลอกแล้ว!</p>}
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Continue Shopping */}
            <Card>
              <CardHeader>
                <CardTitle>ช้อปปิ้งต่อ</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {relatedCategories.map((category) => (
                  <Link key={category.name} href={category.href}>
                    <Button variant="outline" className="w-full justify-between bg-transparent">
                      <span>{category.name}</span>
                      <div className="flex items-center space-x-2">
                        <Badge variant="secondary">{category.count}</Badge>
                        <ArrowRight className="h-4 w-4" />
                      </div>
                    </Button>
                  </Link>
                ))}
                <Link href="/categories">
                  <Button className="w-full mt-4">
                    <ShoppingBag className="h-4 w-4 mr-2" />
                    ดูสินค้าทั้งหมด
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Customer Support */}
            <Card>
              <CardHeader>
                <CardTitle>ต้องการความช่วยเหลือ?</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  <MessageCircle className="h-4 w-4 mr-2" />
                  แชทสด
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  <Phone className="h-4 w-4 mr-2" />
                  โทร 0-2925-9633-4
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  <Mail className="h-4 w-4 mr-2" />
                  อีเมลสอบถาม
                </Button>
              </CardContent>
            </Card>

            {/* Review Reminder */}
            <Card className="bg-gradient-to-r from-yellow-50 to-orange-50 border-yellow-200">
              <CardContent className="p-4">
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center">
                    <Heart className="h-4 w-4 text-yellow-600" />
                  </div>
                  <div>
                    <h4 className="font-medium text-yellow-900">รีวิวสินค้า</h4>
                    <p className="text-sm text-yellow-800 mb-3">แบ่งปันประสบการณ์ของคุณเพื่อช่วยลูกค้าคนอื่น</p>
                    <Button size="sm" className="bg-yellow-600 hover:bg-yellow-700">
                      <Star className="h-4 w-4 mr-2" />
                      เขียนรีวิว
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Thank You Message */}
        <Card className="mt-8 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
          <CardContent className="p-8 text-center">
            <div className="max-w-2xl mx-auto">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">ขอบคุณที่เลือกใช้บริการ KDP Engineering & Supply</h2>
              <p className="text-gray-600 mb-6">
                เราภูมิใจที่ได้เป็นส่วนหนึ่งในโครงการของคุณ และมุ่งมั่นที่จะให้บริการที่ดีที่สุดเสมอ หากมีข้อสงสัยหรือต้องการความช่วยเหลือ
                อย่าลังเลที่จะติดต่อเรา
              </p>
              <div className="flex items-center justify-center space-x-4">
                <Link href="/">
                  <Button variant="outline">กลับหน้าแรก</Button>
                </Link>
                <Link href="/categories">
                  <Button>ช้อปปิ้งต่อ</Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
