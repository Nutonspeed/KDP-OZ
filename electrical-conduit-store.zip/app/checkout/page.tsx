"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Factory,
  CreditCard,
  Truck,
  MapPin,
  Lock,
  Shield,
  CheckCircle,
  Plus,
  Trash2,
  Edit,
  Gift,
  ArrowLeft,
  ArrowRight,
} from "lucide-react"

// Mock cart data
const cartData = [
  {
    id: "1",
    name: "ท่อร้อยสายไฟ PVC ขนาด 1/2 นิ้ว",
    brand: "O-Z/Gedney",
    sku: "PVC-12-100",
    price: 45,
    quantity: 10,
    image: "/placeholder.svg?height=80&width=80&text=PVC",
    weight: 0.5,
  },
  {
    id: "2",
    name: "กล่องพักสาย 4x4 นิ้ว",
    brand: "O-Z/Gedney",
    sku: "BOX-44-STD",
    price: 85,
    quantity: 5,
    image: "/placeholder.svg?height=80&width=80&text=Box",
    weight: 0.8,
  },
  {
    id: "3",
    name: "ข้อต่อท่อ 90 องศา ขนาด 3/4 นิ้ว",
    brand: "O-Z/Gedney",
    sku: "ELB-34-90",
    price: 25,
    quantity: 20,
    image: "/placeholder.svg?height=80&width=80&text=Elbow",
    weight: 0.3,
  },
]

// Mock user data
const userData = {
  firstName: "สมชาย",
  lastName: "ใจดี",
  email: "somchai@company.com",
  phone: "081-234-5678",
  companyName: "บริษัท ABC จำกัด",
  taxId: "0123456789012",
  addresses: [
    {
      id: "1",
      type: "office",
      name: "สำนักงานใหญ่",
      address: "123 ถนนสุขุมวิท แขวงคลองตัน เขตวัฒนา กรุงเทพฯ 10110",
      phone: "02-123-4567",
      isDefault: true,
    },
    {
      id: "2",
      type: "warehouse",
      name: "คลังสินค้า",
      address: "456 ถนนรามคำแหง แขวงหัวหมาก เขตบางกะปิ กรุงเทพฯ 10240",
      phone: "02-987-6543",
      isDefault: false,
    },
  ],
}

export default function CheckoutPage() {
  const [currentStep, setCurrentStep] = useState(1)
  const [selectedAddress, setSelectedAddress] = useState(userData.addresses[0].id)
  const [paymentMethod, setPaymentMethod] = useState("credit_card")
  const [shippingMethod, setShippingMethod] = useState("standard")
  const [couponCode, setCouponCode] = useState("")
  const [appliedCoupon, setAppliedCoupon] = useState<any>(null)
  const [specialInstructions, setSpecialInstructions] = useState("")
  const [agreeTerms, setAgreeTerms] = useState(false)
  const [saveInfo, setSaveInfo] = useState(true)

  const [newAddress, setNewAddress] = useState({
    name: "",
    address: "",
    phone: "",
  })

  const [paymentInfo, setPaymentInfo] = useState({
    cardNumber: "",
    expiryDate: "",
    cvv: "",
    cardName: "",
  })

  // Calculations
  const subtotal = cartData.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const totalWeight = cartData.reduce((sum, item) => sum + item.weight * item.quantity, 0)

  const shippingRates = {
    standard: totalWeight <= 10 ? 0 : Math.ceil(totalWeight / 10) * 50,
    express: totalWeight <= 10 ? 100 : 100 + Math.ceil(totalWeight / 10) * 30,
    overnight: totalWeight <= 10 ? 200 : 200 + Math.ceil(totalWeight / 10) * 50,
  }

  const shippingCost = shippingRates[shippingMethod as keyof typeof shippingRates]
  const tax = Math.round(subtotal * 0.07) // 7% VAT
  const discount = appliedCoupon ? Math.round(subtotal * (appliedCoupon.percentage / 100)) : 0
  const total = subtotal + shippingCost + tax - discount

  const handleApplyCoupon = () => {
    // Mock coupon validation
    if (couponCode === "SAVE10") {
      setAppliedCoupon({ code: "SAVE10", percentage: 10, description: "ส่วนลด 10%" })
    } else if (couponCode === "NEWCUSTOMER") {
      setAppliedCoupon({ code: "NEWCUSTOMER", percentage: 15, description: "ส่วนลดลูกค้าใหม่ 15%" })
    } else {
      alert("รหัสคูปองไม่ถูกต้อง")
    }
  }

  const handleRemoveCoupon = () => {
    setAppliedCoupon(null)
    setCouponCode("")
  }

  const handleNextStep = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1)
    }
  }

  const handlePrevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handlePlaceOrder = () => {
    if (!agreeTerms) {
      alert("กรุณายอมรับข้อตกลงและเงื่อนไข")
      return
    }

    // Process order
    console.log("Order placed:", {
      items: cartData,
      address: selectedAddress,
      payment: paymentMethod,
      shipping: shippingMethod,
      total,
    })

    // Redirect to success page
    alert("สั่งซื้อสำเร็จ! คุณจะได้รับอีเมลยืนยันในไม่ช้า")
  }

  const getShippingMethodName = (method: string) => {
    switch (method) {
      case "standard":
        return "จัดส่งมาตรฐาน (3-5 วันทำการ)"
      case "express":
        return "จัดส่งด่วน (1-2 วันทำการ)"
      case "overnight":
        return "จัดส่งด่วนพิเศษ (1 วันทำการ)"
      default:
        return method
    }
  }

  const getPaymentMethodName = (method: string) => {
    switch (method) {
      case "credit_card":
        return "บัตรเครดิต/เดบิต"
      case "bank_transfer":
        return "โอนเงินผ่านธนาคาร"
      case "cash_on_delivery":
        return "เก็บเงินปลายทาง"
      case "installment":
        return "ผ่อนชำระ 0%"
      default:
        return method
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <Factory className="h-6 w-6 text-white" />
              </div>
              <div>
                <div className="text-xl font-bold text-gray-900">O-Z/Gedney</div>
                <div className="text-xs text-gray-500">อุปกรณ์ไฟฟ้า</div>
              </div>
            </Link>

            <div className="flex items-center space-x-4">
              <Link href="/cart">
                <Button variant="outline">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  กลับไปตะกร้า
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Checkout Content */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Progress Steps */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              {[
                { step: 1, title: "ที่อยู่จัดส่ง", icon: MapPin },
                { step: 2, title: "วิธีจัดส่ง", icon: Truck },
                { step: 3, title: "การชำระเงิน", icon: CreditCard },
                { step: 4, title: "ยืนยันคำสั่งซื้อ", icon: CheckCircle },
              ].map(({ step, title, icon: Icon }) => (
                <div
                  key={step}
                  className={`flex items-center ${currentStep >= step ? "text-blue-600" : "text-gray-400"}`}
                >
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      currentStep >= step ? "bg-blue-600 text-white" : "bg-gray-200"
                    }`}
                  >
                    {currentStep > step ? <CheckCircle className="h-5 w-5" /> : <Icon className="h-5 w-5" />}
                  </div>
                  <span className="ml-2 text-sm font-medium hidden sm:block">{title}</span>
                </div>
              ))}
            </div>
            <Progress value={(currentStep / 4) * 100} className="h-2" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* Step 1: Shipping Address */}
              {currentStep === 1 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <MapPin className="h-5 w-5 mr-2" />
                      ที่อยู่จัดส่ง
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Existing Addresses */}
                    <div className="space-y-4">
                      <h3 className="font-medium">เลือกที่อยู่จัดส่ง</h3>
                      <RadioGroup value={selectedAddress} onValueChange={setSelectedAddress}>
                        {userData.addresses.map((address) => (
                          <div key={address.id} className="flex items-start space-x-3 p-4 border rounded-lg">
                            <RadioGroupItem value={address.id} id={address.id} className="mt-1" />
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-2">
                                <Label htmlFor={address.id} className="font-medium cursor-pointer">
                                  {address.name}
                                </Label>
                                {address.isDefault && <Badge variant="secondary">ค่าเริ่มต้น</Badge>}
                                <Badge variant="outline">{address.type === "office" ? "สำนักงาน" : "คลังสินค้า"}</Badge>
                              </div>
                              <p className="text-sm text-gray-600 mb-1">{address.address}</p>
                              <p className="text-sm text-gray-600">โทร: {address.phone}</p>
                            </div>
                            <Button variant="outline" size="sm">
                              <Edit className="h-4 w-4" />
                            </Button>
                          </div>
                        ))}
                      </RadioGroup>
                    </div>

                    <Separator />

                    {/* Add New Address */}
                    <div className="space-y-4">
                      <h3 className="font-medium">เพิ่มที่อยู่ใหม่</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="addressName">ชื่อที่อยู่</Label>
                          <Input
                            id="addressName"
                            value={newAddress.name}
                            onChange={(e) => setNewAddress((prev) => ({ ...prev, name: e.target.value }))}
                            placeholder="เช่น สำนักงานสาขา 2"
                          />
                        </div>
                        <div>
                          <Label htmlFor="addressPhone">เบอร์โทรศัพท์</Label>
                          <Input
                            id="addressPhone"
                            value={newAddress.phone}
                            onChange={(e) => setNewAddress((prev) => ({ ...prev, phone: e.target.value }))}
                            placeholder="08X-XXX-XXXX"
                          />
                        </div>
                      </div>
                      <div>
                        <Label htmlFor="fullAddress">ที่อยู่เต็ม</Label>
                        <Textarea
                          id="fullAddress"
                          value={newAddress.address}
                          onChange={(e) => setNewAddress((prev) => ({ ...prev, address: e.target.value }))}
                          placeholder="เลขที่ ถนน ตำบล อำเภอ จังหวัด รหัสไปรษณีย์"
                          rows={3}
                        />
                      </div>
                      <Button variant="outline" className="w-full bg-transparent">
                        <Plus className="h-4 w-4 mr-2" />
                        เพิ่มที่อยู่นี้
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Step 2: Shipping Method */}
              {currentStep === 2 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Truck className="h-5 w-5 mr-2" />
                      วิธีจัดส่ง
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <RadioGroup value={shippingMethod} onValueChange={setShippingMethod}>
                      <div className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-3">
                          <RadioGroupItem value="standard" id="standard" />
                          <div>
                            <Label htmlFor="standard" className="font-medium cursor-pointer">
                              จัดส่งมาตรฐาน
                            </Label>
                            <p className="text-sm text-gray-600">3-5 วันทำการ</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="font-medium">
                            {shippingRates.standard === 0 ? "ฟรี" : `฿${shippingRates.standard.toLocaleString()}`}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-3">
                          <RadioGroupItem value="express" id="express" />
                          <div>
                            <Label htmlFor="express" className="font-medium cursor-pointer">
                              จัดส่งด่วน
                            </Label>
                            <p className="text-sm text-gray-600">1-2 วันทำการ</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="font-medium">฿{shippingRates.express.toLocaleString()}</span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-3">
                          <RadioGroupItem value="overnight" id="overnight" />
                          <div>
                            <Label htmlFor="overnight" className="font-medium cursor-pointer">
                              จัดส่งด่วนพิเศษ
                            </Label>
                            <p className="text-sm text-gray-600">1 วันทำการ</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="font-medium">฿{shippingRates.overnight.toLocaleString()}</span>
                        </div>
                      </div>
                    </RadioGroup>

                    <div className="mt-6">
                      <Label htmlFor="instructions">คำแนะนำพิเศษ (ไม่บังคับ)</Label>
                      <Textarea
                        id="instructions"
                        value={specialInstructions}
                        onChange={(e) => setSpecialInstructions(e.target.value)}
                        placeholder="เช่น จัดส่งในช่วงเวลา 9:00-17:00 น."
                        rows={3}
                      />
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Step 3: Payment Method */}
              {currentStep === 3 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <CreditCard className="h-5 w-5 mr-2" />
                      การชำระเงิน
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
                      <div className="flex items-center space-x-3 p-4 border rounded-lg">
                        <RadioGroupItem value="credit_card" id="credit_card" />
                        <div className="flex-1">
                          <Label htmlFor="credit_card" className="font-medium cursor-pointer">
                            บัตรเครดิต/เดบิต
                          </Label>
                          <p className="text-sm text-gray-600">Visa, Mastercard, JCB</p>
                        </div>
                        <div className="flex space-x-2">
                          <div className="w-8 h-5 bg-blue-600 rounded text-white text-xs flex items-center justify-center">
                            VISA
                          </div>
                          <div className="w-8 h-5 bg-red-600 rounded text-white text-xs flex items-center justify-center">
                            MC
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center space-x-3 p-4 border rounded-lg">
                        <RadioGroupItem value="bank_transfer" id="bank_transfer" />
                        <div className="flex-1">
                          <Label htmlFor="bank_transfer" className="font-medium cursor-pointer">
                            โอนเงินผ่านธนาคาร
                          </Label>
                          <p className="text-sm text-gray-600">โอนภายใน 24 ชั่วโมง</p>
                        </div>
                      </div>

                      <div className="flex items-center space-x-3 p-4 border rounded-lg">
                        <RadioGroupItem value="cash_on_delivery" id="cash_on_delivery" />
                        <div className="flex-1">
                          <Label htmlFor="cash_on_delivery" className="font-medium cursor-pointer">
                            เก็บเงินปลายทาง
                          </Label>
                          <p className="text-sm text-gray-600">ชำระเมื่อได้รับสินค้า (+฿30)</p>
                        </div>
                      </div>

                      <div className="flex items-center space-x-3 p-4 border rounded-lg">
                        <RadioGroupItem value="installment" id="installment" />
                        <div className="flex-1">
                          <Label htmlFor="installment" className="font-medium cursor-pointer">
                            ผ่อนชำระ 0%
                          </Label>
                          <p className="text-sm text-gray-600">3, 6, 10 เดือน (บัตรเครดิตที่ร่วมรายการ)</p>
                        </div>
                      </div>
                    </RadioGroup>

                    {/* Credit Card Form */}
                    {paymentMethod === "credit_card" && (
                      <div className="space-y-4 p-4 bg-gray-50 rounded-lg">
                        <h4 className="font-medium">ข้อมูลบัตรเครดิต</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="md:col-span-2">
                            <Label htmlFor="cardNumber">หมายเลขบัตร</Label>
                            <Input
                              id="cardNumber"
                              value={paymentInfo.cardNumber}
                              onChange={(e) => setPaymentInfo((prev) => ({ ...prev, cardNumber: e.target.value }))}
                              placeholder="1234 5678 9012 3456"
                              maxLength={19}
                            />
                          </div>
                          <div>
                            <Label htmlFor="expiryDate">วันหมดอายุ</Label>
                            <Input
                              id="expiryDate"
                              value={paymentInfo.expiryDate}
                              onChange={(e) => setPaymentInfo((prev) => ({ ...prev, expiryDate: e.target.value }))}
                              placeholder="MM/YY"
                              maxLength={5}
                            />
                          </div>
                          <div>
                            <Label htmlFor="cvv">CVV</Label>
                            <Input
                              id="cvv"
                              value={paymentInfo.cvv}
                              onChange={(e) => setPaymentInfo((prev) => ({ ...prev, cvv: e.target.value }))}
                              placeholder="123"
                              maxLength={4}
                            />
                          </div>
                          <div className="md:col-span-2">
                            <Label htmlFor="cardName">ชื่อบนบัตร</Label>
                            <Input
                              id="cardName"
                              value={paymentInfo.cardName}
                              onChange={(e) => setPaymentInfo((prev) => ({ ...prev, cardName: e.target.value }))}
                              placeholder="ชื่อเต็มตามบัตร"
                            />
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Checkbox id="saveCard" checked={saveInfo} onCheckedChange={setSaveInfo} />
                          <Label htmlFor="saveCard" className="text-sm cursor-pointer">
                            บันทึกข้อมูลบัตรสำหรับการซื้อครั้งต่อไป
                          </Label>
                        </div>
                      </div>
                    )}

                    {/* Bank Transfer Info */}
                    {paymentMethod === "bank_transfer" && (
                      <div className="p-4 bg-blue-50 rounded-lg">
                        <h4 className="font-medium mb-2">ข้อมูลการโอนเงิน</h4>
                        <div className="space-y-2 text-sm">
                          <p>
                            <strong>ธนาคาร:</strong> กสิกรไทย
                          </p>
                          <p>
                            <strong>เลขที่บัญชี:</strong> 123-4-56789-0
                          </p>
                          <p>
                            <strong>ชื่อบัญชี:</strong> บริษัท O-Z/Gedney (ประเทศไทย) จำกัด
                          </p>
                          <p className="text-blue-600 font-medium">กรุณาโอนเงินภายใน 24 ชั่วโมง และแนบหลักฐานการโอน</p>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}

              {/* Step 4: Order Confirmation */}
              {currentStep === 4 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <CheckCircle className="h-5 w-5 mr-2" />
                      ยืนยันคำสั่งซื้อ
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Order Summary */}
                    <div>
                      <h3 className="font-medium mb-4">สรุปคำสั่งซื้อ</h3>
                      <div className="space-y-4">
                        {cartData.map((item) => (
                          <div key={item.id} className="flex items-center space-x-4 p-4 border rounded-lg">
                            <Image
                              src={item.image || "/placeholder.svg"}
                              alt={item.name}
                              width={60}
                              height={60}
                              className="rounded-lg"
                            />
                            <div className="flex-1">
                              <h4 className="font-medium">{item.name}</h4>
                              <p className="text-sm text-gray-600">
                                {item.brand} • {item.sku}
                              </p>
                              <p className="text-sm text-gray-600">จำนวน: {item.quantity} ชิ้น</p>
                            </div>
                            <div className="text-right">
                              <p className="font-medium">฿{(item.price * item.quantity).toLocaleString()}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <Separator />

                    {/* Shipping Address */}
                    <div>
                      <h3 className="font-medium mb-2">ที่อยู่จัดส่ง</h3>
                      {(() => {
                        const address = userData.addresses.find((addr) => addr.id === selectedAddress)
                        return address ? (
                          <div className="p-4 bg-gray-50 rounded-lg">
                            <p className="font-medium">{address.name}</p>
                            <p className="text-sm text-gray-600">{address.address}</p>
                            <p className="text-sm text-gray-600">โทร: {address.phone}</p>
                          </div>
                        ) : null
                      })()}
                    </div>

                    <Separator />

                    {/* Shipping & Payment */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h3 className="font-medium mb-2">วิธีจัดส่ง</h3>
                        <p className="text-sm text-gray-600">{getShippingMethodName(shippingMethod)}</p>
                        {specialInstructions && (
                          <p className="text-sm text-gray-600 mt-1">หมายเหตุ: {specialInstructions}</p>
                        )}
                      </div>
                      <div>
                        <h3 className="font-medium mb-2">วิธีชำระเงิน</h3>
                        <p className="text-sm text-gray-600">{getPaymentMethodName(paymentMethod)}</p>
                      </div>
                    </div>

                    <Separator />

                    {/* Terms Agreement */}
                    <div className="flex items-start space-x-2">
                      <Checkbox id="agreeTerms" checked={agreeTerms} onCheckedChange={setAgreeTerms} />
                      <div className="text-sm">
                        <Label htmlFor="agreeTerms" className="cursor-pointer">
                          ฉันยอมรับ{" "}
                          <Link href="/terms" className="text-blue-600 hover:underline">
                            ข้อตกลงและเงื่อนไข
                          </Link>{" "}
                          และ{" "}
                          <Link href="/privacy" className="text-blue-600 hover:underline">
                            นโยบายความเป็นส่วนตัว
                          </Link>
                        </Label>
                      </div>
                    </div>

                    {/* Security Notice */}
                    <div className="flex items-center space-x-2 p-4 bg-green-50 rounded-lg">
                      <Shield className="h-5 w-5 text-green-600" />
                      <div className="text-sm text-green-700">
                        <p className="font-medium">การชำระเงินปลอดภัย</p>
                        <p>ข้อมูลของคุณได้รับการเข้ารหัสและปกป้องด้วยระบบความปลอดภัยระดับสูง</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Navigation Buttons */}
              <div className="flex justify-between">
                {currentStep > 1 ? (
                  <Button variant="outline" onClick={handlePrevStep}>
                    <ArrowLeft className="h-4 w-4 mr-2" />
                    ย้อนกลับ
                  </Button>
                ) : (
                  <div />
                )}

                {currentStep < 4 ? (
                  <Button onClick={handleNextStep} className="bg-blue-600 hover:bg-blue-700">
                    ถัดไป
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                ) : (
                  <Button onClick={handlePlaceOrder} className="bg-green-600 hover:bg-green-700" disabled={!agreeTerms}>
                    <CheckCircle className="h-4 w-4 mr-2" />
                    สั่งซื้อ
                  </Button>
                )}
              </div>
            </div>

            {/* Order Summary Sidebar */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>สรุปคำสั่งซื้อ</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Items */}
                  <div className="space-y-3">
                    {cartData.map((item) => (
                      <div key={item.id} className="flex items-center justify-between text-sm">
                        <div className="flex-1">
                          <p className="font-medium truncate">{item.name}</p>
                          <p className="text-gray-600">x{item.quantity}</p>
                        </div>
                        <span className="font-medium">฿{(item.price * item.quantity).toLocaleString()}</span>
                      </div>
                    ))}
                  </div>

                  <Separator />

                  {/* Coupon */}
                  <div className="space-y-3">
                    <div className="flex space-x-2">
                      <Input
                        placeholder="รหัสคูปอง"
                        value={couponCode}
                        onChange={(e) => setCouponCode(e.target.value)}
                        disabled={!!appliedCoupon}
                      />
                      {appliedCoupon ? (
                        <Button variant="outline" onClick={handleRemoveCoupon}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      ) : (
                        <Button variant="outline" onClick={handleApplyCoupon}>
                          <Gift className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                    {appliedCoupon && (
                      <div className="flex items-center justify-between text-sm text-green-600">
                        <span>{appliedCoupon.description}</span>
                        <span>-฿{discount.toLocaleString()}</span>
                      </div>
                    )}
                  </div>

                  <Separator />

                  {/* Totals */}
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>ยอดรวมสินค้า</span>
                      <span>฿{subtotal.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>ค่าจัดส่ง</span>
                      <span>{shippingCost === 0 ? "ฟรี" : `฿${shippingCost.toLocaleString()}`}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>ภาษีมูลค่าเพิ่ม (7%)</span>
                      <span>฿{tax.toLocaleString()}</span>
                    </div>
                    {discount > 0 && (
                      <div className="flex justify-between text-green-600">
                        <span>ส่วนลด</span>
                        <span>-฿{discount.toLocaleString()}</span>
                      </div>
                    )}
                  </div>

                  <Separator />

                  <div className="flex justify-between font-bold text-lg">
                    <span>ยอดรวมทั้งสิ้น</span>
                    <span className="text-blue-600">฿{total.toLocaleString()}</span>
                  </div>

                  {/* Weight Info */}
                  <div className="text-xs text-gray-500 text-center">น้ำหนักรวม: {totalWeight.toFixed(1)} กก.</div>
                </CardContent>
              </Card>

              {/* Security Badges */}
              <Card>
                <CardContent className="p-4">
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2 text-sm">
                      <Shield className="h-4 w-4 text-green-600" />
                      <span>SSL Encryption</span>
                    </div>
                    <div className="flex items-center space-x-2 text-sm">
                      <Lock className="h-4 w-4 text-green-600" />
                      <span>ข้อมูลปลอดภัย 100%</span>
                    </div>
                    <div className="flex items-center space-x-2 text-sm">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span>รับประกันความพึงพอใจ</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
