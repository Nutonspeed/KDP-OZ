"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import {
  Factory,
  User,
  ShoppingBag,
  Settings,
  Shield,
  Bell,
  Edit,
  Camera,
  Star,
  Trophy,
  Gift,
  CreditCard,
  MapPin,
  Phone,
  Mail,
  Building,
  Package,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  Smartphone,
  Monitor,
  Tablet,
  LogOut,
  Key,
  Eye,
  EyeOff,
} from "lucide-react"

// Mock user data
const userData = {
  id: "user_123",
  firstName: "สมชาย",
  lastName: "ใจดี",
  email: "somchai@company.com",
  phone: "081-234-5678",
  avatar: "/placeholder.svg?height=100&width=100&text=SC",
  companyName: "บริษัท ABC จำกัด",
  businessType: "ผู้รับเหมา",
  memberSince: "2023-01-15",
  loyaltyLevel: "Gold",
  loyaltyPoints: 2450,
  totalOrders: 47,
  totalSpent: 125000,
  address: {
    street: "123 ถนนสุขุมวิท",
    district: "วัฒนา",
    province: "กรุงเทพฯ",
    postalCode: "10110",
  },
}

// Mock orders data
const ordersData = [
  {
    id: "ORD-2024-001",
    date: "2024-01-15",
    status: "delivered",
    total: 2850,
    items: 3,
    trackingNumber: "TH123456789",
  },
  {
    id: "ORD-2024-002",
    date: "2024-01-10",
    status: "processing",
    total: 1250,
    items: 2,
    trackingNumber: "TH987654321",
  },
  {
    id: "ORD-2024-003",
    date: "2024-01-05",
    status: "shipped",
    total: 3200,
    items: 5,
    trackingNumber: "TH456789123",
  },
]

// Mock sessions data
const sessionsData = [
  {
    id: "session_1",
    device: "Chrome on Windows",
    location: "กรุงเทพฯ, ประเทศไทย",
    lastActive: "ขณะนี้",
    current: true,
    icon: Monitor,
  },
  {
    id: "session_2",
    device: "Safari on iPhone",
    location: "กรุงเทพฯ, ประเทศไทย",
    lastActive: "2 ชั่วโมงที่แล้ว",
    current: false,
    icon: Smartphone,
  },
  {
    id: "session_3",
    device: "Chrome on Android",
    location: "ชลบุรี, ประเทศไทย",
    lastActive: "1 วันที่แล้ว",
    current: false,
    icon: Tablet,
  },
]

export default function ProfilePage() {
  const [activeTab, setActiveTab] = useState("overview")
  const [isEditing, setIsEditing] = useState(false)
  const [showCurrentPassword, setShowCurrentPassword] = useState(false)
  const [showNewPassword, setShowNewPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)

  const [profileData, setProfileData] = useState(userData)
  const [notifications, setNotifications] = useState({
    orderUpdates: true,
    promotions: true,
    newsletter: false,
    priceAlerts: true,
    stockAlerts: true,
    sms: false,
    push: true,
  })

  const [securitySettings, setSecuritySettings] = useState({
    twoFactorAuth: false,
    loginAlerts: true,
    sessionTimeout: "30",
  })

  const getLoyaltyColor = (level: string) => {
    switch (level) {
      case "Bronze":
        return "bg-amber-600"
      case "Silver":
        return "bg-gray-400"
      case "Gold":
        return "bg-yellow-500"
      case "Platinum":
        return "bg-purple-600"
      default:
        return "bg-gray-400"
    }
  }

  const getLoyaltyProgress = (points: number) => {
    const levels = { Bronze: 0, Silver: 1000, Gold: 2000, Platinum: 5000 }
    const currentLevel = userData.loyaltyLevel
    const nextLevel =
      currentLevel === "Bronze"
        ? "Silver"
        : currentLevel === "Silver"
          ? "Gold"
          : currentLevel === "Gold"
            ? "Platinum"
            : "Platinum"

    if (currentLevel === "Platinum") return 100

    const currentThreshold = levels[currentLevel as keyof typeof levels]
    const nextThreshold = levels[nextLevel as keyof typeof levels]

    return ((points - currentThreshold) / (nextThreshold - currentThreshold)) * 100
  }

  const getOrderStatusColor = (status: string) => {
    switch (status) {
      case "delivered":
        return "text-green-600 bg-green-50"
      case "shipped":
        return "text-blue-600 bg-blue-50"
      case "processing":
        return "text-yellow-600 bg-yellow-50"
      case "cancelled":
        return "text-red-600 bg-red-50"
      default:
        return "text-gray-600 bg-gray-50"
    }
  }

  const getOrderStatusText = (status: string) => {
    switch (status) {
      case "delivered":
        return "จัดส่งแล้ว"
      case "shipped":
        return "กำลังจัดส่ง"
      case "processing":
        return "กำลังดำเนินการ"
      case "cancelled":
        return "ยกเลิกแล้ว"
      default:
        return status
    }
  }

  const getOrderStatusIcon = (status: string) => {
    switch (status) {
      case "delivered":
        return CheckCircle
      case "shipped":
        return Package
      case "processing":
        return Clock
      case "cancelled":
        return XCircle
      default:
        return AlertCircle
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <Factory className="h-6 w-6 text-white" />
              </div>
              <div>
                <div className="text-xl font-bold text-gray-900">O-Z/Gedney</div>
                <div className="text-xs text-gray-500">อุปกรณ์ไฟฟ้า</div>
              </div>
            </Link>

            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-gray-700 hover:text-blue-600">
                หน้าแรก
              </Link>
              <Link href="/categories" className="text-gray-700 hover:text-blue-600">
                สินค้า
              </Link>
              <Link href="/cart" className="text-gray-700 hover:text-blue-600">
                ตะกร้า
              </Link>
              <Link href="/wishlist" className="text-gray-700 hover:text-blue-600">
                รายการโปรด
              </Link>
            </nav>

            <div className="flex items-center space-x-4">
              <Link href="/admin">
                <Button variant="outline">แอดมิน</Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Profile Content */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Profile Header */}
          <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
            <div className="flex items-start justify-between">
              <div className="flex items-center space-x-6">
                <div className="relative">
                  <Avatar className="h-24 w-24">
                    <AvatarImage
                      src={profileData.avatar || "/placeholder.svg"}
                      alt={`${profileData.firstName} ${profileData.lastName}`}
                    />
                    <AvatarFallback className="text-2xl">
                      {profileData.firstName.charAt(0)}
                      {profileData.lastName.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <Button size="sm" className="absolute -bottom-2 -right-2 rounded-full h-8 w-8 p-0">
                    <Camera className="h-4 w-4" />
                  </Button>
                </div>

                <div>
                  <h1 className="text-2xl font-bold text-gray-900">
                    {profileData.firstName} {profileData.lastName}
                  </h1>
                  <p className="text-gray-600">{profileData.companyName}</p>
                  <p className="text-sm text-gray-500">{profileData.businessType}</p>

                  <div className="flex items-center space-x-4 mt-3">
                    <Badge className={`${getLoyaltyColor(profileData.loyaltyLevel)} text-white`}>
                      <Trophy className="h-3 w-3 mr-1" />
                      {profileData.loyaltyLevel} Member
                    </Badge>
                    <span className="text-sm text-gray-500">
                      สมาชิกตั้งแต่ {new Date(profileData.memberSince).toLocaleDateString("th-TH")}
                    </span>
                  </div>
                </div>
              </div>

              <Button variant="outline" onClick={() => setIsEditing(!isEditing)} className="flex items-center">
                <Edit className="h-4 w-4 mr-2" />
                {isEditing ? "ยกเลิก" : "แก้ไขโปรไฟล์"}
              </Button>
            </div>
          </div>

          {/* Profile Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="overview" className="flex items-center">
                <User className="h-4 w-4 mr-2" />
                ภาพรวม
              </TabsTrigger>
              <TabsTrigger value="orders" className="flex items-center">
                <ShoppingBag className="h-4 w-4 mr-2" />
                คำสั่งซื้อ
              </TabsTrigger>
              <TabsTrigger value="profile" className="flex items-center">
                <Settings className="h-4 w-4 mr-2" />
                ข้อมูลส่วนตัว
              </TabsTrigger>
              <TabsTrigger value="security" className="flex items-center">
                <Shield className="h-4 w-4 mr-2" />
                ความปลอดภัย
              </TabsTrigger>
              <TabsTrigger value="notifications" className="flex items-center">
                <Bell className="h-4 w-4 mr-2" />
                การแจ้งเตือน
              </TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">คะแนนสะสม</p>
                        <p className="text-2xl font-bold text-blue-600">{profileData.loyaltyPoints.toLocaleString()}</p>
                      </div>
                      <Gift className="h-8 w-8 text-blue-600" />
                    </div>
                    <div className="mt-4">
                      <div className="flex justify-between text-sm mb-1">
                        <span>ถึงระดับถัดไป</span>
                        <span>
                          {profileData.loyaltyLevel === "Platinum"
                            ? "สูงสุด"
                            : `${5000 - profileData.loyaltyPoints} คะแนน`}
                        </span>
                      </div>
                      <Progress value={getLoyaltyProgress(profileData.loyaltyPoints)} className="h-2" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">จำนวนคำสั่งซื้อ</p>
                        <p className="text-2xl font-bold text-green-600">{profileData.totalOrders}</p>
                      </div>
                      <ShoppingBag className="h-8 w-8 text-green-600" />
                    </div>
                    <p className="text-xs text-gray-500 mt-2">คำสั่งซื้อทั้งหมด</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">ยอดซื้อรวม</p>
                        <p className="text-2xl font-bold text-purple-600">฿{profileData.totalSpent.toLocaleString()}</p>
                      </div>
                      <CreditCard className="h-8 w-8 text-purple-600" />
                    </div>
                    <p className="text-xs text-gray-500 mt-2">ตั้งแต่เป็นสมาชิก</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">ระดับสมาชิก</p>
                        <p className="text-2xl font-bold text-yellow-600">{profileData.loyaltyLevel}</p>
                      </div>
                      <Star className="h-8 w-8 text-yellow-600" />
                    </div>
                    <p className="text-xs text-gray-500 mt-2">สิทธิพิเศษมากมาย</p>
                  </CardContent>
                </Card>
              </div>

              {/* Recent Orders */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>คำสั่งซื้อล่าสุด</span>
                    <Link href="/orders">
                      <Button variant="outline" size="sm">
                        ดูทั้งหมด
                      </Button>
                    </Link>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {ordersData.slice(0, 3).map((order) => {
                      const StatusIcon = getOrderStatusIcon(order.status)
                      return (
                        <div key={order.id} className="flex items-center justify-between p-4 border rounded-lg">
                          <div className="flex items-center space-x-4">
                            <StatusIcon className="h-5 w-5 text-gray-400" />
                            <div>
                              <p className="font-medium">{order.id}</p>
                              <p className="text-sm text-gray-600">
                                {new Date(order.date).toLocaleDateString("th-TH")}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <Badge className={getOrderStatusColor(order.status)}>
                              {getOrderStatusText(order.status)}
                            </Badge>
                            <p className="text-sm font-medium mt-1">฿{order.total.toLocaleString()}</p>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>

              {/* Loyalty Benefits */}
              <Card>
                <CardHeader>
                  <CardTitle>สิทธิพิเศษสมาชิก {profileData.loyaltyLevel}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="h-5 w-5 text-green-600" />
                      <span>ส่วนลดพิเศษ 5-15%</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="h-5 w-5 text-green-600" />
                      <span>จัดส่งฟรีทุกคำสั่งซื้อ</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="h-5 w-5 text-green-600" />
                      <span>คะแนนสะสมเพิ่ม 2 เท่า</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="h-5 w-5 text-green-600" />
                      <span>เข้าถึงสินค้าใหม่ก่อนใคร</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Orders Tab */}
            <TabsContent value="orders" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>ประวัติคำสั่งซื้อ</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {ordersData.map((order) => {
                      const StatusIcon = getOrderStatusIcon(order.status)
                      return (
                        <div key={order.id} className="border rounded-lg p-6">
                          <div className="flex items-center justify-between mb-4">
                            <div className="flex items-center space-x-4">
                              <StatusIcon className="h-6 w-6 text-gray-400" />
                              <div>
                                <h3 className="font-semibold">{order.id}</h3>
                                <p className="text-sm text-gray-600">
                                  สั่งซื้อเมื่อ {new Date(order.date).toLocaleDateString("th-TH")}
                                </p>
                              </div>
                            </div>
                            <Badge className={getOrderStatusColor(order.status)}>
                              {getOrderStatusText(order.status)}
                            </Badge>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                            <div>
                              <span className="text-gray-600">จำนวนสินค้า:</span>
                              <span className="ml-2 font-medium">{order.items} รายการ</span>
                            </div>
                            <div>
                              <span className="text-gray-600">ยอดรวม:</span>
                              <span className="ml-2 font-medium">฿{order.total.toLocaleString()}</span>
                            </div>
                            <div>
                              <span className="text-gray-600">เลขติดตาม:</span>
                              <span className="ml-2 font-medium">{order.trackingNumber}</span>
                            </div>
                          </div>

                          <div className="flex justify-end space-x-2 mt-4">
                            <Button variant="outline" size="sm">
                              ดูรายละเอียด
                            </Button>
                            {order.status === "delivered" && (
                              <Button variant="outline" size="sm">
                                สั่งซื้อซ้ำ
                              </Button>
                            )}
                            {order.status === "processing" && (
                              <Button variant="outline" size="sm" className="text-red-600 bg-transparent">
                                ยกเลิกคำสั่งซื้อ
                              </Button>
                            )}
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Profile Tab */}
            <TabsContent value="profile" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>ข้อมูลส่วนตัว</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="firstName">ชื่อ</Label>
                        <Input
                          id="firstName"
                          value={profileData.firstName}
                          disabled={!isEditing}
                          onChange={(e) => setProfileData((prev) => ({ ...prev, firstName: e.target.value }))}
                        />
                      </div>
                      <div>
                        <Label htmlFor="lastName">นามสกุล</Label>
                        <Input
                          id="lastName"
                          value={profileData.lastName}
                          disabled={!isEditing}
                          onChange={(e) => setProfileData((prev) => ({ ...prev, lastName: e.target.value }))}
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="email">อีเมล</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="email"
                          value={profileData.email}
                          disabled={!isEditing}
                          className="pl-10"
                          onChange={(e) => setProfileData((prev) => ({ ...prev, email: e.target.value }))}
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="phone">เบอร์โทรศัพท์</Label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="phone"
                          value={profileData.phone}
                          disabled={!isEditing}
                          className="pl-10"
                          onChange={(e) => setProfileData((prev) => ({ ...prev, phone: e.target.value }))}
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="companyName">ชื่อบริษัท</Label>
                      <div className="relative">
                        <Building className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="companyName"
                          value={profileData.companyName}
                          disabled={!isEditing}
                          className="pl-10"
                          onChange={(e) => setProfileData((prev) => ({ ...prev, companyName: e.target.value }))}
                        />
                      </div>
                    </div>

                    {isEditing && (
                      <div className="flex space-x-2">
                        <Button className="bg-blue-600 hover:bg-blue-700">บันทึกการเปลี่ยนแปลง</Button>
                        <Button variant="outline" onClick={() => setIsEditing(false)}>
                          ยกเลิก
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>ที่อยู่</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="address">ที่อยู่</Label>
                      <div className="relative">
                        <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Textarea
                          id="address"
                          value={profileData.address.street}
                          disabled={!isEditing}
                          className="pl-10"
                          rows={3}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="district">เขต/อำเภอ</Label>
                        <Input id="district" value={profileData.address.district} disabled={!isEditing} />
                      </div>
                      <div>
                        <Label htmlFor="province">จังหวัด</Label>
                        <Input id="province" value={profileData.address.province} disabled={!isEditing} />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="postalCode">รหัสไปรษณีย์</Label>
                      <Input id="postalCode" value={profileData.address.postalCode} disabled={!isEditing} />
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Security Tab */}
            <TabsContent value="security" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>เปลี่ยนรหัสผ่าน</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="currentPassword">รหัสผ่านปัจจุบัน</Label>
                      <div className="relative">
                        <Key className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="currentPassword"
                          type={showCurrentPassword ? "text" : "password"}
                          className="pl-10 pr-10"
                        />
                        <button
                          type="button"
                          onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                          className="absolute right-3 top-3 text-gray-400 hover:text-gray-600"
                        >
                          {showCurrentPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="newPassword">รหัสผ่านใหม่</Label>
                      <div className="relative">
                        <Key className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input id="newPassword" type={showNewPassword ? "text" : "password"} className="pl-10 pr-10" />
                        <button
                          type="button"
                          onClick={() => setShowNewPassword(!showNewPassword)}
                          className="absolute right-3 top-3 text-gray-400 hover:text-gray-600"
                        >
                          {showNewPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="confirmPassword">ยืนยันรหัสผ่านใหม่</Label>
                      <div className="relative">
                        <Key className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="confirmPassword"
                          type={showConfirmPassword ? "text" : "password"}
                          className="pl-10 pr-10"
                        />
                        <button
                          type="button"
                          onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                          className="absolute right-3 top-3 text-gray-400 hover:text-gray-600"
                        >
                          {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>
                    </div>

                    <Button className="w-full">เปลี่ยนรหัสผ่าน</Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>การตั้งค่าความปลอดภัย</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">การยืนยันตัวตนสองขั้นตอน</h4>
                        <p className="text-sm text-gray-600">เพิ่มความปลอดภัยให้กับบัญชีของคุณ</p>
                      </div>
                      <Switch
                        checked={securitySettings.twoFactorAuth}
                        onCheckedChange={(checked) =>
                          setSecuritySettings((prev) => ({ ...prev, twoFactorAuth: checked }))
                        }
                      />
                    </div>

                    <Separator />

                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">แจ้งเตือนการเข้าสู่ระบบ</h4>
                        <p className="text-sm text-gray-600">รับแจ้งเตือนเมื่อมีการเข้าสู่ระบบใหม่</p>
                      </div>
                      <Switch
                        checked={securitySettings.loginAlerts}
                        onCheckedChange={(checked) =>
                          setSecuritySettings((prev) => ({ ...prev, loginAlerts: checked }))
                        }
                      />
                    </div>

                    <Separator />

                    <div>
                      <h4 className="font-medium mb-2">ระยะเวลาหมดอายุเซสชัน</h4>
                      <select
                        className="w-full p-2 border rounded-md"
                        value={securitySettings.sessionTimeout}
                        onChange={(e) => setSecuritySettings((prev) => ({ ...prev, sessionTimeout: e.target.value }))}
                      >
                        <option value="15">15 นาที</option>
                        <option value="30">30 นาที</option>
                        <option value="60">1 ชั่วโมง</option>
                        <option value="240">4 ชั่วโมง</option>
                      </select>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Active Sessions */}
              <Card>
                <CardHeader>
                  <CardTitle>เซสชันที่ใช้งานอยู่</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {sessionsData.map((session) => {
                      const DeviceIcon = session.icon
                      return (
                        <div key={session.id} className="flex items-center justify-between p-4 border rounded-lg">
                          <div className="flex items-center space-x-4">
                            <DeviceIcon className="h-6 w-6 text-gray-400" />
                            <div>
                              <p className="font-medium">{session.device}</p>
                              <p className="text-sm text-gray-600">{session.location}</p>
                              <p className="text-xs text-gray-500">ใช้งานล่าสุด: {session.lastActive}</p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            {session.current && <Badge variant="secondary">เซสชันปัจจุบัน</Badge>}
                            {!session.current && (
                              <Button variant="outline" size="sm">
                                <LogOut className="h-4 w-4 mr-1" />
                                ออกจากระบบ
                              </Button>
                            )}
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Notifications Tab */}
            <TabsContent value="notifications" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>การตั้งค่าการแจ้งเตือน</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">อัพเดทคำสั่งซื้อ</h4>
                      <p className="text-sm text-gray-600">รับแจ้งเตือนเกี่ยวกับสถานะคำสั่งซื้อ</p>
                    </div>
                    <Switch
                      checked={notifications.orderUpdates}
                      onCheckedChange={(checked) => setNotifications((prev) => ({ ...prev, orderUpdates: checked }))}
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">โปรโมชั่นและข้อเสนอพิเศษ</h4>
                      <p className="text-sm text-gray-600">รับข้อมูลส่วนลดและโปรโมชั่น</p>
                    </div>
                    <Switch
                      checked={notifications.promotions}
                      onCheckedChange={(checked) => setNotifications((prev) => ({ ...prev, promotions: checked }))}
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">จดหมายข่าว</h4>
                      <p className="text-sm text-gray-600">รับข่าวสารและบทความเกี่ยวกับผลิตภัณฑ์</p>
                    </div>
                    <Switch
                      checked={notifications.newsletter}
                      onCheckedChange={(checked) => setNotifications((prev) => ({ ...prev, newsletter: checked }))}
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">แจ้งเตือนราคา</h4>
                      <p className="text-sm text-gray-600">แจ้งเตือนเมื่อสินค้าในรายการโปรดลดราคา</p>
                    </div>
                    <Switch
                      checked={notifications.priceAlerts}
                      onCheckedChange={(checked) => setNotifications((prev) => ({ ...prev, priceAlerts: checked }))}
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">แจ้งเตือนสต็อกสินค้า</h4>
                      <p className="text-sm text-gray-600">แจ้งเตือนเมื่อสินค้าที่หมดสต็อกกลับมามีจำหน่าย</p>
                    </div>
                    <Switch
                      checked={notifications.stockAlerts}
                      onCheckedChange={(checked) => setNotifications((prev) => ({ ...prev, stockAlerts: checked }))}
                    />
                  </div>

                  <Separator />

                  <h3 className="text-lg font-semibold">ช่องทางการแจ้งเตือน</h3>

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">SMS</h4>
                      <p className="text-sm text-gray-600">รับการแจ้งเตือนผ่านข้อความ</p>
                    </div>
                    <Switch
                      checked={notifications.sms}
                      onCheckedChange={(checked) => setNotifications((prev) => ({ ...prev, sms: checked }))}
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Push Notifications</h4>
                      <p className="text-sm text-gray-600">รับการแจ้งเตือนผ่านเบราว์เซอร์</p>
                    </div>
                    <Switch
                      checked={notifications.push}
                      onCheckedChange={(checked) => setNotifications((prev) => ({ ...prev, push: checked }))}
                    />
                  </div>

                  <div className="pt-4">
                    <Button className="w-full">บันทึกการตั้งค่า</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </section>
    </div>
  )
}
