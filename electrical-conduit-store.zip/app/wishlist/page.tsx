"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Progress } from "@/components/ui/progress"
import {
  Factory,
  Heart,
  ShoppingCart,
  Search,
  Grid3X3,
  List,
  Trash2,
  Share2,
  Bell,
  TrendingDown,
  TrendingUp,
  Package,
  AlertTriangle,
  CheckCircle,
  XCircle,
  BarChart3,
  Eye,
} from "lucide-react"

// Mock wishlist data
const wishlistData = [
  {
    id: "1",
    name: "ท่อร้อยสายไฟ PVC ขนาด 1/2 นิ้ว",
    brand: "O-Z/Gedney",
    sku: "PVC-12-100",
    currentPrice: 45,
    originalPrice: 50,
    priceChange: -10,
    priceHistory: [50, 48, 47, 45],
    image: "/placeholder.svg?height=200&width=200&text=PVC+Conduit",
    category: "ท่อร้อยสาย",
    inStock: true,
    stockLevel: 150,
    lowStockThreshold: 20,
    dateAdded: "2024-01-15",
    priceAlert: true,
    stockAlert: true,
    targetPrice: 40,
    rating: 4.5,
    reviews: 28,
  },
  {
    id: "2",
    name: "กล่องพักสาย 4x4 นิ้ว",
    brand: "O-Z/Gedney",
    sku: "BOX-44-STD",
    currentPrice: 85,
    originalPrice: 85,
    priceChange: 0,
    priceHistory: [85, 85, 85, 85],
    image: "/placeholder.svg?height=200&width=200&text=Junction+Box",
    category: "กล่องพักสาย",
    inStock: false,
    stockLevel: 0,
    lowStockThreshold: 10,
    dateAdded: "2024-01-10",
    priceAlert: false,
    stockAlert: true,
    targetPrice: 75,
    rating: 4.8,
    reviews: 42,
  },
  {
    id: "3",
    name: "ข้อต่อท่อ 90 องศา ขนาด 3/4 นิ้ว",
    brand: "O-Z/Gedney",
    sku: "ELB-34-90",
    currentPrice: 25,
    originalPrice: 30,
    priceChange: -16.7,
    priceHistory: [30, 28, 26, 25],
    image: "/placeholder.svg?height=200&width=200&text=Elbow+Connector",
    category: "ข้อต่อ",
    inStock: true,
    stockLevel: 8,
    lowStockThreshold: 15,
    dateAdded: "2024-01-05",
    priceAlert: true,
    stockAlert: true,
    targetPrice: 22,
    rating: 4.3,
    reviews: 15,
  },
  {
    id: "4",
    name: "สายไฟ THW ขนาด 2.5 ตร.มม.",
    brand: "Thai Yazaki",
    sku: "THW-25-100M",
    currentPrice: 1250,
    originalPrice: 1200,
    priceChange: 4.2,
    priceHistory: [1200, 1220, 1240, 1250],
    image: "/placeholder.svg?height=200&width=200&text=THW+Wire",
    category: "สายไฟ",
    inStock: true,
    stockLevel: 25,
    lowStockThreshold: 10,
    dateAdded: "2024-01-01",
    priceAlert: false,
    stockAlert: false,
    targetPrice: 1150,
    rating: 4.7,
    reviews: 67,
  },
]

export default function WishlistPage() {
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [selectedItems, setSelectedItems] = useState<string[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [sortBy, setSortBy] = useState("dateAdded")
  const [filterCategory, setFilterCategory] = useState("all")
  const [filterStock, setFilterStock] = useState("all")
  const [filterAlerts, setFilterAlerts] = useState("all")
  const [showPriceHistory, setShowPriceHistory] = useState<string | null>(null)

  const filteredItems = wishlistData.filter((item) => {
    const matchesSearch =
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.sku.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesCategory = filterCategory === "all" || item.category === filterCategory

    const matchesStock =
      filterStock === "all" ||
      (filterStock === "inStock" && item.inStock) ||
      (filterStock === "outOfStock" && !item.inStock) ||
      (filterStock === "lowStock" && item.inStock && item.stockLevel <= item.lowStockThreshold)

    const matchesAlerts =
      filterAlerts === "all" ||
      (filterAlerts === "priceAlert" && item.priceAlert) ||
      (filterAlerts === "stockAlert" && item.stockAlert)

    return matchesSearch && matchesCategory && matchesStock && matchesAlerts
  })

  const sortedItems = [...filteredItems].sort((a, b) => {
    switch (sortBy) {
      case "name":
        return a.name.localeCompare(b.name)
      case "price":
        return a.currentPrice - b.currentPrice
      case "priceChange":
        return b.priceChange - a.priceChange
      case "dateAdded":
        return new Date(b.dateAdded).getTime() - new Date(a.dateAdded).getTime()
      default:
        return 0
    }
  })

  const handleSelectAll = () => {
    if (selectedItems.length === sortedItems.length) {
      setSelectedItems([])
    } else {
      setSelectedItems(sortedItems.map((item) => item.id))
    }
  }

  const handleSelectItem = (itemId: string) => {
    setSelectedItems((prev) => (prev.includes(itemId) ? prev.filter((id) => id !== itemId) : [...prev, itemId]))
  }

  const handleBulkAddToCart = () => {
    const selectedProducts = sortedItems.filter((item) => selectedItems.includes(item.id))
    console.log("Adding to cart:", selectedProducts)
    // Here you would typically add items to cart
  }

  const handleBulkRemove = () => {
    console.log("Removing items:", selectedItems)
    // Here you would typically remove items from wishlist
    setSelectedItems([])
  }

  const handleTogglePriceAlert = (itemId: string) => {
    console.log("Toggle price alert for:", itemId)
    // Here you would typically update the price alert setting
  }

  const handleToggleStockAlert = (itemId: string) => {
    console.log("Toggle stock alert for:", itemId)
    // Here you would typically update the stock alert setting
  }

  const handleSetTargetPrice = (itemId: string, targetPrice: number) => {
    console.log("Set target price:", itemId, targetPrice)
    // Here you would typically update the target price
  }

  const getPriceChangeColor = (change: number) => {
    if (change > 0) return "text-red-600"
    if (change < 0) return "text-green-600"
    return "text-gray-600"
  }

  const getPriceChangeIcon = (change: number) => {
    if (change > 0) return TrendingUp
    if (change < 0) return TrendingDown
    return null
  }

  const getStockStatus = (item: any) => {
    if (!item.inStock) return { text: "หมดสต็อก", color: "text-red-600 bg-red-50", icon: XCircle }
    if (item.stockLevel <= item.lowStockThreshold)
      return { text: "สต็อกต่ำ", color: "text-yellow-600 bg-yellow-50", icon: AlertTriangle }
    return { text: "มีสต็อก", color: "text-green-600 bg-green-50", icon: CheckCircle }
  }

  const categories = [...new Set(wishlistData.map((item) => item.category))]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <Factory className="h-6 w-6 text-white" />
              </div>
              <div>
                <div className="text-xl font-bold text-gray-900">O-Z/Gedney</div>
                <div className="text-xs text-gray-500">อุปกรณ์ไฟฟ้า</div>
              </div>
            </Link>

            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-gray-700 hover:text-blue-600">
                หน้าแรก
              </Link>
              <Link href="/categories" className="text-gray-700 hover:text-blue-600">
                สินค้า
              </Link>
              <Link href="/cart" className="text-gray-700 hover:text-blue-600">
                ตะกร้า
              </Link>
              <Link href="/profile" className="text-gray-700 hover:text-blue-600">
                โปรไฟล์
              </Link>
            </nav>

            <div className="flex items-center space-x-4">
              <Link href="/admin">
                <Button variant="outline">แอดมิน</Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Wishlist Content */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Page Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center">
                <Heart className="h-8 w-8 mr-3 text-red-500" />
                รายการโปรด
              </h1>
              <p className="text-gray-600 mt-2">จัดการสินค้าที่คุณสนใจ ติดตามราคา และรับแจ้งเตือนเมื่อมีการเปลี่ยนแปลง</p>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="outline" className="flex items-center bg-transparent">
                <Share2 className="h-4 w-4 mr-2" />
                แชร์รายการ
              </Button>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">รายการทั้งหมด</p>
                    <p className="text-2xl font-bold text-blue-600">{wishlistData.length}</p>
                  </div>
                  <Heart className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">ราคาลดลง</p>
                    <p className="text-2xl font-bold text-green-600">
                      {wishlistData.filter((item) => item.priceChange < 0).length}
                    </p>
                  </div>
                  <TrendingDown className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">หมดสต็อก</p>
                    <p className="text-2xl font-bold text-red-600">
                      {wishlistData.filter((item) => !item.inStock).length}
                    </p>
                  </div>
                  <Package className="h-8 w-8 text-red-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">แจ้งเตือนราคา</p>
                    <p className="text-2xl font-bold text-purple-600">
                      {wishlistData.filter((item) => item.priceAlert).length}
                    </p>
                  </div>
                  <Bell className="h-8 w-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Controls */}
          <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
              {/* Search and Filters */}
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 flex-1">
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="ค้นหาสินค้า..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>

                <Select value={filterCategory} onValueChange={setFilterCategory}>
                  <SelectTrigger className="w-full sm:w-48">
                    <SelectValue placeholder="หมวดหมู่" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">ทุกหมวดหมู่</SelectItem>
                    {categories.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={filterStock} onValueChange={setFilterStock}>
                  <SelectTrigger className="w-full sm:w-48">
                    <SelectValue placeholder="สถานะสต็อก" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">ทุกสถานะ</SelectItem>
                    <SelectItem value="inStock">มีสต็อก</SelectItem>
                    <SelectItem value="lowStock">สต็อกต่ำ</SelectItem>
                    <SelectItem value="outOfStock">หมดสต็อก</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={filterAlerts} onValueChange={setFilterAlerts}>
                  <SelectTrigger className="w-full sm:w-48">
                    <SelectValue placeholder="การแจ้งเตือน" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">ทั้งหมด</SelectItem>
                    <SelectItem value="priceAlert">แจ้งเตือนราคา</SelectItem>
                    <SelectItem value="stockAlert">แจ้งเตือนสต็อก</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Sort and View Controls */}
              <div className="flex items-center space-x-4">
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="เรียงตาม" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="dateAdded">วันที่เพิ่ม</SelectItem>
                    <SelectItem value="name">ชื่อสินค้า</SelectItem>
                    <SelectItem value="price">ราคา</SelectItem>
                    <SelectItem value="priceChange">การเปลี่ยนแปลงราคา</SelectItem>
                  </SelectContent>
                </Select>

                <div className="flex items-center space-x-2">
                  <Button
                    variant={viewMode === "grid" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setViewMode("grid")}
                  >
                    <Grid3X3 className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={viewMode === "list" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setViewMode("list")}
                  >
                    <List className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Bulk Actions */}
            {selectedItems.length > 0 && (
              <div className="flex items-center justify-between mt-4 pt-4 border-t">
                <div className="flex items-center space-x-4">
                  <Checkbox checked={selectedItems.length === sortedItems.length} onCheckedChange={handleSelectAll} />
                  <span className="text-sm text-gray-600">เลือกแล้ว {selectedItems.length} รายการ</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Button onClick={handleBulkAddToCart} className="bg-blue-600 hover:bg-blue-700">
                    <ShoppingCart className="h-4 w-4 mr-2" />
                    เพิ่มลงตะกร้า
                  </Button>
                  <Button
                    variant="outline"
                    onClick={handleBulkRemove}
                    className="text-red-600 hover:text-red-700 bg-transparent"
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    ลบออก
                  </Button>
                </div>
              </div>
            )}
          </div>

          {/* Wishlist Items */}
          <div
            className={`grid gap-6 ${
              viewMode === "grid" ? "grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4" : "grid-cols-1"
            }`}
          >
            {sortedItems.map((item) => {
              const stockStatus = getStockStatus(item)
              const PriceChangeIcon = getPriceChangeIcon(item.priceChange)
              const isSelected = selectedItems.includes(item.id)

              return (
                <Card key={item.id} className={`overflow-hidden ${isSelected ? "ring-2 ring-blue-500" : ""}`}>
                  <CardContent className="p-0">
                    {viewMode === "grid" ? (
                      // Grid View
                      <div>
                        {/* Image and Selection */}
                        <div className="relative">
                          <Image
                            src={item.image || "/placeholder.svg"}
                            alt={item.name}
                            width={200}
                            height={200}
                            className="w-full h-48 object-cover"
                          />
                          <div className="absolute top-2 left-2">
                            <Checkbox checked={isSelected} onCheckedChange={() => handleSelectItem(item.id)} />
                          </div>
                          <div className="absolute top-2 right-2 flex space-x-1">
                            {item.priceAlert && (
                              <Badge className="bg-blue-600 text-white">
                                <Bell className="h-3 w-3" />
                              </Badge>
                            )}
                            {item.stockAlert && (
                              <Badge className="bg-purple-600 text-white">
                                <Package className="h-3 w-3" />
                              </Badge>
                            )}
                          </div>
                          {item.priceChange !== 0 && (
                            <div className="absolute bottom-2 left-2">
                              <Badge className={`${getPriceChangeColor(item.priceChange)} bg-white`}>
                                {PriceChangeIcon && <PriceChangeIcon className="h-3 w-3 mr-1" />}
                                {item.priceChange > 0 ? "+" : ""}
                                {item.priceChange.toFixed(1)}%
                              </Badge>
                            </div>
                          )}
                        </div>

                        {/* Content */}
                        <div className="p-4">
                          <div className="flex items-start justify-between mb-2">
                            <Badge variant="outline" className="text-xs">
                              {item.category}
                            </Badge>
                            <Badge className={stockStatus.color}>
                              <stockStatus.icon className="h-3 w-3 mr-1" />
                              {stockStatus.text}
                            </Badge>
                          </div>

                          <h3 className="font-semibold text-gray-900 mb-1 line-clamp-2">{item.name}</h3>
                          <p className="text-sm text-gray-600 mb-2">
                            {item.brand} • {item.sku}
                          </p>

                          <div className="flex items-center justify-between mb-3">
                            <div>
                              <span className="text-lg font-bold text-blue-600">
                                ฿{item.currentPrice.toLocaleString()}
                              </span>
                              {item.originalPrice !== item.currentPrice && (
                                <span className="text-sm text-gray-500 line-through ml-2">
                                  ฿{item.originalPrice.toLocaleString()}
                                </span>
                              )}
                            </div>
                            <div className="flex items-center text-sm text-gray-600">
                              <span className="text-yellow-500">★</span>
                              <span className="ml-1">{item.rating}</span>
                              <span className="ml-1">({item.reviews})</span>
                            </div>
                          </div>

                          {/* Target Price */}
                          {item.targetPrice && (
                            <div className="mb-3">
                              <div className="flex items-center justify-between text-sm">
                                <span className="text-gray-600">เป้าหมายราคา:</span>
                                <span className="font-medium">฿{item.targetPrice.toLocaleString()}</span>
                              </div>
                              <Progress
                                value={Math.max(
                                  0,
                                  Math.min(
                                    100,
                                    ((item.originalPrice - item.currentPrice) /
                                      (item.originalPrice - item.targetPrice)) *
                                      100,
                                  ),
                                )}
                                className="h-2 mt-1"
                              />
                            </div>
                          )}

                          {/* Actions */}
                          <div className="flex space-x-2">
                            <Button size="sm" className="flex-1 bg-blue-600 hover:bg-blue-700" disabled={!item.inStock}>
                              <ShoppingCart className="h-4 w-4 mr-1" />
                              {item.inStock ? "เพิ่มลงตะกร้า" : "หมดสต็อก"}
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setShowPriceHistory(showPriceHistory === item.id ? null : item.id)}
                            >
                              <BarChart3 className="h-4 w-4" />
                            </Button>
                          </div>

                          {/* Price History */}
                          {showPriceHistory === item.id && (
                            <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                              <h4 className="text-sm font-medium mb-2">ประวัติราคา</h4>
                              <div className="space-y-1">
                                {item.priceHistory.map((price, index) => (
                                  <div key={index} className="flex justify-between text-sm">
                                    <span>{index + 1} สัปดาห์ที่แล้ว</span>
                                    <span>฿{price.toLocaleString()}</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          {/* Alert Settings */}
                          <div className="mt-4 pt-3 border-t space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="text-sm text-gray-600">แจ้งเตือนราคา</span>
                              <Switch
                                checked={item.priceAlert}
                                onCheckedChange={() => handleTogglePriceAlert(item.id)}
                                size="sm"
                              />
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-sm text-gray-600">แจ้งเตือนสต็อก</span>
                              <Switch
                                checked={item.stockAlert}
                                onCheckedChange={() => handleToggleStockAlert(item.id)}
                                size="sm"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    ) : (
                      // List View
                      <div className="flex items-center p-4 space-x-4">
                        <Checkbox checked={isSelected} onCheckedChange={() => handleSelectItem(item.id)} />

                        <Image
                          src={item.image || "/placeholder.svg"}
                          alt={item.name}
                          width={80}
                          height={80}
                          className="w-20 h-20 object-cover rounded-lg"
                        />

                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <h3 className="font-semibold text-gray-900 mb-1">{item.name}</h3>
                              <p className="text-sm text-gray-600 mb-2">
                                {item.brand} • {item.sku}
                              </p>
                              <div className="flex items-center space-x-4 text-sm text-gray-600">
                                <Badge variant="outline">{item.category}</Badge>
                                <Badge className={stockStatus.color}>
                                  <stockStatus.icon className="h-3 w-3 mr-1" />
                                  {stockStatus.text}
                                </Badge>
                                <span>เพิ่มเมื่อ {new Date(item.dateAdded).toLocaleDateString("th-TH")}</span>
                              </div>
                            </div>

                            <div className="text-right ml-4">
                              <div className="flex items-center space-x-2 mb-2">
                                <span className="text-lg font-bold text-blue-600">
                                  ฿{item.currentPrice.toLocaleString()}
                                </span>
                                {item.originalPrice !== item.currentPrice && (
                                  <span className="text-sm text-gray-500 line-through">
                                    ฿{item.originalPrice.toLocaleString()}
                                  </span>
                                )}
                                {item.priceChange !== 0 && PriceChangeIcon && (
                                  <Badge className={`${getPriceChangeColor(item.priceChange)} bg-white`}>
                                    <PriceChangeIcon className="h-3 w-3 mr-1" />
                                    {item.priceChange > 0 ? "+" : ""}
                                    {item.priceChange.toFixed(1)}%
                                  </Badge>
                                )}
                              </div>
                              <div className="flex items-center text-sm text-gray-600 mb-2">
                                <span className="text-yellow-500">★</span>
                                <span className="ml-1">
                                  {item.rating} ({item.reviews})
                                </span>
                              </div>
                              <div className="flex space-x-2">
                                <Button size="sm" className="bg-blue-600 hover:bg-blue-700" disabled={!item.inStock}>
                                  <ShoppingCart className="h-4 w-4 mr-1" />
                                  {item.inStock ? "เพิ่มลงตะกร้า" : "หมดสต็อก"}
                                </Button>
                                <Button size="sm" variant="outline">
                                  <Eye className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )
            })}
          </div>

          {/* Empty State */}
          {sortedItems.length === 0 && (
            <div className="text-center py-12">
              <Heart className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">ไม่พบสินค้าในรายการโปรด</h3>
              <p className="text-gray-600 mb-6">
                {searchQuery || filterCategory !== "all" || filterStock !== "all" || filterAlerts !== "all"
                  ? "ลองปรับเปลี่ยนตัวกรองหรือคำค้นหา"
                  : "เริ่มเพิ่มสินค้าที่คุณสนใจลงในรายการโปรด"}
              </p>
              <Link href="/categories">
                <Button className="bg-blue-600 hover:bg-blue-700">เลือกซื้อสินค้า</Button>
              </Link>
            </div>
          )}
        </div>
      </section>
    </div>
  )
}
