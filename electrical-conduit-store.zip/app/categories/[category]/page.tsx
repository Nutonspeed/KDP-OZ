"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Search,
  ShoppingCart,
  Star,
  Grid,
  List,
  ArrowLeft,
  Zap,
  Package,
  AlertTriangle,
  CheckCircle,
  Info,
  TrendingUp,
  Award,
  Shield,
} from "lucide-react"

// Complete product data
const allProductData = {
  "malleable-iron-lb": {
    name: "Malleable Iron Conduit Bodies HDG - LB Series",
    description:
      "Heavy-duty malleable iron conduit bodies with hot-dip galvanized finish for superior corrosion resistance",
    products: [
      {
        code: "LB-50G",
        name: "Malleable Iron Conduit Body LB-50G",
        size: '1/2"',
        qty: 484,
        price: 300.0,
        originalPrice: 350.0,
        type: "LB Body",
        material: "Malleable Iron HDG",
        thread: "NPT",
        application: "General Purpose",
        rating: "NEMA 3R",
        weight: "0.8 lbs",
        image: "/placeholder.svg?height=200&width=200&text=LB-50G",
        inStock: true,
        discount: 14,
        reviews: 45,
        avgRating: 4.8,
        features: ["Hot-dip galvanized", "Corrosion resistant", "NPT threaded", "NEMA 3R rated"],
      },
      {
        code: "LB-75G",
        name: "Malleable Iron Conduit Body LB-75G",
        size: '3/4"',
        qty: 552,
        price: 360.0,
        originalPrice: 400.0,
        type: "LB Body",
        material: "Malleable Iron HDG",
        thread: "NPT",
        application: "General Purpose",
        rating: "NEMA 3R",
        weight: "1.2 lbs",
        image: "/placeholder.svg?height=200&width=200&text=LB-75G",
        inStock: true,
        discount: 10,
        reviews: 67,
        avgRating: 4.9,
        features: ["Hot-dip galvanized", "Corrosion resistant", "NPT threaded", "NEMA 3R rated"],
      },
      {
        code: "LB-100G",
        name: "Malleable Iron Conduit Body LB-100G",
        size: '1"',
        qty: 125,
        price: 560.0,
        originalPrice: 620.0,
        type: "LB Body",
        material: "Malleable Iron HDG",
        thread: "NPT",
        application: "General Purpose",
        rating: "NEMA 3R",
        weight: "1.8 lbs",
        image: "/placeholder.svg?height=200&width=200&text=LB-100G",
        inStock: true,
        discount: 10,
        reviews: 34,
        avgRating: 4.7,
        features: ["Hot-dip galvanized", "Corrosion resistant", "NPT threaded", "NEMA 3R rated"],
      },
      {
        code: "LB-125G",
        name: "Malleable Iron Conduit Body LB-125G",
        size: '1-1/4"',
        qty: 677,
        price: 900.0,
        originalPrice: 1000.0,
        type: "LB Body",
        material: "Malleable Iron HDG",
        thread: "NPT",
        application: "General Purpose",
        rating: "NEMA 3R",
        weight: "2.5 lbs",
        image: "/placeholder.svg?height=200&width=200&text=LB-125G",
        inStock: true,
        discount: 10,
        reviews: 28,
        avgRating: 4.8,
        features: ["Hot-dip galvanized", "Corrosion resistant", "NPT threaded", "NEMA 3R rated"],
      },
      {
        code: "LB-150G",
        name: "Malleable Iron Conduit Body LB-150G",
        size: '1-1/2"',
        qty: 964,
        price: 1000.0,
        originalPrice: 1150.0,
        type: "LB Body",
        material: "Malleable Iron HDG",
        thread: "NPT",
        application: "General Purpose",
        rating: "NEMA 3R",
        weight: "3.2 lbs",
        image: "/placeholder.svg?height=200&width=200&text=LB-150G",
        inStock: true,
        discount: 13,
        reviews: 52,
        avgRating: 4.9,
        features: ["Hot-dip galvanized", "Corrosion resistant", "NPT threaded", "NEMA 3R rated"],
      },
      {
        code: "LB-200G",
        name: "Malleable Iron Conduit Body LB-200G",
        size: '2"',
        qty: 414,
        price: 1500.0,
        originalPrice: 1700.0,
        type: "LB Body",
        material: "Malleable Iron HDG",
        thread: "NPT",
        application: "General Purpose",
        rating: "NEMA 3R",
        weight: "5.1 lbs",
        image: "/placeholder.svg?height=200&width=200&text=LB-200G",
        inStock: true,
        discount: 12,
        reviews: 31,
        avgRating: 4.8,
        features: ["Hot-dip galvanized", "Corrosion resistant", "NPT threaded", "NEMA 3R rated"],
      },
      {
        code: "LB-250G",
        name: "Malleable Iron Conduit Body LB-250G",
        size: '2-1/2"',
        qty: 10,
        price: 2300.0,
        originalPrice: 2600.0,
        type: "LB Body",
        material: "Malleable Iron HDG",
        thread: "NPT",
        application: "Heavy Duty",
        rating: "NEMA 3R",
        weight: "8.2 lbs",
        image: "/placeholder.svg?height=200&width=200&text=LB-250G",
        inStock: true,
        discount: 12,
        reviews: 15,
        avgRating: 4.7,
        features: ["Hot-dip galvanized", "Heavy duty construction", "NPT threaded", "NEMA 3R rated"],
        lowStock: true,
      },
      {
        code: "LB-300G",
        name: "Malleable Iron Conduit Body LB-300G",
        size: '3"',
        qty: 41,
        price: 3000.0,
        originalPrice: 3400.0,
        type: "LB Body",
        material: "Malleable Iron HDG",
        thread: "NPT",
        application: "Heavy Duty",
        rating: "NEMA 3R",
        weight: "12.5 lbs",
        image: "/placeholder.svg?height=200&width=200&text=LB-300G",
        inStock: true,
        discount: 12,
        reviews: 8,
        avgRating: 4.6,
        features: ["Hot-dip galvanized", "Heavy duty construction", "NPT threaded", "NEMA 3R rated"],
      },
      {
        code: "LB-400G",
        name: "Malleable Iron Conduit Body LB-400G",
        size: '4"',
        qty: 42,
        price: 4500.0,
        originalPrice: 5000.0,
        type: "LB Body",
        material: "Malleable Iron HDG",
        thread: "NPT",
        application: "Heavy Duty",
        rating: "NEMA 3R",
        weight: "18.7 lbs",
        image: "/placeholder.svg?height=200&width=200&text=LB-400G",
        inStock: true,
        discount: 10,
        reviews: 12,
        avgRating: 4.8,
        features: ["Hot-dip galvanized", "Heavy duty construction", "NPT threaded", "NEMA 3R rated"],
      },
    ],
  },
  covers: {
    name: "Conduit Body Covers - Flat Top & Domed",
    description: "High-quality covers for conduit bodies with flat top and domed designs",
    products: [
      {
        code: "BC-50G",
        name: "Flat Top Cover BC-50G",
        size: '1/2"',
        qty: 1124,
        price: 200.0,
        originalPrice: 230.0,
        type: "Flat Top Cover",
        material: "Malleable Iron HDG",
        thread: "Compatible",
        application: "Weather Protection",
        rating: "NEMA 3R",
        weight: "0.3 lbs",
        image: "/placeholder.svg?height=200&width=200&text=BC-50G",
        inStock: true,
        discount: 13,
        reviews: 89,
        avgRating: 4.7,
        features: ["Weather resistant", "Flat top design", "Easy installation", "NEMA 3R rated"],
      },
      {
        code: "BC-75G",
        name: "Flat Top Cover BC-75G",
        size: '3/4"',
        qty: 3734,
        price: 215.0,
        originalPrice: 250.0,
        type: "Flat Top Cover",
        material: "Malleable Iron HDG",
        thread: "Compatible",
        application: "Weather Protection",
        rating: "NEMA 3R",
        weight: "0.4 lbs",
        image: "/placeholder.svg?height=200&width=200&text=BC-75G",
        inStock: true,
        discount: 14,
        reviews: 156,
        avgRating: 4.8,
        features: ["Weather resistant", "Flat top design", "Easy installation", "NEMA 3R rated"],
      },
      {
        code: "BC-125G",
        name: "Flat Top Cover BC-125G",
        size: '1-1/4"',
        qty: 3489,
        price: 395.0,
        originalPrice: 450.0,
        type: "Flat Top Cover",
        material: "Malleable Iron HDG",
        thread: "Compatible",
        application: "Weather Protection",
        rating: "NEMA 3R",
        weight: "0.7 lbs",
        image: "/placeholder.svg?height=200&width=200&text=BC-125G",
        inStock: true,
        discount: 12,
        reviews: 78,
        avgRating: 4.6,
        features: ["Weather resistant", "Flat top design", "Easy installation", "NEMA 3R rated"],
      },
      {
        code: "BS-75S",
        name: "Domed Top Cover BS-75S",
        size: '3/4"',
        qty: 705,
        price: 215.0,
        originalPrice: 250.0,
        type: "Domed Top Cover",
        material: "Malleable Iron",
        thread: "Compatible",
        application: "Enhanced Protection",
        rating: "NEMA 3R",
        weight: "0.4 lbs",
        image: "/placeholder.svg?height=200&width=200&text=BS-75S",
        inStock: true,
        discount: 14,
        reviews: 45,
        avgRating: 4.9,
        features: ["Enhanced protection", "Domed design", "Water shedding", "NEMA 3R rated"],
      },
    ],
  },
  // Add more categories as needed...
}

export default function CategoryPage() {
  const params = useParams()
  const categoryKey = params.category as string
  const [products, setProducts] = useState<any[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [sortBy, setSortBy] = useState("name")
  const [viewMode, setViewMode] = useState("grid")
  const [priceRange, setPriceRange] = useState("all")
  const [sizeFilter, setSizeFilter] = useState("all")
  const [cartItems, setCartItems] = useState(0)

  const categoryData = allProductData[categoryKey as keyof typeof allProductData]

  useEffect(() => {
    if (categoryData) {
      setProducts(categoryData.products)
    }
  }, [categoryData])

  // Filter and sort products
  useEffect(() => {
    if (!categoryData) return

    const filtered = categoryData.products.filter((product: any) => {
      const matchesSearch =
        product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.code.toLowerCase().includes(searchTerm.toLowerCase())

      const matchesPrice =
        priceRange === "all" ||
        (priceRange === "low" && product.price < 500) ||
        (priceRange === "medium" && product.price >= 500 && product.price < 1500) ||
        (priceRange === "high" && product.price >= 1500)

      const matchesSize = sizeFilter === "all" || product.size === sizeFilter

      return matchesSearch && matchesPrice && matchesSize
    })

    // Sort products
    filtered.sort((a: any, b: any) => {
      switch (sortBy) {
        case "price-low":
          return a.price - b.price
        case "price-high":
          return b.price - a.price
        case "rating":
          return b.avgRating - a.avgRating
        case "reviews":
          return b.reviews - a.reviews
        case "stock":
          return b.qty - a.qty
        default:
          return a.name.localeCompare(b.name)
      }
    })

    setProducts(filtered)
  }, [searchTerm, sortBy, priceRange, sizeFilter, categoryData])

  const addToCart = (productId: string) => {
    setCartItems((prev) => prev + 1)
    // In real app, would add to cart state/context
  }

  if (!categoryData) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Package className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-2">ไม่พบหมวดหมู่นี้</h1>
          <p className="text-gray-600 mb-4">หมวดหมู่ที่คุณค้นหาไม่มีในระบบ</p>
          <Link href="/categories">
            <Button>
              <ArrowLeft className="h-4 w-4 mr-2" />
              กลับไปหมวดหมู่
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  const ProductCard = ({ product }: { product: any }) => (
    <Card className="group hover:shadow-lg transition-shadow duration-300">
      <CardHeader className="p-0">
        <div className="relative overflow-hidden rounded-t-lg">
          <img
            src={product.image || "/placeholder.svg"}
            alt={product.name}
            className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
          />
          {product.discount > 0 && (
            <Badge className="absolute top-2 left-2 bg-red-500 text-white">-{product.discount}%</Badge>
          )}
          {product.lowStock && (
            <Badge className="absolute top-2 right-2 bg-orange-500 text-white">
              <AlertTriangle className="h-3 w-3 mr-1" />
              เหลือน้อย
            </Badge>
          )}
          {!product.inStock && <Badge className="absolute top-2 right-2 bg-gray-500 text-white">หมด</Badge>}
        </div>
      </CardHeader>
      <CardContent className="p-4">
        <div className="space-y-3">
          <div>
            <div className="flex items-center justify-between mb-1">
              <Badge variant="outline" className="text-xs">
                {product.code}
              </Badge>
              <Badge variant="secondary" className="text-xs">
                {product.size}
              </Badge>
            </div>
            <h3 className="font-semibold text-lg line-clamp-2">{product.name}</h3>
            <p className="text-sm text-gray-600">{product.material}</p>
          </div>

          <div className="flex items-center space-x-1">
            <div className="flex items-center">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`h-4 w-4 ${
                    i < Math.floor(product.avgRating) ? "text-yellow-400 fill-current" : "text-gray-300"
                  }`}
                />
              ))}
            </div>
            <span className="text-sm text-gray-600">
              {product.avgRating} ({product.reviews} รีวิว)
            </span>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center space-x-2">
                  <span className="text-xl font-bold text-blue-600">฿{product.price.toLocaleString()}</span>
                  {product.originalPrice > product.price && (
                    <span className="text-sm text-gray-500 line-through">
                      ฿{product.originalPrice.toLocaleString()}
                    </span>
                  )}
                </div>
                <p className="text-xs text-gray-500">คงเหลือ: {product.qty} ชิ้น</p>
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs text-gray-600">
                <span>น้ำหนัก:</span>
                <span>{product.weight}</span>
              </div>
              <div className="flex items-center justify-between text-xs text-gray-600">
                <span>เกรด:</span>
                <span>{product.rating}</span>
              </div>
            </div>

            <div className="flex flex-wrap gap-1">
              {product.features.slice(0, 2).map((feature: string, index: number) => (
                <Badge key={index} variant="outline" className="text-xs">
                  {feature}
                </Badge>
              ))}
            </div>
          </div>

          <div className="flex space-x-2">
            <Button
              onClick={() => addToCart(product.code)}
              disabled={!product.inStock}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
              size="sm"
            >
              <ShoppingCart className="h-4 w-4 mr-2" />
              {product.inStock ? "เพิ่มลงตะกร้า" : "สินค้าหมด"}
            </Button>
            <Button variant="outline" size="sm">
              <Info className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )

  // Get unique sizes for filter
  const availableSizes = [...new Set(categoryData.products.map((p: any) => p.size))]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center space-x-2">
              <Zap className="h-8 w-8 text-blue-600" />
              <span className="text-xl font-bold text-gray-900">KDP Electrical Store</span>
            </Link>

            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-gray-700 hover:text-blue-600">
                หน้าแรก
              </Link>
              <Link href="/categories" className="text-gray-700 hover:text-blue-600">
                หมวดหมู่สินค้า
              </Link>
              <Link href="/about" className="text-gray-700 hover:text-blue-600">
                เกี่ยวกับเรา
              </Link>
              <Link href="/contact" className="text-gray-700 hover:text-blue-600">
                ติดต่อ
              </Link>
            </nav>

            <div className="flex items-center space-x-4">
              <Button variant="outline" className="relative bg-transparent">
                <ShoppingCart className="h-5 w-5" />
                {cartItems > 0 && (
                  <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                    {cartItems}
                  </Badge>
                )}
              </Button>
              <Link href="/admin">
                <Button variant="outline">Admin</Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Breadcrumb */}
      <div className="bg-gray-100 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center space-x-2 text-sm">
            <Link href="/" className="text-gray-500 hover:text-gray-700">
              หน้าแรก
            </Link>
            <span className="text-gray-400">/</span>
            <Link href="/categories" className="text-gray-500 hover:text-gray-700">
              หมวดหมู่สินค้า
            </Link>
            <span className="text-gray-400">/</span>
            <span className="text-gray-900 font-medium">{categoryData.name.split(" - ")[1] || categoryData.name}</span>
          </div>
        </div>
      </div>

      {/* Category Header */}
      <section className="bg-white py-8 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <div className="flex items-center space-x-4 mb-4">
                <Link href="/categories">
                  <Button variant="outline" size="sm">
                    <ArrowLeft className="h-4 w-4 mr-2" />
                    กลับ
                  </Button>
                </Link>
                <div className="flex items-center space-x-2">
                  <Badge className="bg-blue-100 text-blue-800">{products.length} สินค้า</Badge>
                  <Badge variant="outline">
                    <TrendingUp className="h-3 w-3 mr-1" />
                    ยอดนิยม
                  </Badge>
                </div>
              </div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">{categoryData.name}</h1>
              <p className="text-lg text-gray-600 mb-4">{categoryData.description}</p>
              <div className="flex items-center space-x-6 text-sm text-gray-600">
                <div className="flex items-center space-x-1">
                  <Shield className="h-4 w-4" />
                  <span>รับประกันคุณภาพ</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Award className="h-4 w-4" />
                  <span>มาตรฐาน NEMA</span>
                </div>
                <div className="flex items-center space-x-1">
                  <CheckCircle className="h-4 w-4" />
                  <span>พร้อมส่ง</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Filters */}
      <section className="bg-white py-6 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-6 gap-4 items-end">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">ค้นหาสินค้า</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="ค้นหารหัสหรือชื่อสินค้า..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">ช่วงราคา</label>
              <Select value={priceRange} onValueChange={setPriceRange}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">ทุกราคา</SelectItem>
                  <SelectItem value="low">ต่ำกว่า ฿500</SelectItem>
                  <SelectItem value="medium">฿500 - ฿1,500</SelectItem>
                  <SelectItem value="high">สูงกว่า ฿1,500</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">ขนาด</label>
              <Select value={sizeFilter} onValueChange={setSizeFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">ทุกขนาด</SelectItem>
                  {availableSizes.map((size) => (
                    <SelectItem key={size} value={size}>
                      {size}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">เรียงตาม</label>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="name">ชื่อสินค้า</SelectItem>
                  <SelectItem value="price-low">ราคา: ต่ำ → สูง</SelectItem>
                  <SelectItem value="price-high">ราคา: สูง → ต่ำ</SelectItem>
                  <SelectItem value="rating">คะแนนรีวิว</SelectItem>
                  <SelectItem value="reviews">จำนวนรีวิว</SelectItem>
                  <SelectItem value="stock">จำนวนสต็อก</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">มุมมอง</label>
              <div className="flex space-x-2">
                <Button
                  variant={viewMode === "grid" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setViewMode("grid")}
                >
                  <Grid className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === "list" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setViewMode("list")}
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Products */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {products.length > 0 ? (
            <div
              className={`grid gap-6 ${
                viewMode === "grid" ? "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4" : "grid-cols-1"
              }`}
            >
              {products.map((product) => (
                <ProductCard key={product.code} product={product} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Package className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">ไม่พบสินค้าที่ค้นหา</h3>
              <p className="text-gray-600 mb-4">ลองปรับเปลี่ยนตัวกรองหรือคำค้นหา</p>
              <Button
                onClick={() => {
                  setSearchTerm("")
                  setPriceRange("all")
                  setSizeFilter("all")
                }}
                variant="outline"
              >
                ล้างตัวกรอง
              </Button>
            </div>
          )}
        </div>
      </section>
    </div>
  )
}
