"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Search,
  Package,
  Grid,
  List,
  Filter,
  ArrowRight,
  Factory,
  ShoppingCart,
  Star,
  TrendingUp,
  Shield,
  Award,
} from "lucide-react"

// หมวดหมู่สินค้า O-Z/Gedney
const ozGedneyCategories = {
  "form7-bodies": {
    name: "ท่อร้อยสายไฟ Form 7",
    description: "ท่อร้อยสายไฟเหล็กหล่อ Form 7 สำหรับพื้นที่อันตรายและงานทั่วไป",
    image: "/placeholder.svg?height=200&width=300&text=Form+7+Bodies",
    productCount: 45,
    priceRange: "฿450 - ฿3,500",
    popular: true,
    totalStock: 2850,
    avgRating: 4.8,
    applications: ["พื้นที่อันตราย", "งานทั่วไป", "อุตสาหกรรม"],
    sizes: ['1/2"', '3/4"', '1"', '1-1/4"', '1-1/2"', '2"', '2-1/2"', '3"', '4"'],
    certifications: ["UL Listed", "CSA Certified", "NEMA 3R"],
  },
  "malleable-iron-bodies": {
    name: "ท่อร้อยสายไฟเหล็กเหนียว",
    description: "ท่อร้อยสายไฟเหล็กเหนียวชุบสังกะสีร้อน ทนการกัดกร่อนเยี่ยม",
    image: "/placeholder.svg?height=200&width=300&text=Malleable+Iron",
    productCount: 38,
    priceRange: "฿520 - ฿5,200",
    popular: true,
    totalStock: 4200,
    avgRating: 4.9,
    applications: ["งานกลางแจ้ง", "สภาพแวดล้อมกัดกร่อน", "งานทางทะเล"],
    sizes: ['1/2"', '3/4"', '1"', '1-1/4"', '1-1/2"', '2"', '2-1/2"', '3"', '4"'],
    certifications: ["UL Listed", "CSA Certified", "NEMA 3R", "NEMA 4X"],
  },
  "rigid-conduit-fittings": {
    name: "ข้อต่อท่อเหล็กแข็ง",
    description: "ข้อต่อท่อเหล็กแข็งครบชุด รวมข้อต่อ ข้องอ และนิปเปิล",
    image: "/placeholder.svg?height=200&width=300&text=Rigid+Fittings",
    productCount: 125,
    priceRange: "฿230 - ฿2,650",
    popular: true,
    totalStock: 8500,
    avgRating: 4.7,
    applications: ["พาณิชยกรรม", "อุตสาหกรรม", "สถาบัน"],
    sizes: ['1/2"', '3/4"', '1"', '1-1/4"', '1-1/2"', '2"', '2-1/2"', '3"', '3-1/2"', '4"'],
    certifications: ["UL Listed", "CSA Certified"],
  },
  "liquidtight-fittings": {
    name: "ข้อต่อท่อยืดหยุ่นกันน้ำ",
    description: "ข้อต่อกันน้ำสำหรับท่อยืดหยุ่นโลหะและไม่ใช่โลหะ",
    image: "/placeholder.svg?height=200&width=300&text=Liquidtight",
    productCount: 85,
    priceRange: "฿350 - ฿2,180",
    popular: false,
    totalStock: 3200,
    avgRating: 4.6,
    applications: ["สถานที่เปียก", "ป้องกันการสั่นสะเทือน", "การต่อแบบยืดหยุ่น"],
    sizes: ['3/8"', '1/2"', '3/4"', '1"', '1-1/4"', '1-1/2"', '2"', '2-1/2"', '3"', '4"'],
    certifications: ["UL Listed", "CSA Certified", "NEMA 4", "NEMA 4X"],
  },
  "junction-boxes": {
    name: "กล่องต่อสายไฟและตู้ไฟฟ้า",
    description: "กล่องต่อสายไฟเหล็กหล่อและเหล็กกล้าสำหรับงานไฟฟ้าต่างๆ",
    image: "/placeholder.svg?height=200&width=300&text=Junction+Boxes",
    productCount: 65,
    priceRange: "฿700 - ฿9,800",
    popular: false,
    totalStock: 1800,
    avgRating: 4.5,
    applications: ["จุดต่อสาย", "กล่องดึงสาย", "การติดตั้งอุปกรณ์"],
    sizes: ["4x4", "6x6", "8x8", "10x10", "12x12", "ตามสั่ง"],
    certifications: ["UL Listed", "CSA Certified", "NEMA 3R", "NEMA 4X"],
  },
  "covers-gaskets": {
    name: "ฝาครอบและปะเก็น",
    description: "ฝาครอบและปะเก็นทดแทนสำหรับท่อร้อยสายไฟและกล่องต่อสาย",
    image: "/placeholder.svg?height=200&width=300&text=Covers+Gaskets",
    productCount: 95,
    priceRange: "฿160 - ฿1,260",
    popular: false,
    totalStock: 5600,
    avgRating: 4.4,
    applications: ["ป้องกันสภาพอากาศ", "การบำรุงรักษา", "อะไหล่ทดแทน"],
    sizes: ['1/2"', '3/4"', '1"', '1-1/4"', '1-1/2"', '2"', '2-1/2"', '3"', '4"'],
    certifications: ["UL Listed", "NEMA 3R", "NEMA 4X"],
  },
  "explosion-proof": {
    name: "อุปกรณ์ป้องกันการระเบิด",
    description: "ท่อร้อยสายไฟและข้อต่อป้องกันการระเบิด Class I Division 1",
    image: "/placeholder.svg?height=200&width=300&text=Explosion+Proof",
    productCount: 28,
    priceRange: "฿2,380 - ฿12,600",
    popular: false,
    totalStock: 650,
    avgRating: 4.9,
    applications: ["พื้นที่อันตราย", "Class I Div 1", "ปิโตรเคมี"],
    sizes: ['1/2"', '3/4"', '1"', '1-1/4"', '1-1/2"', '2"'],
    certifications: ["UL Listed", "CSA Certified", "Class I Div 1", "ATEX"],
  },
  "specialty-fittings": {
    name: "ข้อต่อพิเศษ",
    description: "ข้อต่อพิเศษ รวมข้อต่อซีล ข้อต่อขยายตัว และโซลูชั่นตามสั่ง",
    image: "/placeholder.svg?height=200&width=300&text=Specialty",
    productCount: 42,
    priceRange: "฿980 - ฿7,980",
    popular: false,
    totalStock: 980,
    avgRating: 4.6,
    applications: ["การซีล", "การขยายตัว", "งานตามสั่ง"],
    sizes: ["หลากหลาย", "ตามสั่ง"],
    certifications: ["UL Listed", "CSA Certified", "ใบรับรองตามสั่ง"],
  },
}

export default function CategoriesPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [sortBy, setSortBy] = useState("popular")
  const [viewMode, setViewMode] = useState("grid")

  // กรองและเรียงหมวดหมู่
  const filteredCategories = Object.entries(ozGedneyCategories)
    .filter(
      ([key, category]) =>
        category.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        category.description.toLowerCase().includes(searchTerm.toLowerCase()),
    )
    .sort(([, a], [, b]) => {
      switch (sortBy) {
        case "popular":
          return b.popular === a.popular ? 0 : b.popular ? 1 : -1
        case "name":
          return a.name.localeCompare(b.name)
        case "products":
          return b.productCount - a.productCount
        case "stock":
          return b.totalStock - a.totalStock
        default:
          return 0
      }
    })

  const CategoryCard = ({ categoryKey, category }: { categoryKey: string; category: any }) => (
    <Card className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
      <CardHeader className="p-0">
        <div className="relative overflow-hidden rounded-t-lg">
          <img
            src={category.image || "/placeholder.svg"}
            alt={category.name}
            className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
          />
          {category.popular && (
            <Badge className="absolute top-3 left-3 bg-orange-500 text-white">
              <TrendingUp className="h-3 w-3 mr-1" />
              ยอดนิยม
            </Badge>
          )}
          <Badge className="absolute top-3 right-3 bg-blue-600 text-white">O-Z/Gedney</Badge>
          <div className="absolute bottom-3 left-3 bg-black/70 text-white px-2 py-1 rounded text-sm">
            {category.productCount} สินค้า
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-4">
          <div>
            <h3 className="font-bold text-lg line-clamp-2 group-hover:text-blue-600 transition-colors">
              {category.name}
            </h3>
            <p className="text-gray-600 text-sm line-clamp-2 mt-2">{category.description}</p>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-500">ช่วงราคา:</span>
              <span className="font-semibold text-blue-600">{category.priceRange}</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-500">คงเหลือ:</span>
              <span className="font-semibold">{category.totalStock.toLocaleString()} ชิ้น</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-500">คะแนน:</span>
              <div className="flex items-center space-x-1">
                <Star className="h-4 w-4 text-yellow-400 fill-current" />
                <span className="font-semibold">{category.avgRating}</span>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <p className="text-sm font-medium text-gray-700">การใช้งาน:</p>
            <div className="flex flex-wrap gap-1">
              {category.applications.slice(0, 2).map((app: string, index: number) => (
                <Badge key={index} variant="outline" className="text-xs">
                  {app}
                </Badge>
              ))}
              {category.applications.length > 2 && (
                <Badge variant="outline" className="text-xs">
                  +{category.applications.length - 2} อื่นๆ
                </Badge>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <p className="text-sm font-medium text-gray-700">ใบรับรอง:</p>
            <div className="flex flex-wrap gap-1">
              {category.certifications.slice(0, 3).map((cert: string, index: number) => (
                <Badge key={index} variant="secondary" className="text-xs">
                  {cert}
                </Badge>
              ))}
            </div>
          </div>

          <Link href={`/categories/${categoryKey}`}>
            <Button className="w-full group-hover:bg-blue-700 transition-colors">
              ดูสินค้า
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  )

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <Factory className="h-6 w-6 text-white" />
              </div>
              <div>
                <div className="text-xl font-bold text-gray-900">O-Z/Gedney</div>
                <div className="text-xs text-gray-500">อุปกรณ์ไฟฟ้า</div>
              </div>
            </Link>

            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-gray-700 hover:text-blue-600">
                หน้าแรก
              </Link>
              <Link href="/categories" className="text-blue-600 font-medium">
                สินค้า
              </Link>
              <Link href="/catalog" className="text-gray-700 hover:text-blue-600">
                แคตตาล็อก
              </Link>
              <Link href="/technical" className="text-gray-700 hover:text-blue-600">
                ข้อมูลเทคนิค
              </Link>
              <Link href="/about" className="text-gray-700 hover:text-blue-600">
                เกี่ยวกับเรา
              </Link>
              <Link href="/contact" className="text-gray-700 hover:text-blue-600">
                ติดต่อ
              </Link>
            </nav>

            <div className="flex items-center space-x-4">
              <Button variant="outline" className="relative bg-transparent">
                <ShoppingCart className="h-5 w-5" />
              </Button>
              <Link href="/admin">
                <Button variant="outline">แอดมิน</Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-slate-800 to-slate-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">หมวดหมู่สินค้า O-Z/Gedney</h1>
            <p className="text-xl text-slate-300 mb-6">โซลูชั่นท่อร้อยสายไฟและข้อต่อครบครันสำหรับทุกการใช้งาน</p>
            <div className="flex justify-center">
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 max-w-md">
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-blue-400">{Object.keys(ozGedneyCategories).length}</div>
                    <div className="text-sm text-slate-300">หมวดหมู่</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-blue-400">
                      {Object.values(ozGedneyCategories).reduce((sum, cat) => sum + cat.productCount, 0)}
                    </div>
                    <div className="text-sm text-slate-300">สินค้า</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-blue-400">
                      {(Object.values(ozGedneyCategories).reduce((sum, cat) => sum + cat.totalStock, 0) / 1000).toFixed(
                        0,
                      )}
                      K
                    </div>
                    <div className="text-sm text-slate-300">ชิ้นในสต็อก</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Filters */}
          <div className="bg-white p-6 rounded-lg shadow-sm mb-8">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">ค้นหาหมวดหมู่</label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="ค้นหาหมวดหมู่สินค้า..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">เรียงตาม</label>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="popular">ความนิยม</SelectItem>
                    <SelectItem value="name">ชื่อหมวดหมู่</SelectItem>
                    <SelectItem value="products">จำนวนสินค้า</SelectItem>
                    <SelectItem value="stock">ระดับสต็อก</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">มุมมอง</label>
                <div className="flex space-x-2">
                  <Button
                    variant={viewMode === "grid" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setViewMode("grid")}
                  >
                    <Grid className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={viewMode === "list" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setViewMode("list")}
                  >
                    <List className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div>
                <Button variant="outline" className="w-full bg-transparent">
                  <Filter className="h-4 w-4 mr-2" />
                  ตัวกรองขั้นสูง
                </Button>
              </div>
            </div>
          </div>

          {/* Categories Grid */}
          <div
            className={`grid gap-6 ${
              viewMode === "grid" ? "grid-cols-1 md:grid-cols-2 lg:grid-cols-3" : "grid-cols-1"
            }`}
          >
            {filteredCategories.map(([key, category]) => (
              <CategoryCard key={key} categoryKey={key} category={category} />
            ))}
          </div>

          {filteredCategories.length === 0 && (
            <div className="text-center py-12">
              <Package className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">ไม่พบหมวดหมู่ที่ค้นหา</h3>
              <p className="text-gray-600">ลองปรับเปลี่ยนเกณฑ์การค้นหา</p>
            </div>
          )}
        </div>
      </section>

      {/* Popular Categories Section */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">หมวดหมู่ยอดนิยม</h2>
            <p className="text-lg text-gray-600">สายผลิตภัณฑ์ O-Z/Gedney ที่ขายดีที่สุด</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {Object.entries(ozGedneyCategories)
              .filter(([, category]) => category.popular)
              .map(([key, category]) => (
                <div key={key} className="text-center p-6 border rounded-lg hover:shadow-md transition-shadow">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Package className="h-8 w-8 text-blue-600" />
                  </div>
                  <h3 className="font-semibold text-lg mb-2">{category.name}</h3>
                  <p className="text-gray-600 text-sm mb-4">{category.productCount} สินค้า</p>
                  <div className="flex justify-center space-x-2 mb-4">
                    <Badge variant="outline" className="text-xs">
                      <Shield className="h-3 w-3 mr-1" />
                      UL Listed
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      <Award className="h-3 w-3 mr-1" />
                      Made in USA
                    </Badge>
                  </div>
                  <Link href={`/categories/${key}`}>
                    <Button variant="outline" size="sm">
                      ดูสินค้า
                    </Button>
                  </Link>
                </div>
              ))}
          </div>
        </div>
      </section>
    </div>
  )
}
