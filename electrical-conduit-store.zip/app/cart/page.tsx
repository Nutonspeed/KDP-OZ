"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"
import {
  ShoppingCart,
  Plus,
  Minus,
  Trash2,
  ArrowLeft,
  Factory,
  Truck,
  Shield,
  CreditCard,
  Gift,
  Tag,
  AlertCircle,
  CheckCircle,
} from "lucide-react"

// ข้อมูลตะกร้าสินค้าตัวอย่าง
const initialCartItems = [
  {
    id: "lb-17",
    name: "ท่อร้อยสายไฟ Form 7 รุ่น LB-17",
    partNumber: "LB-17",
    image: "/placeholder.svg?height=100&width=100&text=LB-17",
    price: 850,
    originalPrice: 950,
    quantity: 2,
    inStock: true,
    stockQuantity: 245,
    weight: 0.85,
  },
  {
    id: "lb-27",
    name: "ท่อร้อยสายไฟ Form 7 รุ่น LB-27",
    partNumber: "LB-27",
    image: "/placeholder.svg?height=100&width=100&text=LB-27",
    price: 1250,
    originalPrice: 1400,
    quantity: 1,
    inStock: true,
    stockQuantity: 156,
    weight: 1.2,
  },
  {
    id: "cover-17",
    name: "ฝาครอบ LB-17-C",
    partNumber: "LB-17-C",
    image: "/placeholder.svg?height=100&width=100&text=Cover",
    price: 180,
    originalPrice: 200,
    quantity: 2,
    inStock: true,
    stockQuantity: 89,
    weight: 0.15,
  },
]

export default function CartPage() {
  const [cartItems, setCartItems] = useState(initialCartItems)
  const [promoCode, setPromoCode] = useState("")
  const [appliedPromo, setAppliedPromo] = useState<string | null>(null)
  const [shippingMethod, setShippingMethod] = useState("standard")

  // คำนวณราคารวม
  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const originalSubtotal = cartItems.reduce((sum, item) => sum + item.originalPrice * item.quantity, 0)
  const totalSavings = originalSubtotal - subtotal
  const totalWeight = cartItems.reduce((sum, item) => sum + item.weight * item.quantity, 0)

  // ค่าจัดส่ง
  const shippingCost = shippingMethod === "express" ? 150 : subtotal >= 2000 ? 0 : 100

  // ส่วนลดโปรโมชั่น
  const promoDiscount = appliedPromo === "SAVE10" ? subtotal * 0.1 : appliedPromo === "NEWCUSTOMER" ? 200 : 0

  // ภาษี VAT 7%
  const vatAmount = (subtotal - promoDiscount + shippingCost) * 0.07

  // ราคารวมสุดท้าย
  const finalTotal = subtotal - promoDiscount + shippingCost + vatAmount

  const updateQuantity = (id: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      removeItem(id)
      return
    }

    setCartItems((items) =>
      items.map((item) => (item.id === id ? { ...item, quantity: Math.min(newQuantity, item.stockQuantity) } : item)),
    )
  }

  const removeItem = (id: string) => {
    setCartItems((items) => items.filter((item) => item.id !== id))
  }

  const applyPromoCode = () => {
    const validCodes = ["SAVE10", "NEWCUSTOMER", "FREESHIP"]
    if (validCodes.includes(promoCode.toUpperCase())) {
      setAppliedPromo(promoCode.toUpperCase())
      setPromoCode("")
    }
  }

  const removePromoCode = () => {
    setAppliedPromo(null)
  }

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-white shadow-sm border-b">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <Link href="/" className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                  <Factory className="h-6 w-6 text-white" />
                </div>
                <div>
                  <div className="text-xl font-bold text-gray-900">O-Z/Gedney</div>
                  <div className="text-xs text-gray-500">อุปกรณ์ไฟฟ้า</div>
                </div>
              </Link>

              <nav className="hidden md:flex items-center space-x-8">
                <Link href="/" className="text-gray-700 hover:text-blue-600">
                  หน้าแรก
                </Link>
                <Link href="/categories" className="text-gray-700 hover:text-blue-600">
                  สินค้า
                </Link>
                <Link href="/catalog" className="text-gray-700 hover:text-blue-600">
                  แคตตาล็อก
                </Link>
                <Link href="/technical" className="text-gray-700 hover:text-blue-600">
                  ข้อมูลเทคนิค
                </Link>
                <Link href="/about" className="text-gray-700 hover:text-blue-600">
                  เกี่ยวกับเรา
                </Link>
                <Link href="/contact" className="text-gray-700 hover:text-blue-600">
                  ติดต่อ
                </Link>
              </nav>

              <div className="flex items-center space-x-4">
                <Button variant="outline" className="relative bg-transparent">
                  <ShoppingCart className="h-5 w-5" />
                </Button>
                <Link href="/admin">
                  <Button variant="outline">แอดมิน</Button>
                </Link>
              </div>
            </div>
          </div>
        </header>

        {/* Empty Cart */}
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="text-center">
            <ShoppingCart className="h-24 w-24 text-gray-400 mx-auto mb-6" />
            <h1 className="text-3xl font-bold text-gray-900 mb-4">ตะกร้าสินค้าว่างเปล่า</h1>
            <p className="text-gray-600 mb-8">ยังไม่มีสินค้าในตะกร้าของคุณ เริ่มช้อปปิ้งกันเลย!</p>
            <div className="space-x-4">
              <Link href="/categories">
                <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
                  เลือกซื้อสินค้า
                </Button>
              </Link>
              <Link href="/">
                <Button variant="outline" size="lg">
                  กลับหน้าแรก
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <Factory className="h-6 w-6 text-white" />
              </div>
              <div>
                <div className="text-xl font-bold text-gray-900">O-Z/Gedney</div>
                <div className="text-xs text-gray-500">อุปกรณ์ไฟฟ้า</div>
              </div>
            </Link>

            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-gray-700 hover:text-blue-600">
                หน้าแรก
              </Link>
              <Link href="/categories" className="text-gray-700 hover:text-blue-600">
                สินค้า
              </Link>
              <Link href="/catalog" className="text-gray-700 hover:text-blue-600">
                แคตตาล็อก
              </Link>
              <Link href="/technical" className="text-gray-700 hover:text-blue-600">
                ข้อมูลเทคนิค
              </Link>
              <Link href="/about" className="text-gray-700 hover:text-blue-600">
                เกี่ยวกับเรา
              </Link>
              <Link href="/contact" className="text-gray-700 hover:text-blue-600">
                ติดต่อ
              </Link>
            </nav>

            <div className="flex items-center space-x-4">
              <Button variant="outline" className="relative bg-transparent">
                <ShoppingCart className="h-5 w-5" />
                <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                  {cartItems.reduce((sum, item) => sum + item.quantity, 0)}
                </Badge>
              </Button>
              <Link href="/admin">
                <Button variant="outline">แอดมิน</Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Breadcrumb */}
      <div className="bg-gray-100 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center space-x-2 text-sm">
            <Link href="/" className="text-gray-500 hover:text-gray-700">
              หน้าแรก
            </Link>
            <span className="text-gray-400">/</span>
            <span className="text-gray-900 font-medium">ตะกร้าสินค้า</span>
          </div>
        </div>
      </div>

      {/* Cart Content */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <h1 className="text-3xl font-bold text-gray-900">ตะกร้าสินค้า</h1>
            <Link href="/categories">
              <Button variant="outline">
                <ArrowLeft className="h-4 w-4 mr-2" />
                เลือกซื้อสินค้าต่อ
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-4">
              {cartItems.map((item) => (
                <Card key={item.id}>
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <img
                        src={item.image || "/placeholder.svg"}
                        alt={item.name}
                        className="w-20 h-20 object-cover rounded-lg border"
                      />

                      <div className="flex-1 space-y-2">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="font-semibold text-lg">{item.name}</h3>
                            <p className="text-sm text-gray-600">รหัส: {item.partNumber}</p>
                            <div className="flex items-center space-x-2 mt-1">
                              {item.inStock ? (
                                <Badge className="bg-green-100 text-green-800">
                                  <CheckCircle className="h-3 w-3 mr-1" />
                                  พร้อมส่ง
                                </Badge>
                              ) : (
                                <Badge className="bg-red-100 text-red-800">
                                  <AlertCircle className="h-3 w-3 mr-1" />
                                  สินค้าหมด
                                </Badge>
                              )}
                              <span className="text-xs text-gray-500">คงเหลือ {item.stockQuantity} ชิ้น</span>
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeItem(item.id)}
                            className="text-red-600 hover:text-red-700 hover:bg-red-50"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <span className="text-lg font-bold text-blue-600">฿{item.price.toLocaleString()}</span>
                            {item.originalPrice > item.price && (
                              <span className="text-sm text-gray-500 line-through">
                                ฿{item.originalPrice.toLocaleString()}
                              </span>
                            )}
                          </div>

                          <div className="flex items-center space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => updateQuantity(item.id, item.quantity - 1)}
                              disabled={item.quantity <= 1}
                            >
                              <Minus className="h-4 w-4" />
                            </Button>
                            <Input
                              type="number"
                              value={item.quantity}
                              onChange={(e) => updateQuantity(item.id, Number.parseInt(e.target.value) || 1)}
                              className="w-16 text-center"
                              min="1"
                              max={item.stockQuantity}
                            />
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => updateQuantity(item.id, item.quantity + 1)}
                              disabled={item.quantity >= item.stockQuantity}
                            >
                              <Plus className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>

                        <div className="text-right">
                          <span className="text-lg font-semibold">
                            ฿{(item.price * item.quantity).toLocaleString()}
                          </span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}

              {/* Promo Code */}
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4">
                    <Tag className="h-5 w-5 text-gray-500" />
                    <div className="flex-1">
                      <Input
                        placeholder="ใส่รหัสส่วนลด"
                        value={promoCode}
                        onChange={(e) => setPromoCode(e.target.value)}
                        className="mb-2"
                      />
                      {appliedPromo && (
                        <div className="flex items-center justify-between bg-green-50 p-2 rounded">
                          <span className="text-green-800 text-sm">ใช้รหัส: {appliedPromo}</span>
                          <Button variant="ghost" size="sm" onClick={removePromoCode} className="text-red-600">
                            ยกเลิก
                          </Button>
                        </div>
                      )}
                    </div>
                    <Button onClick={applyPromoCode} disabled={!promoCode}>
                      ใช้รหัส
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Order Summary */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <h2 className="text-xl font-semibold">สรุปคำสั่งซื้อ</h2>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between">
                    <span>ราคาสินค้า ({cartItems.reduce((sum, item) => sum + item.quantity, 0)} ชิ้น)</span>
                    <span>฿{subtotal.toLocaleString()}</span>
                  </div>

                  {totalSavings > 0 && (
                    <div className="flex justify-between text-green-600">
                      <span>ส่วนลดสินค้า</span>
                      <span>-฿{totalSavings.toLocaleString()}</span>
                    </div>
                  )}

                  {promoDiscount > 0 && (
                    <div className="flex justify-between text-green-600">
                      <span>ส่วนลดโปรโมชั่น</span>
                      <span>-฿{promoDiscount.toLocaleString()}</span>
                    </div>
                  )}

                  <Separator />

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>ค่าจัดส่ง</span>
                      <span>{shippingCost === 0 ? "ฟรี" : `฿${shippingCost}`}</span>
                    </div>
                    <div className="text-sm text-gray-600">
                      <div className="flex items-center space-x-2">
                        <input
                          type="radio"
                          id="standard"
                          name="shipping"
                          value="standard"
                          checked={shippingMethod === "standard"}
                          onChange={(e) => setShippingMethod(e.target.value)}
                        />
                        <label htmlFor="standard">จัดส่งมาตรฐาน (3-5 วัน)</label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input
                          type="radio"
                          id="express"
                          name="shipping"
                          value="express"
                          checked={shippingMethod === "express"}
                          onChange={(e) => setShippingMethod(e.target.value)}
                        />
                        <label htmlFor="express">จัดส่งด่วน (1-2 วัน) +฿150</label>
                      </div>
                    </div>
                    {subtotal >= 2000 && <p className="text-sm text-green-600">🎉 ฟรีค่าจัดส่งสำหรับคำสั่งซื้อตั้งแต่ ฿2,000</p>}
                  </div>

                  <div className="flex justify-between">
                    <span>ภาษี VAT 7%</span>
                    <span>฿{vatAmount.toLocaleString()}</span>
                  </div>

                  <Separator />

                  <div className="flex justify-between text-lg font-bold">
                    <span>ราคารวมทั้งสิ้น</span>
                    <span className="text-blue-600">฿{finalTotal.toLocaleString()}</span>
                  </div>

                  <div className="text-sm text-gray-600">
                    <p>น้ำหนักรวม: {totalWeight.toFixed(2)} กก.</p>
                  </div>
                </CardContent>
              </Card>

              {/* Checkout Button */}
              <Button className="w-full bg-blue-600 hover:bg-blue-700" size="lg">
                <CreditCard className="h-5 w-5 mr-2" />
                ดำเนินการชำระเงิน
              </Button>

              {/* Security Info */}
              <Card>
                <CardContent className="p-4">
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <Shield className="h-5 w-5 text-green-600" />
                      <span className="text-sm">การชำระเงินปลอดภัย 100%</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Truck className="h-5 w-5 text-blue-600" />
                      <span className="text-sm">จัดส่งทั่วประเทศ</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Gift className="h-5 w-5 text-purple-600" />
                      <span className="text-sm">รับประกันสินค้า 2 ปี</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Contact for Bulk Order */}
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-2">สั่งซื้อจำนวนมาก?</h3>
                  <p className="text-sm text-gray-600 mb-3">ติดต่อเราเพื่อขอใบเสนอราคาพิเศษ</p>
                  <Button variant="outline" className="w-full bg-transparent" size="sm">
                    ขอใบเสนอราคา
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
