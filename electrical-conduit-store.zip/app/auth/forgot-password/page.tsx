"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import {
  ArrowLeft,
  Mail,
  Shield,
  CheckCircle,
  Eye,
  EyeOff,
  RefreshCw,
  Clock,
  AlertCircle,
  Sparkles,
} from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp"

type Step = "email" | "otp" | "password" | "success"

export default function ForgotPasswordPage() {
  const [currentStep, setCurrentStep] = useState<Step>("email")
  const [email, setEmail] = useState("")
  const [otp, setOtp] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [otpTimer, setOtpTimer] = useState(300) // 5 minutes
  const [canResendOtp, setCanResendOtp] = useState(false)

  // Password strength checker
  const getPasswordStrength = (password: string) => {
    let strength = 0
    const checks = {
      length: password.length >= 8,
      uppercase: /[A-Z]/.test(password),
      lowercase: /[a-z]/.test(password),
      number: /\d/.test(password),
      special: /[!@#$%^&*(),.?":{}|<>]/.test(password),
    }

    strength = Object.values(checks).filter(Boolean).length

    return {
      score: strength,
      checks,
      label: strength < 2 ? "อ่อน" : strength < 4 ? "ปานกลาง" : "แข็งแกร่ง",
      color: strength < 2 ? "text-red-600" : strength < 4 ? "text-yellow-600" : "text-green-600",
      bgColor: strength < 2 ? "bg-red-100" : strength < 4 ? "bg-yellow-100" : "bg-green-100",
    }
  }

  const passwordStrength = getPasswordStrength(newPassword)

  // Simulate OTP timer
  useState(() => {
    if (currentStep === "otp" && otpTimer > 0) {
      const timer = setInterval(() => {
        setOtpTimer((prev) => {
          if (prev <= 1) {
            setCanResendOtp(true)
            return 0
          }
          return prev - 1
        })
      }, 1000)
      return () => clearInterval(timer)
    }
  })

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000))

    if (email === "invalid@example.com") {
      setError("ไม่พบอีเมลนี้ในระบบ")
      setIsLoading(false)
      return
    }

    setIsLoading(false)
    setCurrentStep("otp")
    setOtpTimer(300)
    setCanResendOtp(false)
  }

  const handleOtpSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))

    if (otp !== "123456") {
      setError("รหัส OTP ไม่ถูกต้อง")
      setIsLoading(false)
      return
    }

    setIsLoading(false)
    setCurrentStep("password")
  }

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    if (newPassword !== confirmPassword) {
      setError("รหัสผ่านไม่ตรงกัน")
      setIsLoading(false)
      return
    }

    if (passwordStrength.score < 3) {
      setError("รหัสผ่านไม่แข็งแกร่งพอ")
      setIsLoading(false)
      return
    }

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000))

    setIsLoading(false)
    setCurrentStep("success")
  }

  const handleResendOtp = async () => {
    setIsLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 1000))
    setOtpTimer(300)
    setCanResendOtp(false)
    setIsLoading(false)
    setOtp("")
  }

  const getStepProgress = () => {
    switch (currentStep) {
      case "email":
        return 25
      case "otp":
        return 50
      case "password":
        return 75
      case "success":
        return 100
      default:
        return 0
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <Link href="/auth/login">
            <Button variant="ghost" size="sm" className="mb-4">
              <ArrowLeft className="h-4 w-4 mr-2" />
              กลับไปเข้าสู่ระบบ
            </Button>
          </Link>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">รีเซ็ตรหัสผ่าน</h1>
          <p className="text-gray-600">ทำตามขั้นตอนเพื่อรีเซ็ตรหัสผ่านของคุณ</p>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between text-xs text-gray-500 mb-2">
            <span className={currentStep === "email" ? "text-blue-600 font-medium" : ""}>อีเมล</span>
            <span className={currentStep === "otp" ? "text-blue-600 font-medium" : ""}>ยืนยัน OTP</span>
            <span className={currentStep === "password" ? "text-blue-600 font-medium" : ""}>รหัสผ่านใหม่</span>
            <span className={currentStep === "success" ? "text-green-600 font-medium" : ""}>สำเร็จ</span>
          </div>
          <Progress value={getStepProgress()} className="h-2" />
        </div>

        <Card className="shadow-lg border-0">
          <CardContent className="p-6">
            {/* Step 1: Email */}
            {currentStep === "email" && (
              <div className="space-y-6">
                <div className="text-center">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Mail className="h-8 w-8 text-blue-600" />
                  </div>
                  <h2 className="text-xl font-semibold mb-2">ใส่อีเมลของคุณ</h2>
                  <p className="text-gray-600 text-sm">เราจะส่งรหัส OTP ไปยังอีเมลของคุณ</p>
                </div>

                <form onSubmit={handleEmailSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="email">อีเมล</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="your@email.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="mt-1"
                    />
                  </div>

                  {error && (
                    <Alert variant="destructive">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}

                  <Button type="submit" className="w-full" disabled={isLoading}>
                    {isLoading ? (
                      <>
                        <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                        กำลังส่ง OTP...
                      </>
                    ) : (
                      "ส่ง OTP"
                    )}
                  </Button>
                </form>

                <div className="text-center text-sm text-gray-500">
                  <p>
                    จำรหัสผ่านได้แล้ว?{" "}
                    <Link href="/auth/login" className="text-blue-600 hover:underline">
                      เข้าสู่ระบบ
                    </Link>
                  </p>
                </div>
              </div>
            )}

            {/* Step 2: OTP */}
            {currentStep === "otp" && (
              <div className="space-y-6">
                <div className="text-center">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Shield className="h-8 w-8 text-green-600" />
                  </div>
                  <h2 className="text-xl font-semibold mb-2">ใส่รหัส OTP</h2>
                  <p className="text-gray-600 text-sm">
                    เราได้ส่งรหัส 6 หลักไปยัง <span className="font-medium">{email}</span>
                  </p>
                </div>

                <form onSubmit={handleOtpSubmit} className="space-y-4">
                  <div className="flex justify-center">
                    <InputOTP maxLength={6} value={otp} onChange={(value) => setOtp(value)}>
                      <InputOTPGroup>
                        <InputOTPSlot index={0} />
                        <InputOTPSlot index={1} />
                        <InputOTPSlot index={2} />
                        <InputOTPSlot index={3} />
                        <InputOTPSlot index={4} />
                        <InputOTPSlot index={5} />
                      </InputOTPGroup>
                    </InputOTP>
                  </div>

                  {otpTimer > 0 && (
                    <div className="text-center">
                      <div className="flex items-center justify-center space-x-2 text-sm text-gray-500">
                        <Clock className="h-4 w-4" />
                        <span>รหัสจะหมดอายุใน {formatTime(otpTimer)}</span>
                      </div>
                    </div>
                  )}

                  {error && (
                    <Alert variant="destructive">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}

                  <Button type="submit" className="w-full" disabled={isLoading || otp.length !== 6}>
                    {isLoading ? (
                      <>
                        <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                        กำลังตรวจสอบ...
                      </>
                    ) : (
                      "ยืนยัน OTP"
                    )}
                  </Button>

                  {canResendOtp && (
                    <Button
                      type="button"
                      variant="outline"
                      className="w-full bg-transparent"
                      onClick={handleResendOtp}
                      disabled={isLoading}
                    >
                      ส่ง OTP ใหม่
                    </Button>
                  )}
                </form>

                <div className="text-center text-sm text-gray-500">
                  <p>ไม่ได้รับ OTP? ตรวจสอบในโฟลเดอร์ Spam</p>
                </div>
              </div>
            )}

            {/* Step 3: New Password */}
            {currentStep === "password" && (
              <div className="space-y-6">
                <div className="text-center">
                  <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Shield className="h-8 w-8 text-purple-600" />
                  </div>
                  <h2 className="text-xl font-semibold mb-2">ตั้งรหัสผ่านใหม่</h2>
                  <p className="text-gray-600 text-sm">สร้างรหัสผ่านที่แข็งแกร่งเพื่อความปลอดภัย</p>
                </div>

                <form onSubmit={handlePasswordSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="newPassword">รหัสผ่านใหม่</Label>
                    <div className="relative mt-1">
                      <Input
                        id="newPassword"
                        type={showPassword ? "text" : "password"}
                        placeholder="ใส่รหัสผ่านใหม่"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        required
                        className="pr-10"
                      />
                      <button
                        type="button"
                        className="absolute inset-y-0 right-0 pr-3 flex items-center"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? (
                          <EyeOff className="h-4 w-4 text-gray-400" />
                        ) : (
                          <Eye className="h-4 w-4 text-gray-400" />
                        )}
                      </button>
                    </div>

                    {newPassword && (
                      <div className="mt-2 space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-600">ความแข็งแกร่ง:</span>
                          <Badge className={passwordStrength.bgColor + " " + passwordStrength.color}>
                            {passwordStrength.label}
                          </Badge>
                        </div>
                        <Progress value={(passwordStrength.score / 5) * 100} className="h-2" />
                        <div className="grid grid-cols-2 gap-2 text-xs">
                          <div
                            className={`flex items-center space-x-1 ${passwordStrength.checks.length ? "text-green-600" : "text-gray-400"}`}
                          >
                            <CheckCircle className="h-3 w-3" />
                            <span>8+ ตัวอักษร</span>
                          </div>
                          <div
                            className={`flex items-center space-x-1 ${passwordStrength.checks.uppercase ? "text-green-600" : "text-gray-400"}`}
                          >
                            <CheckCircle className="h-3 w-3" />
                            <span>ตัวพิมพ์ใหญ่</span>
                          </div>
                          <div
                            className={`flex items-center space-x-1 ${passwordStrength.checks.lowercase ? "text-green-600" : "text-gray-400"}`}
                          >
                            <CheckCircle className="h-3 w-3" />
                            <span>ตัวพิมพ์เล็ก</span>
                          </div>
                          <div
                            className={`flex items-center space-x-1 ${passwordStrength.checks.number ? "text-green-600" : "text-gray-400"}`}
                          >
                            <CheckCircle className="h-3 w-3" />
                            <span>ตัวเลข</span>
                          </div>
                          <div
                            className={`flex items-center space-x-1 ${passwordStrength.checks.special ? "text-green-600" : "text-gray-400"}`}
                          >
                            <CheckCircle className="h-3 w-3" />
                            <span>อักขระพิเศษ</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="confirmPassword">ยืนยันรหัสผ่าน</Label>
                    <div className="relative mt-1">
                      <Input
                        id="confirmPassword"
                        type={showConfirmPassword ? "text" : "password"}
                        placeholder="ใส่รหัสผ่านอีกครั้ง"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        required
                        className="pr-10"
                      />
                      <button
                        type="button"
                        className="absolute inset-y-0 right-0 pr-3 flex items-center"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      >
                        {showConfirmPassword ? (
                          <EyeOff className="h-4 w-4 text-gray-400" />
                        ) : (
                          <Eye className="h-4 w-4 text-gray-400" />
                        )}
                      </button>
                    </div>
                    {confirmPassword && newPassword !== confirmPassword && (
                      <p className="text-sm text-red-600 mt-1">รหัสผ่านไม่ตรงกัน</p>
                    )}
                  </div>

                  {error && (
                    <Alert variant="destructive">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}

                  <Button
                    type="submit"
                    className="w-full"
                    disabled={isLoading || passwordStrength.score < 3 || newPassword !== confirmPassword}
                  >
                    {isLoading ? (
                      <>
                        <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                        กำลังบันทึก...
                      </>
                    ) : (
                      "บันทึกรหัสผ่าน"
                    )}
                  </Button>
                </form>

                <Alert>
                  <Shield className="h-4 w-4" />
                  <AlertDescription>
                    <strong>เคล็ดลับความปลอดภัย:</strong> ใช้รหัสผ่านที่ไม่เคยใช้ที่อื่น และเก็บไว้ในที่ปลอดภัย
                  </AlertDescription>
                </Alert>
              </div>
            )}

            {/* Step 4: Success */}
            {currentStep === "success" && (
              <div className="space-y-6 text-center">
                <div className="relative">
                  <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 relative">
                    <CheckCircle className="h-10 w-10 text-green-600" />
                    <div className="absolute -top-2 -right-2">
                      <Sparkles className="h-6 w-6 text-yellow-500 animate-pulse" />
                    </div>
                  </div>
                  <h2 className="text-2xl font-bold text-green-600 mb-2">สำเร็จ!</h2>
                  <p className="text-gray-600">รหัสผ่านของคุณได้รับการรีเซ็ตเรียบร้อยแล้ว</p>
                </div>

                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex items-center space-x-2 text-green-800">
                    <CheckCircle className="h-5 w-5" />
                    <span className="font-medium">รหัสผ่านใหม่ถูกบันทึกแล้ว</span>
                  </div>
                  <p className="text-sm text-green-700 mt-1">คุณสามารถเข้าสู่ระบบด้วยรหัสผ่านใหม่ได้ทันที</p>
                </div>

                <div className="space-y-3">
                  <Link href="/auth/login">
                    <Button className="w-full">เข้าสู่ระบบ</Button>
                  </Link>
                  <Link href="/">
                    <Button variant="outline" className="w-full bg-transparent">
                      กลับหน้าแรก
                    </Button>
                  </Link>
                </div>

                <div className="text-sm text-gray-500">
                  <p>หากมีปัญหาในการเข้าสู่ระบบ กรุณาติดต่อฝ่ายสนับสนุน</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Security Tips */}
        {currentStep !== "success" && (
          <div className="mt-6 text-center">
            <Alert>
              <Shield className="h-4 w-4" />
              <AlertDescription className="text-left">
                <strong>เคล็ดลับความปลอดภัย:</strong>
                <ul className="mt-2 text-sm space-y-1">
                  <li>• ไม่แชร์รหัส OTP กับใครทั้งสิ้น</li>
                  <li>• ใช้รหัสผ่านที่แข็งแกร่งและไม่ซ้ำกับที่อื่น</li>
                  <li>• ออกจากระบบเมื่อใช้งานเสร็จ</li>
                </ul>
              </AlertDescription>
            </Alert>
          </div>
        )}
      </div>
    </div>
  )
}
