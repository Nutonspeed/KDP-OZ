"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Progress } from "@/components/ui/progress"
import {
  Factory,
  User,
  Mail,
  Phone,
  Lock,
  Eye,
  EyeOff,
  Building,
  MapPin,
  CheckCircle,
  XCircle,
  ArrowRight,
  ArrowLeft,
  Shield,
  Globe,
  Facebook,
  Chrome,
} from "lucide-react"

export default function RegisterPage() {
  const [currentStep, setCurrentStep] = useState(1)
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [formData, setFormData] = useState({
    // Step 1: Personal Information
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
    // Step 2: Business Information
    companyName: "",
    businessType: "",
    taxId: "",
    address: "",
    district: "",
    province: "",
    postalCode: "",
    website: "",
    description: "",
    // Agreements
    acceptTerms: false,
    acceptPrivacy: false,
    acceptMarketing: false,
  })

  const [passwordStrength, setPasswordStrength] = useState({
    score: 0,
    feedback: [],
    hasLength: false,
    hasUpper: false,
    hasLower: false,
    hasNumber: false,
    hasSpecial: false,
  })

  const [errors, setErrors] = useState<Record<string, string>>({})

  const checkPasswordStrength = (password: string) => {
    const checks = {
      hasLength: password.length >= 8,
      hasUpper: /[A-Z]/.test(password),
      hasLower: /[a-z]/.test(password),
      hasNumber: /\d/.test(password),
      hasSpecial: /[!@#$%^&*(),.?":{}|<>]/.test(password),
    }

    const score = Object.values(checks).filter(Boolean).length
    const feedback = []

    if (!checks.hasLength) feedback.push("ต้องมีอย่างน้อย 8 ตัวอักษร")
    if (!checks.hasUpper) feedback.push("ต้องมีตัวพิมพ์ใหญ่")
    if (!checks.hasLower) feedback.push("ต้องมีตัวพิมพ์เล็ก")
    if (!checks.hasNumber) feedback.push("ต้องมีตัวเลข")
    if (!checks.hasSpecial) feedback.push("ต้องมีอักขระพิเศษ")

    setPasswordStrength({ score, feedback, ...checks })
  }

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData((prev) => ({ ...prev, [field]: value }))

    if (field === "password") {
      checkPasswordStrength(value as string)
    }

    // Clear error when user starts typing
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: "" }))
    }
  }

  const validateStep1 = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.firstName.trim()) newErrors.firstName = "กรุณากรอกชื่อ"
    if (!formData.lastName.trim()) newErrors.lastName = "กรุณากรอกนามสกุล"
    if (!formData.email.trim()) {
      newErrors.email = "กรุณากรอกอีเมล"
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "รูปแบบอีเมลไม่ถูกต้อง"
    }
    if (!formData.phone.trim()) {
      newErrors.phone = "กรุณากรอกเบอร์โทรศัพท์"
    } else if (!/^[0-9]{10}$/.test(formData.phone.replace(/[-\s]/g, ""))) {
      newErrors.phone = "เบอร์โทรศัพท์ไม่ถูกต้อง"
    }
    if (!formData.password) {
      newErrors.password = "กรุณากรอกรหัสผ่าน"
    } else if (passwordStrength.score < 4) {
      newErrors.password = "รหัสผ่านไม่แข็งแกร่งพอ"
    }
    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = "รหัสผ่านไม่ตรงกัน"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const validateStep2 = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.companyName.trim()) newErrors.companyName = "กรุณากรอกชื่อบริษัท"
    if (!formData.businessType) newErrors.businessType = "กรุณาเลือกประเภทธุรกิจ"
    if (!formData.address.trim()) newErrors.address = "กรุณากรอกที่อยู่"
    if (!formData.district.trim()) newErrors.district = "กรุณากรอกเขต/อำเภอ"
    if (!formData.province.trim()) newErrors.province = "กรุณากรอกจังหวัด"
    if (!formData.postalCode.trim()) {
      newErrors.postalCode = "กรุณากรอกรหัสไปรษณีย์"
    } else if (!/^[0-9]{5}$/.test(formData.postalCode)) {
      newErrors.postalCode = "รหัสไปรษณีย์ไม่ถูกต้อง"
    }
    if (!formData.acceptTerms) newErrors.acceptTerms = "กรุณายอมรับข้อตกลงการใช้งาน"
    if (!formData.acceptPrivacy) newErrors.acceptPrivacy = "กรุณายอมรับนโยบายความเป็นส่วนตัว"

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleNextStep = () => {
    if (currentStep === 1 && validateStep1()) {
      setCurrentStep(2)
    }
  }

  const handlePrevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (currentStep === 1) {
      handleNextStep()
      return
    }

    if (validateStep2()) {
      // Submit registration
      console.log("Registration data:", formData)
      // Here you would typically send the data to your API
    }
  }

  const getPasswordStrengthColor = () => {
    if (passwordStrength.score <= 1) return "bg-red-500"
    if (passwordStrength.score <= 2) return "bg-orange-500"
    if (passwordStrength.score <= 3) return "bg-yellow-500"
    if (passwordStrength.score <= 4) return "bg-green-400"
    return "bg-green-500"
  }

  const getPasswordStrengthText = () => {
    if (passwordStrength.score <= 1) return "อ่อนแอมาก"
    if (passwordStrength.score <= 2) return "อ่อนแอ"
    if (passwordStrength.score <= 3) return "ปานกลาง"
    if (passwordStrength.score <= 4) return "แข็งแกร่ง"
    return "แข็งแกร่งมาก"
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <Factory className="h-6 w-6 text-white" />
              </div>
              <div>
                <div className="text-xl font-bold text-gray-900">O-Z/Gedney</div>
                <div className="text-xs text-gray-500">อุปกรณ์ไฟฟ้า</div>
              </div>
            </Link>

            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">มีบัญชีแล้ว?</span>
              <Link href="/auth/login">
                <Button variant="outline">เข้าสู่ระบบ</Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Registration Form */}
      <section className="py-12">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">สมัครสมาชิก</h1>
            <p className="text-gray-600">เข้าร่วมกับเราเพื่อรับสิทธิพิเศษและบริการที่ดีที่สุด</p>
          </div>

          {/* Progress Indicator */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <div className={`flex items-center ${currentStep >= 1 ? "text-blue-600" : "text-gray-400"}`}>
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    currentStep >= 1 ? "bg-blue-600 text-white" : "bg-gray-200"
                  }`}
                >
                  {currentStep > 1 ? <CheckCircle className="h-5 w-5" /> : "1"}
                </div>
                <span className="ml-2 text-sm font-medium">ข้อมูลส่วนตัว</span>
              </div>
              <div className={`flex items-center ${currentStep >= 2 ? "text-blue-600" : "text-gray-400"}`}>
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    currentStep >= 2 ? "bg-blue-600 text-white" : "bg-gray-200"
                  }`}
                >
                  2
                </div>
                <span className="ml-2 text-sm font-medium">ข้อมูลธุรกิจ</span>
              </div>
            </div>
            <Progress value={(currentStep / 2) * 100} className="h-2" />
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                {currentStep === 1 ? (
                  <>
                    <User className="h-5 w-5 mr-2" />
                    ข้อมูลส่วนตัว
                  </>
                ) : (
                  <>
                    <Building className="h-5 w-5 mr-2" />
                    ข้อมูลธุรกิจ
                  </>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {currentStep === 1 && (
                  <>
                    {/* Social Registration */}
                    <div className="space-y-3">
                      <Button type="button" variant="outline" className="w-full bg-transparent">
                        <Chrome className="h-4 w-4 mr-2" />
                        สมัครด้วย Google
                      </Button>
                      <Button type="button" variant="outline" className="w-full bg-transparent">
                        <Facebook className="h-4 w-4 mr-2" />
                        สมัครด้วย Facebook
                      </Button>
                    </div>

                    <div className="relative">
                      <div className="absolute inset-0 flex items-center">
                        <div className="w-full border-t border-gray-300" />
                      </div>
                      <div className="relative flex justify-center text-sm">
                        <span className="px-2 bg-white text-gray-500">หรือสมัครด้วยอีเมล</span>
                      </div>
                    </div>

                    {/* Personal Information */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="firstName">ชื่อ *</Label>
                        <Input
                          id="firstName"
                          value={formData.firstName}
                          onChange={(e) => handleInputChange("firstName", e.target.value)}
                          className={errors.firstName ? "border-red-500" : ""}
                        />
                        {errors.firstName && <p className="text-red-500 text-sm mt-1">{errors.firstName}</p>}
                      </div>
                      <div>
                        <Label htmlFor="lastName">นามสกุล *</Label>
                        <Input
                          id="lastName"
                          value={formData.lastName}
                          onChange={(e) => handleInputChange("lastName", e.target.value)}
                          className={errors.lastName ? "border-red-500" : ""}
                        />
                        {errors.lastName && <p className="text-red-500 text-sm mt-1">{errors.lastName}</p>}
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="email">อีเมล *</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="email"
                          type="email"
                          value={formData.email}
                          onChange={(e) => handleInputChange("email", e.target.value)}
                          className={`pl-10 ${errors.email ? "border-red-500" : ""}`}
                          placeholder="example@company.com"
                        />
                      </div>
                      {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
                    </div>

                    <div>
                      <Label htmlFor="phone">เบอร์โทรศัพท์ *</Label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="phone"
                          value={formData.phone}
                          onChange={(e) => handleInputChange("phone", e.target.value)}
                          className={`pl-10 ${errors.phone ? "border-red-500" : ""}`}
                          placeholder="08X-XXX-XXXX"
                        />
                      </div>
                      {errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone}</p>}
                    </div>

                    <div>
                      <Label htmlFor="password">รหัสผ่าน *</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="password"
                          type={showPassword ? "text" : "password"}
                          value={formData.password}
                          onChange={(e) => handleInputChange("password", e.target.value)}
                          className={`pl-10 pr-10 ${errors.password ? "border-red-500" : ""}`}
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-3 text-gray-400 hover:text-gray-600"
                        >
                          {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>
                      {formData.password && (
                        <div className="mt-2">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-sm text-gray-600">ความแข็งแกร่ง:</span>
                            <span
                              className={`text-sm font-medium ${
                                passwordStrength.score <= 2
                                  ? "text-red-500"
                                  : passwordStrength.score <= 3
                                    ? "text-yellow-500"
                                    : "text-green-500"
                              }`}
                            >
                              {getPasswordStrengthText()}
                            </span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div
                              className={`h-2 rounded-full transition-all ${getPasswordStrengthColor()}`}
                              style={{ width: `${(passwordStrength.score / 5) * 100}%` }}
                            />
                          </div>
                          <div className="mt-2 grid grid-cols-2 gap-2 text-xs">
                            <div
                              className={`flex items-center ${passwordStrength.hasLength ? "text-green-600" : "text-gray-400"}`}
                            >
                              {passwordStrength.hasLength ? (
                                <CheckCircle className="h-3 w-3 mr-1" />
                              ) : (
                                <XCircle className="h-3 w-3 mr-1" />
                              )}
                              8+ ตัวอักษร
                            </div>
                            <div
                              className={`flex items-center ${passwordStrength.hasUpper ? "text-green-600" : "text-gray-400"}`}
                            >
                              {passwordStrength.hasUpper ? (
                                <CheckCircle className="h-3 w-3 mr-1" />
                              ) : (
                                <XCircle className="h-3 w-3 mr-1" />
                              )}
                              ตัวพิมพ์ใหญ่
                            </div>
                            <div
                              className={`flex items-center ${passwordStrength.hasLower ? "text-green-600" : "text-gray-400"}`}
                            >
                              {passwordStrength.hasLower ? (
                                <CheckCircle className="h-3 w-3 mr-1" />
                              ) : (
                                <XCircle className="h-3 w-3 mr-1" />
                              )}
                              ตัวพิมพ์เล็ก
                            </div>
                            <div
                              className={`flex items-center ${passwordStrength.hasNumber ? "text-green-600" : "text-gray-400"}`}
                            >
                              {passwordStrength.hasNumber ? (
                                <CheckCircle className="h-3 w-3 mr-1" />
                              ) : (
                                <XCircle className="h-3 w-3 mr-1" />
                              )}
                              ตัวเลข
                            </div>
                            <div
                              className={`flex items-center ${passwordStrength.hasSpecial ? "text-green-600" : "text-gray-400"} col-span-2`}
                            >
                              {passwordStrength.hasSpecial ? (
                                <CheckCircle className="h-3 w-3 mr-1" />
                              ) : (
                                <XCircle className="h-3 w-3 mr-1" />
                              )}
                              อักขระพิเศษ (!@#$%^&*)
                            </div>
                          </div>
                        </div>
                      )}
                      {errors.password && <p className="text-red-500 text-sm mt-1">{errors.password}</p>}
                    </div>

                    <div>
                      <Label htmlFor="confirmPassword">ยืนยันรหัสผ่าน *</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="confirmPassword"
                          type={showConfirmPassword ? "text" : "password"}
                          value={formData.confirmPassword}
                          onChange={(e) => handleInputChange("confirmPassword", e.target.value)}
                          className={`pl-10 pr-10 ${errors.confirmPassword ? "border-red-500" : ""}`}
                        />
                        <button
                          type="button"
                          onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                          className="absolute right-3 top-3 text-gray-400 hover:text-gray-600"
                        >
                          {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>
                      {formData.confirmPassword && formData.password === formData.confirmPassword && (
                        <div className="flex items-center mt-1 text-green-600 text-sm">
                          <CheckCircle className="h-4 w-4 mr-1" />
                          รหัสผ่านตรงกัน
                        </div>
                      )}
                      {errors.confirmPassword && <p className="text-red-500 text-sm mt-1">{errors.confirmPassword}</p>}
                    </div>
                  </>
                )}

                {currentStep === 2 && (
                  <>
                    {/* Business Information */}
                    <div>
                      <Label htmlFor="companyName">ชื่อบริษัท/ร้านค้า *</Label>
                      <div className="relative">
                        <Building className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="companyName"
                          value={formData.companyName}
                          onChange={(e) => handleInputChange("companyName", e.target.value)}
                          className={`pl-10 ${errors.companyName ? "border-red-500" : ""}`}
                          placeholder="บริษัท ABC จำกัด"
                        />
                      </div>
                      {errors.companyName && <p className="text-red-500 text-sm mt-1">{errors.companyName}</p>}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="businessType">ประเภทธุรกิจ *</Label>
                        <Select
                          value={formData.businessType}
                          onValueChange={(value) => handleInputChange("businessType", value)}
                        >
                          <SelectTrigger className={errors.businessType ? "border-red-500" : ""}>
                            <SelectValue placeholder="เลือกประเภทธุรกิจ" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="contractor">ผู้รับเหมา</SelectItem>
                            <SelectItem value="distributor">ผู้จำหน่าย</SelectItem>
                            <SelectItem value="retailer">ร้านค้าปลีก</SelectItem>
                            <SelectItem value="manufacturer">ผู้ผลิต</SelectItem>
                            <SelectItem value="installer">ช่างติดตั้ง</SelectItem>
                            <SelectItem value="other">อื่นๆ</SelectItem>
                          </SelectContent>
                        </Select>
                        {errors.businessType && <p className="text-red-500 text-sm mt-1">{errors.businessType}</p>}
                      </div>
                      <div>
                        <Label htmlFor="taxId">เลขประจำตัวผู้เสียภาษี</Label>
                        <Input
                          id="taxId"
                          value={formData.taxId}
                          onChange={(e) => handleInputChange("taxId", e.target.value)}
                          placeholder="0123456789012"
                          maxLength={13}
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="address">ที่อยู่ *</Label>
                      <div className="relative">
                        <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Textarea
                          id="address"
                          value={formData.address}
                          onChange={(e) => handleInputChange("address", e.target.value)}
                          className={`pl-10 ${errors.address ? "border-red-500" : ""}`}
                          placeholder="เลขที่ ถนน ตำบล"
                          rows={3}
                        />
                      </div>
                      {errors.address && <p className="text-red-500 text-sm mt-1">{errors.address}</p>}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <Label htmlFor="district">เขต/อำเภอ *</Label>
                        <Input
                          id="district"
                          value={formData.district}
                          onChange={(e) => handleInputChange("district", e.target.value)}
                          className={errors.district ? "border-red-500" : ""}
                        />
                        {errors.district && <p className="text-red-500 text-sm mt-1">{errors.district}</p>}
                      </div>
                      <div>
                        <Label htmlFor="province">จังหวัด *</Label>
                        <Input
                          id="province"
                          value={formData.province}
                          onChange={(e) => handleInputChange("province", e.target.value)}
                          className={errors.province ? "border-red-500" : ""}
                        />
                        {errors.province && <p className="text-red-500 text-sm mt-1">{errors.province}</p>}
                      </div>
                      <div>
                        <Label htmlFor="postalCode">รหัสไปรษณีย์ *</Label>
                        <Input
                          id="postalCode"
                          value={formData.postalCode}
                          onChange={(e) => handleInputChange("postalCode", e.target.value)}
                          className={errors.postalCode ? "border-red-500" : ""}
                          maxLength={5}
                        />
                        {errors.postalCode && <p className="text-red-500 text-sm mt-1">{errors.postalCode}</p>}
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="website">เว็บไซต์</Label>
                      <div className="relative">
                        <Globe className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="website"
                          value={formData.website}
                          onChange={(e) => handleInputChange("website", e.target.value)}
                          className="pl-10"
                          placeholder="https://www.example.com"
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="description">รายละเอียดธุรกิจ</Label>
                      <Textarea
                        id="description"
                        value={formData.description}
                        onChange={(e) => handleInputChange("description", e.target.value)}
                        placeholder="บอกเล่าเกี่ยวกับธุรกิจของคุณ..."
                        rows={3}
                      />
                    </div>

                    {/* Terms and Conditions */}
                    <div className="space-y-4 pt-4 border-t">
                      <div className="flex items-start space-x-2">
                        <Checkbox
                          id="acceptTerms"
                          checked={formData.acceptTerms}
                          onCheckedChange={(checked) => handleInputChange("acceptTerms", checked as boolean)}
                        />
                        <div className="text-sm">
                          <label htmlFor="acceptTerms" className="cursor-pointer">
                            ฉันยอมรับ{" "}
                            <Link href="/terms" className="text-blue-600 hover:underline">
                              ข้อตกลงการใช้งาน
                            </Link>{" "}
                            *
                          </label>
                          {errors.acceptTerms && <p className="text-red-500 text-xs mt-1">{errors.acceptTerms}</p>}
                        </div>
                      </div>

                      <div className="flex items-start space-x-2">
                        <Checkbox
                          id="acceptPrivacy"
                          checked={formData.acceptPrivacy}
                          onCheckedChange={(checked) => handleInputChange("acceptPrivacy", checked as boolean)}
                        />
                        <div className="text-sm">
                          <label htmlFor="acceptPrivacy" className="cursor-pointer">
                            ฉันยอมรับ{" "}
                            <Link href="/privacy" className="text-blue-600 hover:underline">
                              นโยบายความเป็นส่วนตัว
                            </Link>{" "}
                            *
                          </label>
                          {errors.acceptPrivacy && <p className="text-red-500 text-xs mt-1">{errors.acceptPrivacy}</p>}
                        </div>
                      </div>

                      <div className="flex items-start space-x-2">
                        <Checkbox
                          id="acceptMarketing"
                          checked={formData.acceptMarketing}
                          onCheckedChange={(checked) => handleInputChange("acceptMarketing", checked as boolean)}
                        />
                        <label htmlFor="acceptMarketing" className="text-sm cursor-pointer">
                          ฉันต้องการรับข่าวสารและโปรโมชั่นพิเศษ
                        </label>
                      </div>
                    </div>
                  </>
                )}

                {/* Navigation Buttons */}
                <div className="flex justify-between pt-6">
                  {currentStep > 1 ? (
                    <Button type="button" variant="outline" onClick={handlePrevStep}>
                      <ArrowLeft className="h-4 w-4 mr-2" />
                      ย้อนกลับ
                    </Button>
                  ) : (
                    <div />
                  )}

                  <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                    {currentStep === 1 ? (
                      <>
                        ถัดไป
                        <ArrowRight className="h-4 w-4 ml-2" />
                      </>
                    ) : (
                      <>
                        <Shield className="h-4 w-4 mr-2" />
                        สมัครสมาชิก
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          {/* Security Notice */}
          <div className="mt-8 text-center">
            <div className="flex items-center justify-center space-x-2 text-sm text-gray-600">
              <Shield className="h-4 w-4" />
              <span>ข้อมูลของคุณได้รับการปกป้องด้วยระบบความปลอดภัยระดับสูง</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
