"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Search,
  ShoppingCart,
  Star,
  Grid,
  List,
  Filter,
  Factory,
  Package,
  AlertTriangle,
  Info,
  SlidersHorizontal,
} from "lucide-react"

// ข้อมูลสินค้าทั้งหมดสำหรับการค้นหา
const allProducts = [
  {
    id: "lb-17",
    code: "LB-17",
    name: "ท่อร้อยสายไฟ Form 7 รุ่น LB-17",
    category: "ท่อร้อยสายไฟ Form 7",
    brand: "O-Z/Gedney",
    price: 850,
    originalPrice: 950,
    size: '1/2"',
    material: "เหล็กหล่อ",
    rating: "NEMA 3R",
    weight: "0.85 กก.",
    image: "/placeholder.svg?height=200&width=200&text=LB-17",
    inStock: true,
    stockQuantity: 245,
    discount: 11,
    reviews: 156,
    avgRating: 4.9,
    description: "ท่อร้อยสายไฟ Form 7 ขนาด 1/2 นิ้ว วัสดุเหล็กหล่อ สำหรับงานทั่วไป",
    features: ["เหล็กหล่อคุณภาพสูง", "ชุบผิวป้องกันการกัดกร่อน", "เกลียว NPT มาตรฐาน", "รับรอง UL Listed"],
  },
  {
    id: "lb-27",
    code: "LB-27",
    name: "ท่อร้อยสายไฟ Form 7 รุ่น LB-27",
    category: "ท่อร้อยสายไฟ Form 7",
    brand: "O-Z/Gedney",
    price: 1250,
    originalPrice: 1400,
    size: '3/4"',
    material: "เหล็กหล่อ",
    rating: "NEMA 3R",
    weight: "1.2 กก.",
    image: "/placeholder.svg?height=200&width=200&text=LB-27",
    inStock: true,
    stockQuantity: 156,
    discount: 11,
    reviews: 89,
    avgRating: 4.8,
    description: "ท่อร้อยสายไฟ Form 7 ขนาด 3/4 นิ้ว วัสดุเหล็กหล่อ สำหรับงานทั่วไป",
    features: ["เหล็กหล่อคุณภาพสูง", "ชุบผิวป้องกันการกัดกร่อน", "เกลียว NPT มาตรฐาน", "รับรอง UL Listed"],
  },
  {
    id: "rc-100",
    code: "RC-100",
    name: "ข้อต่อท่อเหล็กแข็ง รุ่น RC-100",
    category: "ข้อต่อท่อเหล็กแข็ง",
    brand: "O-Z/Gedney",
    price: 485,
    originalPrice: 550,
    size: '1"',
    material: "เหล็กกล้า",
    rating: "งานทั่วไป",
    weight: "0.65 กก.",
    image: "/placeholder.svg?height=200&width=200&text=RC-100",
    inStock: true,
    stockQuantity: 234,
    discount: 12,
    reviews: 234,
    avgRating: 4.7,
    description: "ข้อต่อท่อเหล็กแข็ง ขนาด 1 นิ้ว วัสดุเหล็กกล้า",
    features: ["เหล็กกล้าคุณภาพสูง", "ชุบสังกะสี", "เกลียว NPT มาตรฐาน", "ทนทานต่อการกัดกร่อน"],
  },
  {
    id: "lt-50",
    code: "LT-50",
    name: "ข้อต่อท่อยืดหยุ่นกันน้ำ รุ่น LT-50",
    category: "ข้อต่อท่อยืดหยุ่นกันน้ำ",
    brand: "O-Z/Gedney",
    price: 320,
    originalPrice: 380,
    size: '1/2"',
    material: "สังกะสีหล่อ",
    rating: "NEMA 4",
    weight: "0.45 กก.",
    image: "/placeholder.svg?height=200&width=200&text=LT-50",
    inStock: true,
    stockQuantity: 178,
    discount: 16,
    reviews: 178,
    avgRating: 4.6,
    description: "ข้อต่อท่อยืดหยุ่นกันน้ำ ขนาด 1/2 นิ้ว สำหรับงานกันน้ำ",
    features: ["กันน้ำ IP67", "ยืดหยุ่นสูง", "ทนต่อสารเคมี", "รับรอง UL Listed"],
  },
  {
    id: "bc-50g",
    code: "BC-50G",
    name: "ฝาครอบแบบเรียบ BC-50G",
    category: "ฝาครอบและปะเก็น",
    brand: "O-Z/Gedney",
    price: 200,
    originalPrice: 230,
    size: '1/2"',
    material: "เหล็กเหนียว HDG",
    rating: "NEMA 3R",
    weight: "0.3 กก.",
    image: "/placeholder.svg?height=200&width=200&text=BC-50G",
    inStock: true,
    stockQuantity: 1124,
    discount: 13,
    reviews: 89,
    avgRating: 4.7,
    description: "ฝาครอบแบบเรียบ ขนาด 1/2 นิ้ว สำหรับป้องกันสภาพอากาศ",
    features: ["ป้องกันสภาพอากาศ", "ติดตั้งง่าย", "ชุบสังกะสีร้อน", "รับรอง NEMA 3R"],
  },
  {
    id: "jb-100",
    code: "JB-100",
    name: "กล่องต่อสายไฟ JB-100",
    category: "กล่องต่อสายไฟ",
    brand: "O-Z/Gedney",
    price: 750,
    originalPrice: 850,
    size: '4" x 4"',
    material: "อลูมิเนียม",
    rating: "NEMA 4X",
    weight: "1.1 กก.",
    image: "/placeholder.svg?height=200&width=200&text=JB-100",
    inStock: true,
    stockQuantity: 67,
    discount: 12,
    reviews: 45,
    avgRating: 4.8,
    description: "กล่องต่อสายไฟอลูมิเนียม ขนาด 4x4 นิ้ว กันน้ำ",
    features: ["อลูมิเนียมคุณภาพสูง", "กันน้ำ NEMA 4X", "ทนต่อการกัดกร่อน", "รับรอง UL Listed"],
  },
]

export default function SearchPage() {
  const searchParams = useSearchParams()
  const initialQuery = searchParams.get("q") || ""

  const [searchTerm, setSearchTerm] = useState(initialQuery)
  const [filteredProducts, setFilteredProducts] = useState(allProducts)
  const [sortBy, setSortBy] = useState("relevance")
  const [viewMode, setViewMode] = useState("grid")
  const [priceRange, setPriceRange] = useState("all")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [brandFilter, setBrandFilter] = useState("all")
  const [sizeFilter, setSizeFilter] = useState("all")
  const [ratingFilter, setRatingFilter] = useState("all")
  const [cartItems, setCartItems] = useState(0)
  const [showFilters, setShowFilters] = useState(false)

  // ฟิลเตอร์และค้นหาสินค้า
  useEffect(() => {
    let filtered = allProducts

    // ค้นหาตามคำค้นหา
    if (searchTerm) {
      filtered = filtered.filter(
        (product) =>
          product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          product.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
          product.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
          product.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
          product.features.some((feature) => feature.toLowerCase().includes(searchTerm.toLowerCase())),
      )
    }

    // ฟิลเตอร์ตามราคา
    if (priceRange !== "all") {
      filtered = filtered.filter((product) => {
        if (priceRange === "low") return product.price < 500
        if (priceRange === "medium") return product.price >= 500 && product.price < 1000
        if (priceRange === "high") return product.price >= 1000
        return true
      })
    }

    // ฟิลเตอร์ตามหมวดหมู่
    if (categoryFilter !== "all") {
      filtered = filtered.filter((product) => product.category === categoryFilter)
    }

    // ฟิลเตอร์ตามแบรนด์
    if (brandFilter !== "all") {
      filtered = filtered.filter((product) => product.brand === brandFilter)
    }

    // ฟิลเตอร์ตามขนาด
    if (sizeFilter !== "all") {
      filtered = filtered.filter((product) => product.size === sizeFilter)
    }

    // ฟิลเตอร์ตามคะแนน
    if (ratingFilter !== "all") {
      const minRating = Number.parseFloat(ratingFilter)
      filtered = filtered.filter((product) => product.avgRating >= minRating)
    }

    // เรียงลำดับ
    filtered.sort((a, b) => {
      switch (sortBy) {
        case "price-low":
          return a.price - b.price
        case "price-high":
          return b.price - a.price
        case "rating":
          return b.avgRating - a.avgRating
        case "reviews":
          return b.reviews - a.reviews
        case "name":
          return a.name.localeCompare(b.name)
        case "newest":
          return b.id.localeCompare(a.id)
        default: // relevance
          if (searchTerm) {
            // คำนวณคะแนนความเกี่ยวข้อง
            const getRelevanceScore = (product: any) => {
              let score = 0
              const term = searchTerm.toLowerCase()

              if (product.name.toLowerCase().includes(term)) score += 10
              if (product.code.toLowerCase().includes(term)) score += 8
              if (product.category.toLowerCase().includes(term)) score += 6
              if (product.description.toLowerCase().includes(term)) score += 4
              product.features.forEach((feature: string) => {
                if (feature.toLowerCase().includes(term)) score += 2
              })

              return score
            }

            return getRelevanceScore(b) - getRelevanceScore(a)
          }
          return a.name.localeCompare(b.name)
      }
    })

    setFilteredProducts(filtered)
  }, [searchTerm, priceRange, categoryFilter, brandFilter, sizeFilter, ratingFilter, sortBy])

  const addToCart = (productId: string) => {
    setCartItems((prev) => prev + 1)
  }

  const clearAllFilters = () => {
    setPriceRange("all")
    setCategoryFilter("all")
    setBrandFilter("all")
    setSizeFilter("all")
    setRatingFilter("all")
  }

  // ดึงค่าที่ไม่ซ้ำสำหรับฟิลเตอร์
  const categories = [...new Set(allProducts.map((p) => p.category))]
  const brands = [...new Set(allProducts.map((p) => p.brand))]
  const sizes = [...new Set(allProducts.map((p) => p.size))]

  const ProductCard = ({ product }: { product: any }) => (
    <Card className="group hover:shadow-lg transition-shadow duration-300">
      <CardHeader className="p-0">
        <div className="relative overflow-hidden rounded-t-lg">
          <Link href={`/products/${product.id}`}>
            <img
              src={product.image || "/placeholder.svg"}
              alt={product.name}
              className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
            />
          </Link>
          {product.discount > 0 && (
            <Badge className="absolute top-2 left-2 bg-red-500 text-white">-{product.discount}%</Badge>
          )}
          {product.stockQuantity < 50 && (
            <Badge className="absolute top-2 right-2 bg-orange-500 text-white">
              <AlertTriangle className="h-3 w-3 mr-1" />
              เหลือน้อย
            </Badge>
          )}
          {!product.inStock && <Badge className="absolute top-2 right-2 bg-gray-500 text-white">หมด</Badge>}
        </div>
      </CardHeader>
      <CardContent className="p-4">
        <div className="space-y-3">
          <div>
            <div className="flex items-center justify-between mb-1">
              <Badge variant="outline" className="text-xs">
                {product.code}
              </Badge>
              <Badge variant="secondary" className="text-xs">
                {product.size}
              </Badge>
            </div>
            <Link href={`/products/${product.id}`}>
              <h3 className="font-semibold text-lg line-clamp-2 hover:text-blue-600">{product.name}</h3>
            </Link>
            <p className="text-sm text-gray-600">{product.material}</p>
          </div>

          <div className="flex items-center space-x-1">
            <div className="flex items-center">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`h-4 w-4 ${
                    i < Math.floor(product.avgRating) ? "text-yellow-400 fill-current" : "text-gray-300"
                  }`}
                />
              ))}
            </div>
            <span className="text-sm text-gray-600">
              {product.avgRating} ({product.reviews} รีวิว)
            </span>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center space-x-2">
                  <span className="text-xl font-bold text-blue-600">฿{product.price.toLocaleString()}</span>
                  {product.originalPrice > product.price && (
                    <span className="text-sm text-gray-500 line-through">
                      ฿{product.originalPrice.toLocaleString()}
                    </span>
                  )}
                </div>
                <p className="text-xs text-gray-500">คงเหลือ: {product.stockQuantity} ชิ้น</p>
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs text-gray-600">
                <span>น้ำหนัก:</span>
                <span>{product.weight}</span>
              </div>
              <div className="flex items-center justify-between text-xs text-gray-600">
                <span>เกรด:</span>
                <span>{product.rating}</span>
              </div>
            </div>

            <div className="flex flex-wrap gap-1">
              {product.features.slice(0, 2).map((feature: string, index: number) => (
                <Badge key={index} variant="outline" className="text-xs">
                  {feature}
                </Badge>
              ))}
            </div>
          </div>

          <div className="flex space-x-2">
            <Button
              onClick={() => addToCart(product.id)}
              disabled={!product.inStock}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
              size="sm"
            >
              <ShoppingCart className="h-4 w-4 mr-2" />
              {product.inStock ? "เพิ่มลงตะกร้า" : "สินค้าหมด"}
            </Button>
            <Link href={`/products/${product.id}`}>
              <Button variant="outline" size="sm">
                <Info className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </CardContent>
    </Card>
  )

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <Factory className="h-6 w-6 text-white" />
              </div>
              <div>
                <div className="text-xl font-bold text-gray-900">O-Z/Gedney</div>
                <div className="text-xs text-gray-500">อุปกรณ์ไฟฟ้า</div>
              </div>
            </Link>

            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-gray-700 hover:text-blue-600">
                หน้าแรก
              </Link>
              <Link href="/categories" className="text-gray-700 hover:text-blue-600">
                สินค้า
              </Link>
              <Link href="/catalog" className="text-gray-700 hover:text-blue-600">
                แคตตาล็อก
              </Link>
              <Link href="/technical" className="text-gray-700 hover:text-blue-600">
                ข้อมูลเทคนิค
              </Link>
              <Link href="/about" className="text-gray-700 hover:text-blue-600">
                เกี่ยวกับเรา
              </Link>
              <Link href="/contact" className="text-gray-700 hover:text-blue-600">
                ติดต่อ
              </Link>
            </nav>

            <div className="flex items-center space-x-4">
              <Link href="/cart">
                <Button variant="outline" className="relative bg-transparent">
                  <ShoppingCart className="h-5 w-5" />
                  {cartItems > 0 && (
                    <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                      {cartItems}
                    </Badge>
                  )}
                </Button>
              </Link>
              <Link href="/admin">
                <Button variant="outline">แอดมิน</Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Search Header */}
      <section className="bg-white py-6 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center space-x-4 mb-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <Input
                placeholder="ค้นหาสินค้า รหัสสินค้า หรือหมวดหมู่..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 h-12 text-lg"
              />
            </div>
            <Button variant="outline" onClick={() => setShowFilters(!showFilters)} className="h-12 px-6">
              <SlidersHorizontal className="h-5 w-5 mr-2" />
              ตัวกรอง
            </Button>
          </div>

          {searchTerm && (
            <div className="text-sm text-gray-600">
              ผลการค้นหาสำหรับ "<span className="font-semibold">{searchTerm}</span>" พบ{" "}
              <span className="font-semibold">{filteredProducts.length}</span> รายการ
            </div>
          )}
        </div>
      </section>

      {/* Filters */}
      {showFilters && (
        <section className="bg-gray-50 py-6 border-b">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">ช่วงราคา</label>
                <Select value={priceRange} onValueChange={setPriceRange}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">ทุกราคา</SelectItem>
                    <SelectItem value="low">ต่ำกว่า ฿500</SelectItem>
                    <SelectItem value="medium">฿500 - ฿1,000</SelectItem>
                    <SelectItem value="high">สูงกว่า ฿1,000</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">หมวดหมู่</label>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">ทุกหมวดหมู่</SelectItem>
                    {categories.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">แบรนด์</label>
                <Select value={brandFilter} onValueChange={setBrandFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">ทุกแบรนด์</SelectItem>
                    {brands.map((brand) => (
                      <SelectItem key={brand} value={brand}>
                        {brand}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">ขนาด</label>
                <Select value={sizeFilter} onValueChange={setSizeFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">ทุกขนาด</SelectItem>
                    {sizes.map((size) => (
                      <SelectItem key={size} value={size}>
                        {size}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">คะแนนรีวิว</label>
                <Select value={ratingFilter} onValueChange={setRatingFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">ทุกคะแนน</SelectItem>
                    <SelectItem value="4.5">4.5 ดาวขึ้นไป</SelectItem>
                    <SelectItem value="4.0">4.0 ดาวขึ้นไป</SelectItem>
                    <SelectItem value="3.5">3.5 ดาวขึ้นไป</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-end">
                <Button variant="outline" onClick={clearAllFilters} className="w-full bg-transparent">
                  ล้างตัวกรอง
                </Button>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Sort and View Controls */}
      <section className="bg-white py-4 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">แสดง {filteredProducts.length} รายการ</span>
              {(priceRange !== "all" ||
                categoryFilter !== "all" ||
                brandFilter !== "all" ||
                sizeFilter !== "all" ||
                ratingFilter !== "all") && (
                <div className="flex items-center space-x-2">
                  <Filter className="h-4 w-4 text-gray-500" />
                  <span className="text-sm text-gray-500">มีการกรอง</span>
                </div>
              )}
            </div>

            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <label className="text-sm font-medium text-gray-700">เรียงตาม:</label>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="relevance">ความเกี่ยวข้อง</SelectItem>
                    <SelectItem value="name">ชื่อสินค้า</SelectItem>
                    <SelectItem value="price-low">ราคา: ต่ำ → สูง</SelectItem>
                    <SelectItem value="price-high">ราคา: สูง → ต่ำ</SelectItem>
                    <SelectItem value="rating">คะแนนสูงสุด</SelectItem>
                    <SelectItem value="reviews">รีวิวมากสุด</SelectItem>
                    <SelectItem value="newest">ใหม่ล่าสุด</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex space-x-2">
                <Button
                  variant={viewMode === "grid" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setViewMode("grid")}
                >
                  <Grid className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === "list" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setViewMode("list")}
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Search Results */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {filteredProducts.length > 0 ? (
            <div
              className={`grid gap-6 ${
                viewMode === "grid" ? "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4" : "grid-cols-1"
              }`}
            >
              {filteredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Package className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">ไม่พบสินค้าที่ค้นหา</h3>
              <p className="text-gray-600 mb-4">
                {searchTerm ? `ไม่พบสินค้าที่ตรงกับ "${searchTerm}"` : "ลองปรับเปลี่ยนตัวกรองหรือคำค้นหา"}
              </p>
              <div className="space-x-4">
                <Button
                  onClick={() => {
                    setSearchTerm("")
                    clearAllFilters()
                  }}
                  variant="outline"
                >
                  ล้างการค้นหา
                </Button>
                <Link href="/categories">
                  <Button>เลือกดูตามหมวดหมู่</Button>
                </Link>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Search Suggestions */}
      {searchTerm && filteredProducts.length === 0 && (
        <section className="py-8 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">คำแนะนำการค้นหา</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {["ท่อร้อยสายไฟ", "ข้อต่อ", "กล่องไฟฟ้า", "ฝาครอบ"].map((suggestion) => (
                <Button
                  key={suggestion}
                  variant="outline"
                  onClick={() => setSearchTerm(suggestion)}
                  className="justify-start"
                >
                  <Search className="h-4 w-4 mr-2" />
                  {suggestion}
                </Button>
              ))}
            </div>
          </div>
        </section>
      )}
    </div>
  )
}
