"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  ShoppingCart,
  Star,
  Heart,
  Share2,
  ArrowLeft,
  Factory,
  Shield,
  Package,
  Truck,
  CheckCircle,
  AlertTriangle,
  Download,
  Phone,
  Mail,
  Ruler,
  Weight,
  Settings,
  FileText,
  Plus,
  Minus,
} from "lucide-react"

// ข้อมูลสินค้าตัวอย่าง
const productData = {
  "lb-17": {
    id: "lb-17",
    name: "ท่อร้อยสายไฟ Form 7 รุ่น LB-17",
    partNumber: "LB-17",
    category: "ท่อร้อยสายไฟ Form 7",
    brand: "O-Z/Gedney",
    price: 850.0,
    originalPrice: 950.0,
    discount: 11,
    inStock: true,
    stockQuantity: 245,
    minOrderQty: 1,
    rating: 4.9,
    reviewCount: 156,
    description:
      "ท่อร้อยสายไฟ Form 7 ขนาด 1/2 นิ้ว ทำจากเหล็กหล่อคุณภาพสูง เหมาะสำหรับงานทั่วไปและพื้นที่อันตราย ได้รับการรับรอง UL Listed และ CSA Certified",
    longDescription: `ท่อร้อยสายไฟ Form 7 รุ่น LB-17 เป็นผลิตภัณฑ์คุณภาพสูงจาก O-Z/Gedney ที่ได้รับการยอมรับในอุตสาหกรรมไฟฟ้ามากกว่า 147 ปี 
    
    ออกแบบมาเพื่อให้การเข้าถึงสายไฟที่สะดวกและปลอดภัย เหมาะสำหรับการใช้งานในสภาพแวดล้อมที่หลากหลาย ตั้งแต่งานพาณิชยกรรมไปจนถึงอุตสาหกรรมหนัก
    
    วัสดุเหล็กหล่อที่ใช้ผ่านการทดสอบความแข็งแรงและความทนทานตามมาตรฐานสากล พร้อมด้วยการชุบผิวที่ป้องกันการกัดกร่อนได้อย่างมีประสิทธิภาพ`,
    images: [
      "/placeholder.svg?height=400&width=400&text=LB-17+Main",
      "/placeholder.svg?height=400&width=400&text=LB-17+Side",
      "/placeholder.svg?height=400&width=400&text=LB-17+Detail",
      "/placeholder.svg?height=400&width=400&text=LB-17+Install",
    ],
    specifications: {
      size: '1/2"',
      material: "เหล็กหล่อ (Cast Iron)",
      finish: "ชุบไฟฟ้า (Electroplated)",
      thread: "NPT (National Pipe Thread)",
      rating: "NEMA 3R",
      weight: "0.85 กิโลกรัม",
      dimensions: "4.5 x 3.2 x 2.8 นิ้ว",
      operatingTemp: "-40°C ถึง +75°C",
      ipRating: "IP54",
      wireRange: "14 AWG ถึง 1/0 AWG",
    },
    certifications: [
      { name: "UL Listed", number: "E12345", image: "/placeholder.svg?height=60&width=60&text=UL" },
      { name: "CSA Certified", number: "LR67890", image: "/placeholder.svg?height=60&width=60&text=CSA" },
      { name: "NEMA 3R", number: "NEMA-3R", image: "/placeholder.svg?height=60&width=60&text=NEMA" },
    ],
    applications: ["งานไฟฟ้าทั่วไป", "อาคารพาณิชย์", "โรงงานอุตสาหกรรม", "สถานีไฟฟ้า", "ระบบไฟฟ้าภายนอกอาคาร", "งานซ่อมบำรุง"],
    features: [
      "วัสดุเหล็กหล่อคุณภาพสูง",
      "ชุบผิวป้องกันการกัดกร่อน",
      "เกลียว NPT มาตรฐาน",
      "ได้รับการรับรอง UL Listed",
      "ออกแบบให้เข้าถึงสายไฟได้ง่าย",
      "ทนทานต่อสภาพอากาศ",
    ],
    accessories: [
      { name: "ฝาครอบ LB-17-C", price: 180, image: "/placeholder.svg?height=100&width=100&text=Cover" },
      { name: "ปะเก็น LB-17-G", price: 45, image: "/placeholder.svg?height=100&width=100&text=Gasket" },
      { name: "สกรูยึด LB-17-S", price: 25, image: "/placeholder.svg?height=100&width=100&text=Screw" },
    ],
    relatedProducts: [
      {
        id: "lb-27",
        name: "ท่อร้อยสายไฟ Form 7 รุ่น LB-27",
        price: 1250,
        image: "/placeholder.svg?height=150&width=150&text=LB-27",
      },
      {
        id: "lb-37",
        name: "ท่อร้อยสายไฟ Form 7 รุ่น LB-37",
        price: 1850,
        image: "/placeholder.svg?height=150&width=150&text=LB-37",
      },
      {
        id: "t-17",
        name: "ท่อร้อยสายไฟ Form 7 รุ่น T-17",
        price: 920,
        image: "/placeholder.svg?height=150&width=150&text=T-17",
      },
    ],
    documents: [
      { name: "แคตตาล็อกสินค้า", type: "PDF", size: "2.5 MB", url: "#" },
      { name: "คู่มือการติดตั้ง", type: "PDF", size: "1.8 MB", url: "#" },
      { name: "ใบรับรอง UL", type: "PDF", size: "0.9 MB", url: "#" },
      { name: "ข้อมูลเทคนิค", type: "PDF", size: "3.2 MB", url: "#" },
    ],
    shipping: {
      weight: "0.85 กก.",
      dimensions: "15 x 12 x 10 ซม.",
      shippingClass: "มาตรฐาน",
      estimatedDays: "3-5 วันทำการ",
    },
    warranty: {
      period: "2 ปี",
      coverage: "ครอบคลุมข้อบกพร่องจากการผลิต",
      terms: "ภายใต้เงื่อนไขการใช้งานปกติ",
    },
  },
}

export default function ProductDetailPage() {
  const params = useParams()
  const productId = params.id as string
  const [product, setProduct] = useState<any>(null)
  const [selectedImage, setSelectedImage] = useState(0)
  const [quantity, setQuantity] = useState(1)
  const [cartItems, setCartItems] = useState(0)
  const [isWishlisted, setIsWishlisted] = useState(false)
  const [activeTab, setActiveTab] = useState("description")

  useEffect(() => {
    // โหลดข้อมูลสินค้า
    const productInfo = productData[productId as keyof typeof productData]
    if (productInfo) {
      setProduct(productInfo)
    }
  }, [productId])

  const addToCart = () => {
    setCartItems((prev) => prev + quantity)
    // ในระบบจริงจะส่งข้อมูลไปยัง API หรือ Context
  }

  const toggleWishlist = () => {
    setIsWishlisted(!isWishlisted)
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Package className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-2">ไม่พบสินค้าที่ค้นหา</h1>
          <p className="text-gray-600 mb-4">สินค้าที่คุณค้นหาไม่มีในระบบ</p>
          <Link href="/categories">
            <Button>
              <ArrowLeft className="h-4 w-4 mr-2" />
              กลับไปหมวดหมู่สินค้า
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <Factory className="h-6 w-6 text-white" />
              </div>
              <div>
                <div className="text-xl font-bold text-gray-900">O-Z/Gedney</div>
                <div className="text-xs text-gray-500">อุปกรณ์ไฟฟ้า</div>
              </div>
            </Link>

            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-gray-700 hover:text-blue-600">
                หน้าแรก
              </Link>
              <Link href="/categories" className="text-gray-700 hover:text-blue-600">
                สินค้า
              </Link>
              <Link href="/catalog" className="text-gray-700 hover:text-blue-600">
                แคตตาล็อก
              </Link>
              <Link href="/technical" className="text-gray-700 hover:text-blue-600">
                ข้อมูลเทคนิค
              </Link>
              <Link href="/about" className="text-gray-700 hover:text-blue-600">
                เกี่ยวกับเรา
              </Link>
              <Link href="/contact" className="text-gray-700 hover:text-blue-600">
                ติดต่อ
              </Link>
            </nav>

            <div className="flex items-center space-x-4">
              <Link href="/cart">
                <Button variant="outline" className="relative bg-transparent">
                  <ShoppingCart className="h-5 w-5" />
                  {cartItems > 0 && (
                    <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                      {cartItems}
                    </Badge>
                  )}
                </Button>
              </Link>
              <Link href="/admin">
                <Button variant="outline">แอดมิน</Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Breadcrumb */}
      <div className="bg-gray-100 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center space-x-2 text-sm">
            <Link href="/" className="text-gray-500 hover:text-gray-700">
              หน้าแรก
            </Link>
            <span className="text-gray-400">/</span>
            <Link href="/categories" className="text-gray-500 hover:text-gray-700">
              สินค้า
            </Link>
            <span className="text-gray-400">/</span>
            <Link href={`/categories/${product.category}`} className="text-gray-500 hover:text-gray-700">
              {product.category}
            </Link>
            <span className="text-gray-400">/</span>
            <span className="text-gray-900 font-medium">{product.partNumber}</span>
          </div>
        </div>
      </div>

      {/* Product Detail */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Product Images */}
            <div className="space-y-4">
              <div className="aspect-square bg-white rounded-lg border overflow-hidden">
                <img
                  src={product.images[selectedImage] || "/placeholder.svg"}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="grid grid-cols-4 gap-2">
                {product.images.map((image: string, index: number) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    className={`aspect-square bg-white rounded-lg border overflow-hidden ${
                      selectedImage === index ? "ring-2 ring-blue-600" : ""
                    }`}
                  >
                    <img
                      src={image || "/placeholder.svg"}
                      alt={`${product.name} ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Product Info */}
            <div className="space-y-6">
              <div>
                <div className="flex items-center space-x-2 mb-2">
                  <Badge variant="outline">{product.partNumber}</Badge>
                  <Badge className="bg-blue-600">{product.brand}</Badge>
                  {product.inStock ? (
                    <Badge className="bg-green-600">
                      <CheckCircle className="h-3 w-3 mr-1" />
                      พร้อมส่ง
                    </Badge>
                  ) : (
                    <Badge className="bg-red-600">
                      <AlertTriangle className="h-3 w-3 mr-1" />
                      สินค้าหมด
                    </Badge>
                  )}
                </div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2">{product.name}</h1>
                <p className="text-gray-600">{product.description}</p>
              </div>

              {/* Rating */}
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-5 w-5 ${
                        i < Math.floor(product.rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                      }`}
                    />
                  ))}
                </div>
                <span className="text-lg font-semibold">{product.rating}</span>
                <span className="text-gray-600">({product.reviewCount} รีวิว)</span>
              </div>

              {/* Price */}
              <div className="space-y-2">
                <div className="flex items-center space-x-4">
                  <span className="text-3xl font-bold text-blue-600">฿{product.price.toLocaleString()}</span>
                  {product.originalPrice > product.price && (
                    <span className="text-xl text-gray-500 line-through">
                      ฿{product.originalPrice.toLocaleString()}
                    </span>
                  )}
                  {product.discount > 0 && <Badge className="bg-red-500 text-white">ประหยัด {product.discount}%</Badge>}
                </div>
                <p className="text-sm text-gray-600">
                  คงเหลือ: <span className="font-semibold">{product.stockQuantity}</span> ชิ้น
                </p>
              </div>

              {/* Key Specifications */}
              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="font-semibold mb-3">ข้อมูลสำคัญ</h3>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div className="flex items-center space-x-2">
                    <Ruler className="h-4 w-4 text-gray-500" />
                    <span>ขนาด: {product.specifications.size}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Settings className="h-4 w-4 text-gray-500" />
                    <span>วัสดุ: {product.specifications.material}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Shield className="h-4 w-4 text-gray-500" />
                    <span>มาตรฐาน: {product.specifications.rating}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Weight className="h-4 w-4 text-gray-500" />
                    <span>น้ำหนัก: {product.specifications.weight}</span>
                  </div>
                </div>
              </div>

              {/* Quantity and Add to Cart */}
              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <label className="font-medium">จำนวน:</label>
                  <div className="flex items-center border rounded-lg">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      disabled={quantity <= 1}
                    >
                      <Minus className="h-4 w-4" />
                    </Button>
                    <Input
                      type="number"
                      value={quantity}
                      onChange={(e) => setQuantity(Math.max(1, Number.parseInt(e.target.value) || 1))}
                      className="w-20 text-center border-0"
                      min="1"
                    />
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setQuantity(quantity + 1)}
                      disabled={quantity >= product.stockQuantity}
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                  <span className="text-sm text-gray-600">(ขั้นต่ำ {product.minOrderQty} ชิ้น)</span>
                </div>

                <div className="flex space-x-4">
                  <Button
                    onClick={addToCart}
                    disabled={!product.inStock}
                    className="flex-1 bg-blue-600 hover:bg-blue-700"
                    size="lg"
                  >
                    <ShoppingCart className="h-5 w-5 mr-2" />
                    {product.inStock ? "เพิ่มลงตะกร้า" : "สินค้าหมด"}
                  </Button>
                  <Button
                    variant="outline"
                    size="lg"
                    onClick={toggleWishlist}
                    className={isWishlisted ? "text-red-600 border-red-600" : ""}
                  >
                    <Heart className={`h-5 w-5 ${isWishlisted ? "fill-current" : ""}`} />
                  </Button>
                  <Button variant="outline" size="lg">
                    <Share2 className="h-5 w-5" />
                  </Button>
                </div>

                <div className="text-sm text-gray-600 space-y-1">
                  <div className="flex items-center space-x-2">
                    <Truck className="h-4 w-4" />
                    <span>จัดส่งภายใน {product.shipping.estimatedDays}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Shield className="h-4 w-4" />
                    <span>รับประกัน {product.warranty.period}</span>
                  </div>
                </div>
              </div>

              {/* Contact for Quote */}
              <div className="bg-blue-50 rounded-lg p-4">
                <h3 className="font-semibold text-blue-900 mb-2">ต้องการใบเสนอราคา?</h3>
                <p className="text-blue-700 text-sm mb-3">สำหรับการสั่งซื้อจำนวนมาก หรือต้องการคำปรึกษา</p>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm" className="border-blue-600 text-blue-600 bg-transparent">
                    <Phone className="h-4 w-4 mr-2" />
                    โทร 02-123-4567
                  </Button>
                  <Button variant="outline" size="sm" className="border-blue-600 text-blue-600 bg-transparent">
                    <Mail className="h-4 w-4 mr-2" />
                    ส่งอีเมล
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Product Details Tabs */}
      <section className="py-8 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="description">รายละเอียด</TabsTrigger>
              <TabsTrigger value="specifications">ข้อมูลเทคนิค</TabsTrigger>
              <TabsTrigger value="certifications">ใบรับรอง</TabsTrigger>
              <TabsTrigger value="documents">เอกสาร</TabsTrigger>
              <TabsTrigger value="reviews">รีวิว</TabsTrigger>
            </TabsList>

            <TabsContent value="description" className="mt-6">
              <div className="prose max-w-none">
                <h3 className="text-xl font-semibold mb-4">รายละเอียดสินค้า</h3>
                <div className="whitespace-pre-line text-gray-700 mb-6">{product.longDescription}</div>

                <h4 className="text-lg font-semibold mb-3">คุณสมบัติเด่น</h4>
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-2 mb-6">
                  {product.features.map((feature: string, index: number) => (
                    <li key={index} className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>

                <h4 className="text-lg font-semibold mb-3">การใช้งาน</h4>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {product.applications.map((app: string, index: number) => (
                    <Badge key={index} variant="outline" className="justify-center">
                      {app}
                    </Badge>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="specifications" className="mt-6">
              <div className="space-y-6">
                <h3 className="text-xl font-semibold">ข้อมูลเทคนิค</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {Object.entries(product.specifications).map(([key, value]) => (
                    <div key={key} className="flex justify-between py-2 border-b">
                      <span className="font-medium capitalize">
                        {key === "size" && "ขนาด"}
                        {key === "material" && "วัสดุ"}
                        {key === "finish" && "ผิวหน้า"}
                        {key === "thread" && "เกลียว"}
                        {key === "rating" && "มาตรฐาน"}
                        {key === "weight" && "น้ำหนัก"}
                        {key === "dimensions" && "ขนาดภายนอก"}
                        {key === "operatingTemp" && "อุณหภูมิใช้งาน"}
                        {key === "ipRating" && "ระดับป้องกัน IP"}
                        {key === "wireRange" && "ขนาดสายไฟ"}
                      </span>
                      <span className="text-gray-600">{value as string}</span>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="certifications" className="mt-6">
              <div className="space-y-6">
                <h3 className="text-xl font-semibold">ใบรับรองและมาตรฐาน</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {product.certifications.map((cert: any, index: number) => (
                    <Card key={index}>
                      <CardContent className="p-6 text-center">
                        <img
                          src={cert.image || "/placeholder.svg"}
                          alt={cert.name}
                          className="w-16 h-16 mx-auto mb-4"
                        />
                        <h4 className="font-semibold mb-2">{cert.name}</h4>
                        <p className="text-sm text-gray-600">หมายเลข: {cert.number}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="documents" className="mt-6">
              <div className="space-y-6">
                <h3 className="text-xl font-semibold">เอกสารและคู่มือ</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {product.documents.map((doc: any, index: number) => (
                    <Card key={index}>
                      <CardContent className="p-4">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                            <FileText className="h-6 w-6 text-red-600" />
                          </div>
                          <div className="flex-1">
                            <h4 className="font-semibold">{doc.name}</h4>
                            <p className="text-sm text-gray-600">
                              {doc.type} • {doc.size}
                            </p>
                          </div>
                          <Button variant="outline" size="sm">
                            <Download className="h-4 w-4 mr-2" />
                            ดาวน์โหลด
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="reviews" className="mt-6">
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-semibold">รีวิวจากลูกค้า</h3>
                  <Button variant="outline">เขียนรีวิว</Button>
                </div>

                <div className="bg-gray-50 rounded-lg p-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="text-center">
                      <div className="text-4xl font-bold text-blue-600 mb-2">{product.rating}</div>
                      <div className="flex justify-center mb-2">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`h-5 w-5 ${
                              i < Math.floor(product.rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                            }`}
                          />
                        ))}
                      </div>
                      <p className="text-gray-600">{product.reviewCount} รีวิว</p>
                    </div>

                    <div className="md:col-span-2 space-y-2">
                      {[5, 4, 3, 2, 1].map((stars) => (
                        <div key={stars} className="flex items-center space-x-2">
                          <span className="text-sm w-8">{stars}</span>
                          <Star className="h-4 w-4 text-yellow-400 fill-current" />
                          <div className="flex-1 bg-gray-200 rounded-full h-2">
                            <div
                              className="bg-yellow-400 h-2 rounded-full"
                              style={{
                                width: `${stars === 5 ? 70 : stars === 4 ? 20 : stars === 3 ? 8 : stars === 2 ? 2 : 0}%`,
                              }}
                            ></div>
                          </div>
                          <span className="text-sm text-gray-600 w-8">
                            {stars === 5 ? 109 : stars === 4 ? 31 : stars === 3 ? 12 : stars === 2 ? 3 : 1}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Sample Reviews */}
                <div className="space-y-4">
                  {[
                    {
                      name: "วิชัย ช.",
                      rating: 5,
                      date: "15 ธ.ค. 2567",
                      comment: "สินค้าคุณภาพดีมาก ใช้งานได้ดี การจัดส่งรวดเร็ว แนะนำเลยครับ",
                    },
                    {
                      name: "สมชาย ป.",
                      rating: 5,
                      date: "10 ธ.ค. 2567",
                      comment: "ได้ตามที่สั่ง คุณภาพดี ราคาเหมาะสม จะสั่งซื้อเพิ่มอีก",
                    },
                    {
                      name: "นิรันดร์ ส.",
                      rating: 4,
                      date: "5 ธ.ค. 2567",
                      comment: "สินค้าดี แต่การจัดส่งช้าไปหน่อย โดยรวมพอใจครับ",
                    },
                  ].map((review, index) => (
                    <Card key={index}>
                      <CardContent className="p-4">
                        <div className="flex items-start space-x-4">
                          <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                            <span className="font-semibold text-blue-600">{review.name.charAt(0)}</span>
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-2">
                              <span className="font-semibold">{review.name}</span>
                              <div className="flex">
                                {[...Array(5)].map((_, i) => (
                                  <Star
                                    key={i}
                                    className={`h-4 w-4 ${
                                      i < review.rating ? "text-yellow-400 fill-current" : "text-gray-300"
                                    }`}
                                  />
                                ))}
                              </div>
                              <span className="text-sm text-gray-500">{review.date}</span>
                            </div>
                            <p className="text-gray-700">{review.comment}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Accessories */}
      <section className="py-8 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">อุปกรณ์เสริม</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {product.accessories.map((accessory: any, index: number) => (
              <Card key={index}>
                <CardContent className="p-4">
                  <img
                    src={accessory.image || "/placeholder.svg"}
                    alt={accessory.name}
                    className="w-full h-32 object-cover rounded mb-4"
                  />
                  <h3 className="font-semibold mb-2">{accessory.name}</h3>
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-bold text-blue-600">฿{accessory.price}</span>
                    <Button size="sm">เพิ่มลงตะกร้า</Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Related Products */}
      <section className="py-8 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">สินค้าที่เกี่ยวข้อง</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {product.relatedProducts.map((relatedProduct: any, index: number) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-4">
                  <img
                    src={relatedProduct.image || "/placeholder.svg"}
                    alt={relatedProduct.name}
                    className="w-full h-40 object-cover rounded mb-4"
                  />
                  <h3 className="font-semibold mb-2 line-clamp-2">{relatedProduct.name}</h3>
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-bold text-blue-600">฿{relatedProduct.price.toLocaleString()}</span>
                    <Link href={`/products/${relatedProduct.id}`}>
                      <Button size="sm" variant="outline">
                        ดูรายละเอียด
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
