"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import {
  Package,
  Search,
  Filter,
  Eye,
  Download,
  RefreshCw,
  Truck,
  CheckCircle,
  Clock,
  XCircle,
  Star,
  MessageCircle,
  Phone,
  Mail,
  MapPin,
  CreditCard,
  ArrowLeft,
  ChevronDown,
  ChevronUp,
  Copy,
  Share2,
} from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"

// Mock orders data
const mockOrders = [
  {
    id: "ORD-2024-001",
    date: "2024-01-15",
    status: "delivered",
    total: 15750.0,
    items: 5,
    customer: {
      name: "บริษัท ABC จำกัด",
      email: "abc@company.com",
      phone: "02-123-4567",
    },
    shipping: {
      address: "123 ถนนสุขุมวิท แขวงคลองเตย เขตคลองเตย กรุงเทพฯ 10110",
      method: "Standard Delivery",
      cost: 0,
      trackingNumber: "TH1234567890",
      estimatedDelivery: "2024-01-18",
      actualDelivery: "2024-01-17",
    },
    payment: {
      method: "Bank Transfer",
      status: "paid",
      paidAt: "2024-01-15T14:30:00Z",
      reference: "TXN-ABC-001",
    },
    products: [
      {
        id: 1,
        code: "LB-75G",
        name: "Malleable Iron Conduit Body LB-75G",
        size: '3/4"',
        quantity: 10,
        price: 360.0,
        image: "/placeholder.svg?height=60&width=60&text=LB-75G",
      },
      {
        id: 2,
        code: "T-75G",
        name: "Malleable Iron Conduit Body T-75G",
        size: '3/4"',
        quantity: 5,
        price: 450.0,
        image: "/placeholder.svg?height=60&width=60&text=T-75G",
      },
    ],
    timeline: [
      { status: "Order Placed", date: "2024-01-15T10:00:00Z", completed: true },
      { status: "Payment Confirmed", date: "2024-01-15T14:30:00Z", completed: true },
      { status: "Processing", date: "2024-01-16T09:00:00Z", completed: true },
      { status: "Shipped", date: "2024-01-16T16:00:00Z", completed: true },
      { status: "Delivered", date: "2024-01-17T11:30:00Z", completed: true },
    ],
  },
  {
    id: "ORD-2024-002",
    date: "2024-01-14",
    status: "shipped",
    total: 8950.0,
    items: 3,
    customer: {
      name: "คุณสมชาย ใจดี",
      email: "somchai@email.com",
      phone: "08-1234-5678",
    },
    shipping: {
      address: "456 ถนนพหลโยธิน ตำบลบางบัวทอง อำเภอบางบัวทอง นนทบุรี 11000",
      method: "Express Delivery",
      cost: 150,
      trackingNumber: "TH0987654321",
      estimatedDelivery: "2024-01-16",
    },
    payment: {
      method: "Credit Card",
      status: "paid",
      paidAt: "2024-01-14T16:45:00Z",
      reference: "CC-XYZ-002",
    },
    products: [
      {
        id: 3,
        code: "BC-75G",
        name: "Flat Top Cover BC-75G",
        size: '3/4"',
        quantity: 20,
        price: 215.0,
        image: "/placeholder.svg?height=60&width=60&text=BC-75G",
      },
    ],
    timeline: [
      { status: "Order Placed", date: "2024-01-14T15:00:00Z", completed: true },
      { status: "Payment Confirmed", date: "2024-01-14T16:45:00Z", completed: true },
      { status: "Processing", date: "2024-01-15T08:00:00Z", completed: true },
      { status: "Shipped", date: "2024-01-15T14:00:00Z", completed: true },
      { status: "Out for Delivery", date: "2024-01-16T08:00:00Z", completed: false },
    ],
  },
  {
    id: "ORD-2024-003",
    date: "2024-01-13",
    status: "processing",
    total: 25600.0,
    items: 8,
    customer: {
      name: "บริษัท XYZ เอ็นจิเนียริ่ง",
      email: "xyz@engineering.com",
      phone: "02-987-6543",
    },
    shipping: {
      address: "789 ถนนรัชดาภิเษก แขวงดินแดง เขตดินแดง กรุงเทพฯ 10400",
      method: "Standard Delivery",
      cost: 0,
      estimatedDelivery: "2024-01-18",
    },
    payment: {
      method: "Bank Transfer",
      status: "pending",
      reference: "PENDING-003",
    },
    products: [
      {
        id: 4,
        code: "LB-250G",
        name: "Malleable Iron Conduit Body LB-250G",
        size: '2-1/2"',
        quantity: 5,
        price: 2300.0,
        image: "/placeholder.svg?height=60&width=60&text=LB-250G",
      },
    ],
    timeline: [
      { status: "Order Placed", date: "2024-01-13T11:00:00Z", completed: true },
      { status: "Awaiting Payment", date: "2024-01-13T11:05:00Z", completed: false },
    ],
  },
]

export default function OrdersPage() {
  const [orders, setOrders] = useState(mockOrders)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [expandedOrder, setExpandedOrder] = useState<string | null>(null)
  const [selectedOrder, setSelectedOrder] = useState<any>(null)
  const [isReviewDialogOpen, setIsReviewDialogOpen] = useState(false)
  const [reviewRating, setReviewRating] = useState(0)
  const [reviewText, setReviewText] = useState("")

  const filteredOrders = orders.filter((order) => {
    const matchesSearch =
      order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.customer.name.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || order.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "delivered":
        return "bg-green-100 text-green-800 border-green-200"
      case "shipped":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "processing":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "cancelled":
        return "bg-red-100 text-red-800 border-red-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "delivered":
        return <CheckCircle className="h-4 w-4" />
      case "shipped":
        return <Truck className="h-4 w-4" />
      case "processing":
        return <Clock className="h-4 w-4" />
      case "cancelled":
        return <XCircle className="h-4 w-4" />
      default:
        return <Package className="h-4 w-4" />
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "delivered":
        return "จัดส่งแล้ว"
      case "shipped":
        return "กำลังจัดส่ง"
      case "processing":
        return "กำลังดำเนินการ"
      case "cancelled":
        return "ยกเลิกแล้ว"
      default:
        return "ไม่ทราบสถานะ"
    }
  }

  const handleCopyOrderId = (orderId: string) => {
    navigator.clipboard.writeText(orderId)
    // You could add a toast notification here
  }

  const handleReorder = (order: any) => {
    // Add products to cart and redirect to cart
    console.log("Reordering:", order.id)
  }

  const handleCancelOrder = (orderId: string) => {
    setOrders(orders.map((order) => (order.id === orderId ? { ...order, status: "cancelled" } : order)))
  }

  const handleSubmitReview = () => {
    console.log("Review submitted:", { rating: reviewRating, text: reviewText })
    setIsReviewDialogOpen(false)
    setReviewRating(0)
    setReviewText("")
  }

  const OrderTimeline = ({ timeline }: { timeline: any[] }) => (
    <div className="space-y-4">
      {timeline.map((step, index) => (
        <div key={index} className="flex items-start space-x-3">
          <div
            className={`w-8 h-8 rounded-full flex items-center justify-center ${
              step.completed ? "bg-green-100 text-green-600" : "bg-gray-100 text-gray-400"
            }`}
          >
            {step.completed ? <CheckCircle className="h-4 w-4" /> : <Clock className="h-4 w-4" />}
          </div>
          <div className="flex-1">
            <p className={`font-medium ${step.completed ? "text-gray-900" : "text-gray-500"}`}>{step.status}</p>
            {step.date && <p className="text-sm text-gray-500">{new Date(step.date).toLocaleString("th-TH")}</p>}
          </div>
        </div>
      ))}
    </div>
  )

  const OrderDetails = ({ order }: { order: any }) => (
    <Tabs defaultValue="details" className="w-full">
      <TabsList className="grid w-full grid-cols-4">
        <TabsTrigger value="details">รายละเอียด</TabsTrigger>
        <TabsTrigger value="tracking">ติดตาม</TabsTrigger>
        <TabsTrigger value="shipping">การจัดส่ง</TabsTrigger>
        <TabsTrigger value="payment">การชำระเงิน</TabsTrigger>
      </TabsList>

      <TabsContent value="details" className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">สินค้าในคำสั่งซื้อ</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {order.products.map((product: any) => (
                <div key={product.id} className="flex items-center space-x-3 p-3 border rounded-lg">
                  <Image
                    src={product.image || "/placeholder.svg"}
                    alt={product.code}
                    width={50}
                    height={50}
                    className="rounded"
                  />
                  <div className="flex-1">
                    <p className="font-medium">{product.code}</p>
                    <p className="text-sm text-gray-600">{product.name}</p>
                    <p className="text-xs text-gray-500">ขนาด: {product.size}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">฿{(product.price * product.quantity).toLocaleString()}</p>
                    <p className="text-sm text-gray-600">จำนวน: {product.quantity}</p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">สรุปคำสั่งซื้อ</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span>ราคาสินค้า:</span>
                <span>฿{(order.total - (order.shipping?.cost || 0)).toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span>ค่าจัดส่ง:</span>
                <span>{order.shipping?.cost ? `฿${order.shipping.cost.toLocaleString()}` : "ฟรี"}</span>
              </div>
              <Separator />
              <div className="flex justify-between font-bold text-lg">
                <span>ยอดรวม:</span>
                <span>฿{order.total.toLocaleString()}</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </TabsContent>

      <TabsContent value="tracking" className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">ติดตามสถานะคำสั่งซื้อ</CardTitle>
          </CardHeader>
          <CardContent>
            <OrderTimeline timeline={order.timeline} />
          </CardContent>
        </Card>

        {order.shipping?.trackingNumber && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">ข้อมูลการจัดส่ง</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                <div>
                  <p className="font-medium">หมายเลขติดตาม</p>
                  <p className="text-sm text-gray-600">{order.shipping.trackingNumber}</p>
                </div>
                <Button variant="outline" size="sm" onClick={() => handleCopyOrderId(order.shipping.trackingNumber)}>
                  <Copy className="h-4 w-4 mr-2" />
                  คัดลอก
                </Button>
              </div>

              {order.status === "shipped" && (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>ความคืบหน้าการจัดส่ง</span>
                    <span>75%</span>
                  </div>
                  <Progress value={75} className="h-2" />
                  <p className="text-sm text-gray-600">
                    คาดว่าจะได้รับสินค้าในวันที่ {new Date(order.shipping.estimatedDelivery).toLocaleDateString("th-TH")}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </TabsContent>

      <TabsContent value="shipping" className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">ที่อยู่จัดส่ง</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <MapPin className="h-5 w-5 text-gray-400 mt-0.5" />
                <div>
                  <p className="font-medium">{order.customer.name}</p>
                  <p className="text-sm text-gray-600">{order.shipping.address}</p>
                  <p className="text-sm text-gray-600">{order.customer.phone}</p>
                </div>
              </div>

              <Separator />

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="font-medium">วิธีการจัดส่ง:</p>
                  <p className="text-gray-600">{order.shipping.method}</p>
                </div>
                <div>
                  <p className="font-medium">ค่าจัดส่ง:</p>
                  <p className="text-gray-600">
                    {order.shipping.cost ? `฿${order.shipping.cost.toLocaleString()}` : "ฟรี"}
                  </p>
                </div>
                {order.shipping.estimatedDelivery && (
                  <div>
                    <p className="font-medium">วันที่คาดว่าจะได้รับ:</p>
                    <p className="text-gray-600">
                      {new Date(order.shipping.estimatedDelivery).toLocaleDateString("th-TH")}
                    </p>
                  </div>
                )}
                {order.shipping.actualDelivery && (
                  <div>
                    <p className="font-medium">วันที่ได้รับจริง:</p>
                    <p className="text-green-600">
                      {new Date(order.shipping.actualDelivery).toLocaleDateString("th-TH")}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="payment" className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">ข้อมูลการชำระเงิน</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <CreditCard className="h-5 w-5 text-gray-400" />
                  <div>
                    <p className="font-medium">{order.payment.method}</p>
                    <p className="text-sm text-gray-600">หมายเลขอ้างอิง: {order.payment.reference}</p>
                  </div>
                </div>
                <Badge
                  className={
                    order.payment.status === "paid" ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"
                  }
                >
                  {order.payment.status === "paid" ? "ชำระแล้ว" : "รอชำระ"}
                </Badge>
              </div>

              {order.payment.paidAt && (
                <div className="text-sm text-gray-600">
                  <p>ชำระเงินเมื่อ: {new Date(order.payment.paidAt).toLocaleString("th-TH")}</p>
                </div>
              )}

              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>ยอดรวม:</span>
                  <span className="font-bold">฿{order.total.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>
  )

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  กลับหน้าแรก
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">ประวัติคำสั่งซื้อ</h1>
                <p className="text-gray-600">ติดตามและจัดการคำสั่งซื้อของคุณ</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                ส่งออกรายงาน
              </Button>
              <Button variant="outline" size="sm">
                <RefreshCw className="h-4 w-4 mr-2" />
                รีเฟรช
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    placeholder="ค้นหาด้วยหมายเลขคำสั่งซื้อหรือชื่อลูกค้า..."
                    className="pl-10"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="สถานะ" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">ทุกสถานะ</SelectItem>
                  <SelectItem value="processing">กำลังดำเนินการ</SelectItem>
                  <SelectItem value="shipped">กำลังจัดส่ง</SelectItem>
                  <SelectItem value="delivered">จัดส่งแล้ว</SelectItem>
                  <SelectItem value="cancelled">ยกเลิกแล้ว</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline">
                <Filter className="h-4 w-4 mr-2" />
                ตัวกรองเพิ่มเติม
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Orders List */}
        <div className="space-y-4">
          {filteredOrders.map((order) => (
            <Card key={order.id} className="overflow-hidden">
              <CardContent className="p-0">
                {/* Order Header */}
                <div className="p-6 border-b bg-white">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div>
                        <div className="flex items-center space-x-2">
                          <h3 className="font-bold text-lg">{order.id}</h3>
                          <Button variant="ghost" size="sm" onClick={() => handleCopyOrderId(order.id)}>
                            <Copy className="h-3 w-3" />
                          </Button>
                        </div>
                        <p className="text-sm text-gray-600">
                          สั่งซื้อเมื่อ {new Date(order.date).toLocaleDateString("th-TH")}
                        </p>
                        <p className="text-sm text-gray-600">{order.customer.name}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <p className="font-bold text-lg">฿{order.total.toLocaleString()}</p>
                        <p className="text-sm text-gray-600">{order.items} รายการ</p>
                      </div>
                      <Badge className={getStatusColor(order.status)}>
                        {getStatusIcon(order.status)}
                        <span className="ml-1">{getStatusText(order.status)}</span>
                      </Badge>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setExpandedOrder(expandedOrder === order.id ? null : order.id)}
                      >
                        {expandedOrder === order.id ? (
                          <ChevronUp className="h-4 w-4" />
                        ) : (
                          <ChevronDown className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>

                  {/* Quick Actions */}
                  <div className="flex items-center justify-between mt-4 pt-4 border-t">
                    <div className="flex items-center space-x-2">
                      <Button variant="outline" size="sm" onClick={() => setSelectedOrder(order)}>
                        <Eye className="h-4 w-4 mr-2" />
                        ดูรายละเอียด
                      </Button>
                      {order.shipping?.trackingNumber && (
                        <Button variant="outline" size="sm">
                          <Truck className="h-4 w-4 mr-2" />
                          ติดตามพัสดุ
                        </Button>
                      )}
                      {order.status === "delivered" && (
                        <Button variant="outline" size="sm" onClick={() => setIsReviewDialogOpen(true)}>
                          <Star className="h-4 w-4 mr-2" />
                          รีวิว
                        </Button>
                      )}
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button variant="outline" size="sm">
                        <Download className="h-4 w-4 mr-2" />
                        ใบเสร็จ
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => handleReorder(order)}>
                        <RefreshCw className="h-4 w-4 mr-2" />
                        สั่งซื้อซ้ำ
                      </Button>
                      {order.status === "processing" && (
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-red-600 hover:text-red-700 bg-transparent"
                          onClick={() => handleCancelOrder(order.id)}
                        >
                          <XCircle className="h-4 w-4 mr-2" />
                          ยกเลิก
                        </Button>
                      )}
                    </div>
                  </div>
                </div>

                {/* Expanded Order Details */}
                {expandedOrder === order.id && (
                  <div className="p-6 bg-gray-50">
                    <OrderDetails order={order} />
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredOrders.length === 0 && (
          <Card>
            <CardContent className="p-12 text-center">
              <Package className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">ไม่พบคำสั่งซื้อ</h3>
              <p className="text-gray-600 mb-4">
                {searchTerm || statusFilter !== "all" ? "ไม่พบคำสั่งซื้อที่ตรงกับเงื่อนไขการค้นหา" : "คุณยังไม่มีคำสั่งซื้อ"}
              </p>
              <Link href="/categories">
                <Button>เริ่มช้อปปิ้ง</Button>
              </Link>
            </CardContent>
          </Card>
        )}

        {/* Customer Support */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>ต้องการความช่วยเหลือ?</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2 bg-transparent">
                <MessageCircle className="h-6 w-6" />
                <span>แชทสด</span>
                <span className="text-xs text-gray-500">ตอบกลับทันที</span>
              </Button>
              <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2 bg-transparent">
                <Phone className="h-6 w-6" />
                <span>โทรศัพท์</span>
                <span className="text-xs text-gray-500">0-2925-9633-4</span>
              </Button>
              <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2 bg-transparent">
                <Mail className="h-6 w-6" />
                <span>อีเมล</span>
                <span className="text-xs text-gray-500">support@kdp.co.th</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Order Details Dialog */}
      {selectedOrder && (
        <Dialog open={!!selectedOrder} onOpenChange={() => setSelectedOrder(null)}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center justify-between">
                <span>รายละเอียดคำสั่งซื้อ {selectedOrder.id}</span>
                <div className="flex items-center space-x-2">
                  <Badge className={getStatusColor(selectedOrder.status)}>
                    {getStatusIcon(selectedOrder.status)}
                    <span className="ml-1">{getStatusText(selectedOrder.status)}</span>
                  </Badge>
                  <Button variant="ghost" size="sm">
                    <Share2 className="h-4 w-4" />
                  </Button>
                </div>
              </DialogTitle>
            </DialogHeader>
            <OrderDetails order={selectedOrder} />
          </DialogContent>
        </Dialog>
      )}

      {/* Review Dialog */}
      <Dialog open={isReviewDialogOpen} onOpenChange={setIsReviewDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>รีวิวและให้คะแนน</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>ให้คะแนน</Label>
              <div className="flex items-center space-x-1 mt-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    onClick={() => setReviewRating(star)}
                    className={`p-1 ${star <= reviewRating ? "text-yellow-400" : "text-gray-300"}`}
                  >
                    <Star className="h-6 w-6 fill-current" />
                  </button>
                ))}
              </div>
            </div>
            <div>
              <Label htmlFor="review">ความคิดเห็น</Label>
              <Textarea
                id="review"
                placeholder="แบ่งปันประสบการณ์การใช้งานของคุณ..."
                value={reviewText}
                onChange={(e) => setReviewText(e.target.value)}
                className="mt-2"
              />
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setIsReviewDialogOpen(false)}>
                ยกเลิก
              </Button>
              <Button onClick={handleSubmitReview} disabled={reviewRating === 0}>
                ส่งรีวิว
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
