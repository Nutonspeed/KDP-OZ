"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Factory,
  Phone,
  Mail,
  MapPin,
  Clock,
  Send,
  MessageSquare,
  FileText,
  Users,
  Headphones,
  Facebook,
  Twitter,
  Linkedin,
  Youtube,
} from "lucide-react"

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    subject: "",
    category: "",
    message: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // จำลองการส่งข้อมูล
    await new Promise((resolve) => setTimeout(resolve, 2000))

    setIsSubmitting(false)
    setSubmitted(true)
  }

  if (submitted) {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-white shadow-sm border-b">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <Link href="/" className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                  <Factory className="h-6 w-6 text-white" />
                </div>
                <div>
                  <div className="text-xl font-bold text-gray-900">O-Z/Gedney</div>
                  <div className="text-xs text-gray-500">อุปกรณ์ไฟฟ้า</div>
                </div>
              </Link>

              <nav className="hidden md:flex items-center space-x-8">
                <Link href="/" className="text-gray-700 hover:text-blue-600">
                  หน้าแรก
                </Link>
                <Link href="/categories" className="text-gray-700 hover:text-blue-600">
                  สินค้า
                </Link>
                <Link href="/catalog" className="text-gray-700 hover:text-blue-600">
                  แคตตาล็อก
                </Link>
                <Link href="/technical" className="text-gray-700 hover:text-blue-600">
                  ข้อมูลเทคนิค
                </Link>
                <Link href="/about" className="text-gray-700 hover:text-blue-600">
                  เกี่ยวกับเรา
                </Link>
                <Link href="/contact" className="text-blue-600 font-medium">
                  ติดต่อ
                </Link>
              </nav>

              <div className="flex items-center space-x-4">
                <Link href="/admin">
                  <Button variant="outline">แอดมิน</Button>
                </Link>
              </div>
            </div>
          </div>
        </header>

        {/* Success Message */}
        <div className="flex items-center justify-center min-h-[60vh]">
          <Card className="max-w-md">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Send className="h-8 w-8 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">ส่งข้อความสำเร็จ!</h2>
              <p className="text-gray-600 mb-6">ขอบคุณที่ติดต่อเรา เราจะตอบกลับภายใน 24 ชั่วโมง</p>
              <div className="space-y-3">
                <Link href="/">
                  <Button className="w-full">กลับหน้าแรก</Button>
                </Link>
                <Button variant="outline" className="w-full bg-transparent" onClick={() => setSubmitted(false)}>
                  ส่งข้อความอีกครั้ง
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <Factory className="h-6 w-6 text-white" />
              </div>
              <div>
                <div className="text-xl font-bold text-gray-900">O-Z/Gedney</div>
                <div className="text-xs text-gray-500">อุปกรณ์ไฟฟ้า</div>
              </div>
            </Link>

            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-gray-700 hover:text-blue-600">
                หน้าแรก
              </Link>
              <Link href="/categories" className="text-gray-700 hover:text-blue-600">
                สินค้า
              </Link>
              <Link href="/catalog" className="text-gray-700 hover:text-blue-600">
                แคตตาล็อก
              </Link>
              <Link href="/technical" className="text-gray-700 hover:text-blue-600">
                ข้อมูลเทคนิค
              </Link>
              <Link href="/about" className="text-gray-700 hover:text-blue-600">
                เกี่ยวกับเรา
              </Link>
              <Link href="/contact" className="text-blue-600 font-medium">
                ติดต่อ
              </Link>
            </nav>

            <div className="flex items-center space-x-4">
              <Link href="/admin">
                <Button variant="outline">แอดมิน</Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-slate-800 to-slate-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">ติดต่อเรา</h1>
            <p className="text-xl text-slate-300 mb-8">พร้อมให้คำปรึกษาและบริการด้านอุปกรณ์ไฟฟ้า O-Z/Gedney</p>
            <div className="flex justify-center space-x-8 text-sm">
              <div className="flex items-center space-x-2">
                <Phone className="h-5 w-5" />
                <span>โทร 02-123-4567</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="h-5 w-5" />
                <span>info@ozgedney.co.th</span>
              </div>
              <div className="flex items-center space-x-2">
                <Clock className="h-5 w-5" />
                <span>จันทร์-ศุกร์ 8:00-17:00</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Content */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Contact Form */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <h2 className="text-2xl font-bold">ส่งข้อความถึงเรา</h2>
                  <p className="text-gray-600">กรอกข้อมูลด้านล่าง เราจะติดต่อกลับโดยเร็วที่สุด</p>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">ชื่อ-นามสกุล *</label>
                        <Input
                          required
                          value={formData.name}
                          onChange={(e) => handleInputChange("name", e.target.value)}
                          placeholder="กรอกชื่อ-นามสกุล"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">อีเมล *</label>
                        <Input
                          type="email"
                          required
                          value={formData.email}
                          onChange={(e) => handleInputChange("email", e.target.value)}
                          placeholder="example@email.com"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">เบอร์โทรศัพท์</label>
                        <Input
                          value={formData.phone}
                          onChange={(e) => handleInputChange("phone", e.target.value)}
                          placeholder="08X-XXX-XXXX"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">บริษัท/องค์กร</label>
                        <Input
                          value={formData.company}
                          onChange={(e) => handleInputChange("company", e.target.value)}
                          placeholder="ชื่อบริษัทหรือองค์กร"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">หมวดหมู่ *</label>
                        <Select
                          value={formData.category}
                          onValueChange={(value) => handleInputChange("category", value)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="เลือกหมวดหมู่" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="product-inquiry">สอบถามสินค้า</SelectItem>
                            <SelectItem value="quote-request">ขอใบเสนอราคา</SelectItem>
                            <SelectItem value="technical-support">สนับสนุนเทคนิค</SelectItem>
                            <SelectItem value="warranty">การรับประกัน</SelectItem>
                            <SelectItem value="partnership">ความร่วมมือ</SelectItem>
                            <SelectItem value="other">อื่นๆ</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">หัวข้อ *</label>
                        <Input
                          required
                          value={formData.subject}
                          onChange={(e) => handleInputChange("subject", e.target.value)}
                          placeholder="หัวข้อที่ต้องการติดต่อ"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">รายละเอียด *</label>
                      <Textarea
                        required
                        rows={6}
                        value={formData.message}
                        onChange={(e) => handleInputChange("message", e.target.value)}
                        placeholder="กรุณาระบุรายละเอียดที่ต้องการติดต่อ..."
                      />
                    </div>

                    <Button
                      type="submit"
                      className="w-full bg-blue-600 hover:bg-blue-700"
                      size="lg"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? (
                        <>กำลังส่ง...</>
                      ) : (
                        <>
                          <Send className="h-5 w-5 mr-2" />
                          ส่งข้อความ
                        </>
                      )}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>

            {/* Contact Info */}
            <div className="space-y-6">
              {/* Office Info */}
              <Card>
                <CardHeader>
                  <h3 className="text-xl font-semibold">ข้อมูลติดต่อ</h3>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <MapPin className="h-5 w-5 text-blue-600 mt-1" />
                    <div>
                      <p className="font-medium">สำนักงานใหญ่</p>
                      <p className="text-gray-600 text-sm">
                        123/45 ถนนสุขุมวิท แขวงคลองตัน
                        <br />
                        เขตวัฒนา กรุงเทพฯ 10110
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3">
                    <Phone className="h-5 w-5 text-blue-600" />
                    <div>
                      <p className="font-medium">โทรศัพท์</p>
                      <p className="text-gray-600 text-sm">02-123-4567</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3">
                    <Mail className="h-5 w-5 text-blue-600" />
                    <div>
                      <p className="font-medium">อีเมล</p>
                      <p className="text-gray-600 text-sm">info@ozgedney.co.th</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <Clock className="h-5 w-5 text-blue-600 mt-1" />
                    <div>
                      <p className="font-medium">เวลาทำการ</p>
                      <p className="text-gray-600 text-sm">
                        จันทร์ - ศุกร์: 8:00 - 17:00
                        <br />
                        เสาร์: 8:00 - 12:00
                        <br />
                        อาทิตย์: ปิด
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Contact */}
              <Card>
                <CardHeader>
                  <h3 className="text-xl font-semibold">ติดต่อด่วน</h3>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    <Phone className="h-4 w-4 mr-3" />
                    โทรเลย 02-123-4567
                  </Button>
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    <MessageSquare className="h-4 w-4 mr-3" />
                    แชท Line: @ozgedney
                  </Button>
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    <Mail className="h-4 w-4 mr-3" />
                    ส่งอีเมลด่วน
                  </Button>
                </CardContent>
              </Card>

              {/* Departments */}
              <Card>
                <CardHeader>
                  <h3 className="text-xl font-semibold">แผนกต่างๆ</h3>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <Users className="h-5 w-5 text-blue-600" />
                    <div>
                      <p className="font-medium">ฝ่ายขาย</p>
                      <p className="text-gray-600 text-sm">sales@ozgedney.co.th</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3">
                    <Headphones className="h-5 w-5 text-blue-600" />
                    <div>
                      <p className="font-medium">ฝ่ายเทคนิค</p>
                      <p className="text-gray-600 text-sm">technical@ozgedney.co.th</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3">
                    <FileText className="h-5 w-5 text-blue-600" />
                    <div>
                      <p className="font-medium">ฝ่ายการเงิน</p>
                      <p className="text-gray-600 text-sm">finance@ozgedney.co.th</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Social Media */}
              <Card>
                <CardHeader>
                  <h3 className="text-xl font-semibold">ติดตามเรา</h3>
                </CardHeader>
                <CardContent>
                  <div className="flex space-x-4">
                    <Button variant="outline" size="sm">
                      <Facebook className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="sm">
                      <Twitter className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="sm">
                      <Linkedin className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="sm">
                      <Youtube className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">ที่ตั้งสำนักงาน</h2>
            <p className="text-lg text-gray-600">มาเยี่ยมชมโชว์รูมและคลังสินค้าของเรา</p>
          </div>

          <div className="bg-gray-200 rounded-lg h-96 flex items-center justify-center">
            <div className="text-center">
              <MapPin className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">แผนที่ Google Maps</p>
              <p className="text-sm text-gray-500">123/45 ถนนสุขุมวิท แขวงคลองตัน เขตวัฒนา กรุงเทพฯ 10110</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
