/api/customers (GET, POST) - Customer List & Create API - done
/api/customers/[id] (GET) - Get Customer by ID - done
/api/customers/[id] (PUT) - Update Customer - done
/api/customers/[id] (DELETE) - Delete Customer - done
Zustand Store -> Customer API - done
