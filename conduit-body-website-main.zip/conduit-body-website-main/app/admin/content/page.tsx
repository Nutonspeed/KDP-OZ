"use client"

export default function ContentPage() {
  return (
    <div className="p-6 text-center">
      <p className="text-gray-500">⚠️ หน้านี้ยังไม่เปิดใช้งาน</p>
    </div>
  )
}
